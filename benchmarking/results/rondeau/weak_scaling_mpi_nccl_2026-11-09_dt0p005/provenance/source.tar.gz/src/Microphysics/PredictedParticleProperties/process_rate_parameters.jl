#####
##### Process Rate Parameters
#####
##### Container for all P3 microphysical process rate parameters.
##### These parameters control timescales, efficiencies, and thresholds.
#####

export ProcessRate, NumericalFloors

struct NumericalFloors{FT}
    saturation_mass_fraction :: FT  # floors qᵛ⁺ˡ, qᵛ⁺ⁱ in supersaturation denominators [kg/kg]
    transport_coefficient :: FT     # floors Dᵛ and ν in Schmidt-number ratios [m²/s]
    mass_scale :: FT                # floors mass and volume denominators and log₁₀
                                    # arguments [kg/kg, kg, or m³/kg]
    number_scale :: FT              # floors number denominators [1/kg]; the scheme-less
                                    # counterpart of `minimum_number_mixing_ratio`
    rate_scale :: FT                # rate below which a process is treated as inactive
    divisor :: FT                   # smallest positive value admitted beneath a division or a `log`
    mean_particle_mass_fallback :: FT   # mean particle mass substituted where the number
                                        # concentration is exactly zero [kg]; only has to
                                        # land inside the ice tables' mass axis
end

"""
$(TYPEDSIGNATURES)

Construct the numerical floors shared by the P3 process rates: the smallest value each
quantity is allowed to take before it enters a division or a logarithm, so that a
process rate stays finite where the physics may legitimately reach zero. `divisor` is
the last resort — the smallest strictly positive number substituted for anything that
would otherwise send a quotient or a logarithm to infinity.
`mean_particle_mass_fallback` is the one entry that replaces a quantity outright rather
than bounding it, standing in for a mean particle mass where the number concentration
is exactly zero.

Each value is a field rather than a literal so that a configuration can move all of
them together. The defaults sit far below any atmospheric value at double precision and
remain normal numbers in `Float32`, whose smallest normal is ``1.2 × 10^{-38}``.
They do *not* survive `Float16`, whose smallest normal is ``6.1 × 10^{-5}`` — half
precision needs floors raised into that range, which is the reason they are settable
rather than baked in.

```jldoctest
using Breeze.Microphysics.PredictedParticleProperties: NumericalFloors
NumericalFloors(Float64)

# output
NumericalFloors(mass_scale=1.0e-20)
```
"""
function NumericalFloors(FT::DataType = Oceananigans.defaults.FloatType;
                         saturation_mass_fraction = 1e-10,
                         transport_coefficient = 1e-10,
                         mass_scale = 1e-20,
                         number_scale = 1e-16,
                         rate_scale = 1e-20,
                         divisor = 1e-30,
                         mean_particle_mass_fallback = 1e-12)
    return NumericalFloors{FT}(FT(saturation_mass_fraction),
                               FT(transport_coefficient),
                               FT(mass_scale),
                               FT(number_scale),
                               FT(rate_scale),
                               FT(divisor),
                               FT(mean_particle_mass_fallback))
end

# Re-typing conversion, used when `ProcessRate(FT)` is handed floors
# that were built at a different precision.
function NumericalFloors{FT}(floors::NumericalFloors) where FT
    return NumericalFloors{FT}(floors.saturation_mass_fraction,
                               floors.transport_coefficient,
                               floors.mass_scale,
                               floors.number_scale,
                               floors.rate_scale,
                               floors.divisor,
                               floors.mean_particle_mass_fallback)
end

# Helpers needing only floors take `floors` as a trailing argument
# (`tabulated_kernels.jl`, `process_rate_helpers.jl`, `rain_quadrature.jl`); scheme-level
# rate functions take `p3`/`parameters` and unpack it themselves. Either way the value is
# the scheme's settable field, so a configured floor reaches every per-cell rate and the
# rain tabulation alike. The quadrature evaluators carry it as a struct field because
# they run before a scheme exists.

Base.summary(::NumericalFloors) = "NumericalFloors"

function Base.show(io::IO, floors::NumericalFloors)
    print(io, summary(floors), "(mass_scale=", floors.mass_scale, ")")
end

"""
$(TYPEDEF)

Diagnose the vapor excess over liquid ``δqᵛ⁺ˡ = qᵛ - qᵛ⁺ˡ(T)`` from the thermodynamic
state and relax cloud condensation toward saturation. This is P3's default; no extra
prognostic field is carried.
"""
struct DiagnosticVaporExcess end

"""
$(TYPEDEF)

Carry the density-weighted vapor excess over liquid ``ρδqᵛ⁺ˡ`` as a prognostic field and
condense with the bounded saturation adjustment of
[Grabowski and Morrison (2008)](@cite GrabowskiMorrison2008).
"""
struct PrognosticVaporExcess end

Base.summary(::DiagnosticVaporExcess) = "DiagnosticVaporExcess"
Base.summary(::PrognosticVaporExcess) = "PrognosticVaporExcess"

"""
$(TYPEDEF)

Track liquid water on ice ``qʷⁱ`` and hence the liquid fraction of ice particles
[Milbrandt et al. (2025)](@cite MilbrandtEtAl2025liquidfraction). Melting and
above-freezing collection add liquid to the ice, which is shed to rain or refrozen.
This is P3's default.
"""
struct PrognosticLiquidFraction end

"""
$(TYPEDEF)

Carry no liquid on ice, as in P3 before [Milbrandt et al. (2025)](@cite MilbrandtEtAl2025liquidfraction):
melting and above-freezing collection route liquid directly to rain, and any ``qʷⁱ``
on the state is drained to rain over `sink_limiting_timescale`.
"""
struct NoLiquidFraction end

Base.summary(::PrognosticLiquidFraction) = "PrognosticLiquidFraction"
Base.summary(::NoLiquidFraction) = "NoLiquidFraction"

struct ProcessRate{FT, VE, LF}
    # Properties cached from `ThermodynamicConstants`. These are not independent
    # parameters: each is copied from the constants at construction and cannot be set
    # separately, so the two can never disagree.
    #
    # TODO: drop them and read `constants.liquid.density`, `constants.ice.density` at the
    # point of use, so nothing is stored twice. That needs `constants` threaded through
    # `rain_slope_parameter`, `rain_number_from_slope`, `bounded_rain_number`,
    # `activated_droplet_mass`, `tendency_ρbᶠ`, and their callers, which is a wider change
    # than this container. `ThermodynamicConstants` has no melting-point field, so
    # `freezing_temperature` (273.15 K at 1 atm, distinct from the 273.16 K triple point)
    # has nowhere to move until one is added there.
    liquid_water_density :: FT       # ρʷ [kg/m³], = constants.liquid.density
    pure_ice_density :: FT           # ρⁱ [kg/m³], = constants.ice.density
    freezing_temperature :: FT       # T₀ [K]

    # Rain fall-speed air-density correction, (ρ₀/ρ)^α
    reference_air_density :: FT      # ρ₀ [kg/m³]
    fall_speed_density_correction_exponent :: FT  # ℂᵈᵉⁿˢ₁ [-]
    minimum_fall_speed_air_density :: FT          # floor on ρ in the correction [kg/m³]

    # Newly formed particles
    nucleated_ice_mass :: FT         # ℂᶠᵒʳᵐ₁ [kg], newly nucleated ice crystal mass
    activated_droplet_radius :: FT   # ℂᶠᵒʳᵐ₂ [m], newly activated droplet radius
    activation_supersaturation_threshold :: FT  # ℂᶠᵒʳᵐ₃, activation onset [-]

    # Rain autoconversion (Khairoutdinov-Kogan 2000)
    autoconversion_coefficient :: FT         # ℂᵃᵘᵗᵒ₁, see KK2000 Eq. 29
    autoconversion_exponent_cloud :: FT      # ℂᵃᵘᵗᵒ₂ [-]
    autoconversion_exponent_droplet :: FT    # ℂᵃᵘᵗᵒ₃ [-]
    autoconversion_threshold :: FT           # ℂᵃᵘᵗᵒ₄ [kg/kg]
    autoconversion_reference_concentration :: FT  # unit-defining Nᶜˡ_r [1/m³], not free

    # Rain accretion (Khairoutdinov-Kogan 2000)
    accretion_coefficient :: FT              # ℂᵃᶜᶜʳ₁ [s⁻¹]
    accretion_exponent :: FT                 # ℂᵃᶜᶜʳ₂ [-]

    # Rain self-collection and breakup (KK2000 self-collection rate combined with
    # the Verlinde-Cotton 1993 breakup multiplier)
    rain_self_collection_coefficient :: FT   # ℂˢᵉˡᶠ₁ [m³ kg⁻¹ s⁻¹]
    rain_breakup_diameter_threshold :: FT    # ℂᵇʳᵏᵖ₁ [m] (1/λʳ convention)
    rain_breakup_coefficient :: FT           # ℂᵇʳᵏᵖ₂ [1/m]

    # Evaporation/sublimation timescales
    rain_evaporation_timescale :: FT         # τ_evap [s]

    # Ice aggregation. The sticking efficiency ramps linearly from its minimum to maximum
    # between the two temperatures, and is then shut off between the two rime
    # fractions, above which heavily rimed particles no longer aggregate.
    maximum_aggregation_efficiency :: FT     # ℂᵃᵍᵍʳ₁ [-]
    minimum_aggregation_efficiency :: FT     # ℂᵃᵍᵍʳ₂ [-], cold-ice value
    aggregation_efficiency_ramp_start_temperature :: FT # ℂᵃᵍᵍʳ₃ [K]
    aggregation_efficiency_ramp_end_temperature :: FT   # ℂᵃᵍᵍʳ₄ [K]
    minimum_aggregation_rime_fraction :: FT  # ℂᵃᵍᵍʳ₅ [-]
    maximum_aggregation_rime_fraction :: FT  # ℂᵃᵍᵍʳ₆ [-]

    # Cloud riming
    cloud_ice_collection_efficiency :: FT    # ℂʳⁱᵐᵉ₁ [-]

    # Rain riming
    rain_ice_collection_efficiency :: FT     # ℂʳⁱᵐᵉ₂ [-]

    # Rime density bounds
    minimum_rime_density :: FT               # ℂʳⁱᵐᵉ₃ [kg/m³]
    maximum_rime_density :: FT               # ℂʳⁱᵐᵉ₄ [kg/m³]

    # Riming impact parameter Ri, which sets the density of freshly accreted rime.
    # Ri = ℂʳⁱᵐᵉ₅ Dᶜ |𝕎ⁱ - 𝕎ᶜˡ| / (T₀ - T), evaluated in the cloud-riming branch.
    rime_impact_coefficient :: FT            # ℂʳⁱᵐᵉ₅ [K s / m²]
    minimum_rime_impact :: FT                # ℂʳⁱᵐᵉ₆ [-]
    maximum_rime_impact :: FT                # ℂʳⁱᵐᵉ₇ [-]
    minimum_riming_supercooling :: FT        # smallest T₀ - T admitted in Ri [K]
    unrimed_rime_density :: FT               # ℂʳⁱᵐᵉ₈ [kg/m³]
    rime_density_constant_coefficient :: FT  # ℂʳⁱᵐᵉ₉ [kg/m³]
    rime_density_linear_coefficient :: FT    # ℂʳⁱᵐᵉ₁₀ [kg/m³]
    rime_density_quadratic_coefficient :: FT # ℂʳⁱᵐᵉ₁₁ [kg/m³]
    rime_density_transition_impact :: FT     # ℂʳⁱᵐᵉ₁₂ [-]

    # Shedding
    shed_drop_mass :: FT                     # ℂˢʰᵉᵈ₁ [kg] (cloud/wet-growth shedding)
    shed_drop_mass_liqfrac :: FT             # ℂˢʰᵉᵈ₂ [kg] (liquid-fraction shedding)

    # Wet growth is off where there is too little cloud plus rain to collect, or where
    # collection barely outpaces the freezing capacity.
    wet_growth_hydrometeor_threshold :: FT   # ℂʷᵉᵗᵍ₁ [kg/kg]
    wet_growth_excess_threshold :: FT        # ℂʷᵉᵗᵍ₂, excess over freezing capacity
                                             # needed to fire wet growth [kg/kg/s]

    # Refreezing
    refreezing_timescale :: FT               # ℂᵖʰᵃˢ₁ [s]

    # Deposition nucleation (Cooper 1986)
    ice_nucleation_temperature_threshold :: FT   # ℂⁿᵘᶜˡ₁ [K]
    ice_nucleation_supersaturation_threshold :: FT  # ℂⁿᵘᶜˡ₂ [-]
    maximum_ice_nucleation_concentration :: FT   # ℂⁿᵘᶜˡ₃ [1/m³]
    ice_nucleation_timescale :: FT               # ℂⁿᵘᶜˡ₄ [s]
    ice_nucleation_coefficient :: FT             # ℂⁿᵘᶜˡ₅ [1/m³]
    ice_nucleation_temperature_coefficient :: FT # ℂⁿᵘᶜˡ₆ [1/K]

    # Immersion freezing (Barklie-Gokhale 1959)
    maximum_immersion_freezing_temperature :: FT # ℂⁱᵐᵐᶠ₁ [K]
    immersion_freezing_coefficient :: FT     # ℂⁱᵐᵐᶠ₂ [-]
    immersion_freezing_nucleation_coefficient :: FT  # ℂⁱᵐᵐᶠ₃ [m⁻³s⁻¹]

    # Rime splintering (Hallett-Mossop)
    minimum_splintering_temperature :: FT    # ℂᴴᴹ₁ [K]
    maximum_splintering_temperature :: FT    # ℂᴴᴹ₂ [K]
    splintering_temperature_peak :: FT       # ℂᴴᴹ₃ [K]
    splintering_rate :: FT                   # ℂᴴᴹ₄ [1/kg rime]
    splintering_crystal_mass :: FT           # ℂᴴᴹ₅ [kg]
    splintering_diameter_threshold :: FT     # ℂᴴᴹ₆ [m]
    splintering_cloud_riming_scale :: FT     # 1.0 for nCat=1 (include), 0.0 for nCat>1 (exclude)
    maximum_splintering_liquid_fraction :: FT # ℂᴴᴹ₇ [-]
    maximum_splintering_surface_temperature :: FT # ℂᴴᴹ₈ [K] (Inf disables)

    # Initial rain drop mass (for autoconversion number tendency)
    initial_rain_drop_mass :: FT             # ℂᵃᵘᵗᵒ₅, autoconversion seed mass [kg]

    # Homogeneous freezing (Koop et al. 2000)
    homogeneous_freezing_temperature :: FT   # ℂʰᵒᵐᶠ₁ [K]
    homogeneous_freezing_timescale :: FT     # ℂʰᵒᵐᶠ₂ [s]

    # Rime densification
    rime_densification_timescale :: FT       # ℂᵈᵉⁿˢ₂ [s]

    # Cloud size distribution bounds, imposed on the number-weighted mean droplet
    # diameter ⟨D⟩ = (μᶜˡ + 1) / λᶜˡ rather than on λᶜˡ itself; see `cloud_slope_bounds`.
    maximum_mean_droplet_diameter :: FT     # ℂᶜˡ₅, ⟨D⟩ maximum [m]
    minimum_mean_droplet_diameter :: FT     # ℂᶜˡ₆, ⟨D⟩ minimum [m]

    # Rain PSD slope bounds: the P3 rain lambda limiter. λʳ is clamped here and the
    # DSD-consistent number recomputed, so these bound ⟨D⟩ = (μʳ + 1) / λʳ.
    # `minimum_rain_slope` equals the reference `inv_Drmax = 1/0.002`, i.e. D_max ≈ 2 mm.
    minimum_rain_slope :: FT                # ℂʳ₁, λʳ minimum [1/m]
    maximum_rain_slope :: FT                # ℂʳ₂, λʳ maximum [1/m]

    # Sink-limiting safety timescale [s]
    # If total sinks for any species × dt_safety exceed available mass,
    # all sink rates for that species are rescaled proportionally.
    sink_limiting_timescale :: FT            # dt_safety [s]

    # Coupled donor-budget limiter
    # Fixed re-projection passes for the coupled dry-ice, rain, total-ice,
    # and coating-water sink budgets. Must be positive.
    coupled_sink_limiting_iterations :: Int

    # Global ice number limiter.
    # Applied as a relaxation sink whenever nⁱ × ρ exceeds the maximum.
    maximum_ice_number_density :: FT         # ℂᵖʰᵃˢ₂ [1/m³]

    # Liquid fraction clipping threshold (Milbrandt et al. 2025)
    # Fl < this: instantly freeze all qwi to rime; Fl > (1 - this): fully melt to rain.
    # Implemented as a relaxation drain over refreezing_timescale.
    liquid_fraction_clipping_threshold :: FT # ℂᵖʰᵃˢ₃ [-]

    # A separate "complete melting" diagnostic: a particle this liquid is
    # transferred whole to rain regardless of the clipping threshold above.
    complete_melting_liquid_fraction :: FT   # ℂᵖʰᵃˢ₄ [-]

    # Tiny-ice threshold for warm pre-processing. Ice holding less than
    # this at T ≥ T₀ is converted to rain outright.
    tiny_ice_to_rain_threshold :: FT                         # [kg/kg]

    # Tiny-mass instant-evaporation clauses of the saturation adjustment
    # a species holding less than `tiny_mass_evaporation_threshold` in air more than
    # `subsaturation_evaporation_threshold` below saturation is drained outright.
    tiny_mass_evaporation_threshold :: FT                    # [kg/kg]
    subsaturation_evaporation_threshold :: FT                # [-]

    # Liquid fraction treatment. With `PrognosticLiquidFraction()` (default), wet growth
    # rime densification is suppressed (liquid tracked explicitly in qʷⁱ), and
    # melt-densification is skipped. `NoLiquidFraction()` routes that liquid to rain.
    liquid_fraction :: LF

    # Vapor excess treatment: `DiagnosticVaporExcess()` (default) relaxes condensation
    # toward saturation; `PrognosticVaporExcess()` carries `ρδqᵛ⁺ˡ` and uses the bounded
    # Grabowski-Morrison (2008) adjustment for condensation.
    #
    # The `VE` type parameter lets allocation decisions and kernel gates dispatch at
    # compile time. `prognostic_field_names` must fold to a constant tuple (a `Union`
    # return type makes the host-side prognostic loop allocate), and
    # `materialize_microphysical_fields` needs the type to decide whether `ρδqᵛ⁺ˡ` exists.
    vapor_excess :: VE

    # Deposition/sublimation calibration factors.
    # Ad hoc multipliers to increase or decrease deposition and/or sublimation rates.
    # The representation of ice capacitances is highly simplified and the appropriate
    # values in the diffusional growth equation are uncertain.
    calibration_factor_deposition :: FT      # ℂᵈⁱᶠᶠ₁ [-]
    calibration_factor_sublimation :: FT     # ℂᵈⁱᶠᶠ₂ [-]

    # Numerical floors shared by every process rate
    floors :: NumericalFloors{FT}
end

"""
$(TYPEDSIGNATURES)

Construct process rate parameters with default values from P3 literature.

The liquid-water density, the pure-ice density, and the dry-air gas constant used by the
reference-density calculation come from the supplied `thermodynamic_constants`.
The default `shed_drop_mass` and `initial_rain_drop_mass` also use that liquid-water
density. The default `nucleated_ice_mass` uses `nucleated_ice_density` (900 kg/m³),
while `splintering_crystal_mass` uses `splintering_crystal_density`, which defaults to
`nucleated_ice_density`. Both ice seed densities are configurable independently of
`pure_ice_density`.

These parameters control the rates of all microphysical processes:
autoconversion, accretion, aggregation, riming, melting, evaporation,
deposition, nucleation, and freezing.

The fresh-rime density polynomial has configurable `rime_density_constant_coefficient`,
`rime_density_linear_coefficient`, and `rime_density_quadratic_coefficient` (all in kg/m³,
since the impact parameter is dimensionless). `rime_density_transition_impact` selects
the start of its linear extension. The extension is continuous and reaches
`maximum_rime_density` at `maximum_rime_impact`; its intercept and slope are derived,
not independent parameters. The impact bounds must satisfy
`minimum_rime_impact ≤ rime_density_transition_impact < maximum_rime_impact`.

Calibratable empirical values are denoted ``\\mathbb{C}`` in the theory. When a
kernel unpacks one into a formula-local variable, the implementation uses the matching
Unicode identifier, such as `ℂᵃᵘᵗᵒ₁`. The public fields and constructor keywords remain
descriptive; each calibratable field comment records its exact `ℂ` symbol. Physical
constants, case inputs, switches, and numerical safeguards do not receive `ℂ`. See the
[complete calibration inventory](@ref p3_calibration_inventory).

Ice terminal-velocity, projected-area, collection, and ventilation integrals are
read from the P3 lookup tables by [`read_lookup_tables`](@ref).
Rain velocity and evaporation integrals are generated with Julia quadrature.
Cloud PSD shape is diagnosed from droplet number, while the active rain-process
path uses ``μ_r = 0``. None are duplicated in this rate-parameter container.

# Default Sources

- Autoconversion/accretion: Khairoutdinov and Kogan (2000)
- Self-collection: Khairoutdinov and Kogan (2000); breakup: Verlinde and Cotton (1993)
- Aggregation: Morrison and Milbrandt (2015)
- Nucleation: Cooper (1986)
- Freezing: Barklie and Gokhale (1959)
- Splintering: Hallett and Mossop (1974)

# Example

The second and third type parameters are the types of `vapor_excess` and
`liquid_fraction`. The default `DiagnosticVaporExcess()` drops `ρδqᵛ⁺ˡ` from the
prognostic set entirely.

```jldoctest
using Breeze.Microphysics.PredictedParticleProperties: ProcessRate, DiagnosticVaporExcess,
                                                       PrognosticLiquidFraction
params = ProcessRate(Float64)
typeof(params)

# output
ProcessRate{Float64, DiagnosticVaporExcess, PrognosticLiquidFraction}
```

All parameters are keyword arguments with physically-based defaults. The coupled
donor-budget limiter uses four re-projection passes by default; set
`coupled_sink_limiting_iterations` to tune that count.
"""
function ProcessRate(FT::DataType = Oceananigans.defaults.FloatType;
        # Shared thermodynamic properties. `liquid_water_density`, `pure_ice_density`, and
        # every mass derived from them come from here, so they cannot fall out of step
        # with the model's own constants.
        thermodynamic_constants = ThermodynamicConstants(FT),
        # The melting point at 1 atm. `ThermodynamicConstants` carries the triple point
        # (273.16 K) and the latent-heat reference temperature, but not this.
        freezing_temperature = 273.15,

        # Rain fall-speed air-density correction (ρ₀/ρ)^α. ρ₀ is the dry-air density at
        # P = 1000 hPa, T = 0 °C; α is the Heymsfield et al. (2007) exponent; and the
        # density floor only bites above ~30 km, where there is no condensate to fall.
        reference_pressure = 100000,
        reference_temperature = 273.15,
        reference_air_density = reference_pressure /
            (dry_air_gas_constant(thermodynamic_constants) * reference_temperature),
        fall_speed_density_correction_exponent = 0.54,
        minimum_fall_speed_air_density = 0.01,

        # Newly formed particles. The nucleated crystal is a sphere of
        # `nucleated_ice_radius` at 900 kg/m³ — the density P3 assigns to freshly
        # formed ice, and NOT `pure_ice_density` (917 kg/m³), which is reserved for
        # reflectivity, effective radius and melt densification. See the deposition
        # nucleation section of `docs/src/microphysics/p3_theory.md`, which fixes
        # `m_{i0} = (4π/3) ρᵢ (1 μm)³` at `ρᵢ = 900`.
        nucleated_ice_radius = 1e-6,
        nucleated_ice_density = 900.0,
        nucleated_ice_mass = 4 * FT(π) / 3 * nucleated_ice_density *
                             nucleated_ice_radius^3,
        activated_droplet_radius = 1e-6,               # newly activated droplets are 1 μm
        activation_supersaturation_threshold = 1e-6,   # S above which CCN activate

        # Rain autoconversion
        # KK2000 Eq. 29: dqʳ/dt = 1350 qᶜˡ^2.47 Nᶜˡ^(-1.79) with Nᶜˡ in cm⁻³.
        # Rescaled for (Nᶜˡ/Nᶜˡ_ref)^β with Nᶜˡ_ref = 1e8 m⁻³ = 100 cm⁻³:
        # k₁ = 1350 × (100)^(-1.79) ≈ 0.355
        autoconversion_coefficient = 1350 * 100.0^(-1.79),
        autoconversion_exponent_cloud = 2.47,
        autoconversion_exponent_droplet = -1.79,
        autoconversion_threshold = 1e-8,  # qᶜˡ below which autoconversion is off [kg/kg]
        autoconversion_reference_concentration = 1e8,

        # Rain accretion
        accretion_coefficient = 67.0,
        accretion_exponent = 1.15,

        # Rain self-collection and breakup
        rain_self_collection_coefficient = 5.78,
        rain_breakup_diameter_threshold = 280e-6,  # 280 μm, in the 1/λʳ convention
        rain_breakup_coefficient = 2300.0,

        # Timescales
        rain_evaporation_timescale = 10.0,

        # Ice aggregation (Morrison & Milbrandt 2015a)
        maximum_aggregation_efficiency = 0.3,
        minimum_aggregation_efficiency = 0.001,
        aggregation_efficiency_ramp_start_temperature = 253.15,
        aggregation_efficiency_ramp_end_temperature = 273.15,
        minimum_aggregation_rime_fraction = 0.6,
        maximum_aggregation_rime_fraction = 0.9,

        # Cloud riming
        cloud_ice_collection_efficiency = 0.5,

        # Rain riming
        rain_ice_collection_efficiency = 1.0,

        # Rime density
        minimum_rime_density = 50.0,
        maximum_rime_density = 900.0,

        # Riming impact parameter. Outside 1 ≤ Ri ≤ 12 the underlying rime-density
        # fit extrapolates beyond the data it was fit to, so Ri is clamped there.
        rime_impact_coefficient = 0.5e6,
        minimum_rime_impact = 1.0,
        maximum_rime_impact = 12.0,
        minimum_riming_supercooling = 0.001,
        unrimed_rime_density = 400.0,
        # Cober–List polynomial in SI density units; the upper branch connects
        # its transition value to maximum_rime_density at maximum_rime_impact.
        rime_density_constant_coefficient = 51.0,
        rime_density_linear_coefficient = 114.0,
        rime_density_quadratic_coefficient = -5.5,
        rime_density_transition_impact = 8.0,

        # Shedding. Every path sheds the same 1 mm drop, so both masses are derived
        # from one diameter and the configured liquid density rather than carried as
        # literals: m_shed = π/6 ρʷ D³ = 5.236×10⁻⁷ kg, i.e. 1.910×10⁶ drops per kg.
        # They stay separate fields so each shedding path remains independently
        # tunable; pass either mass explicitly to override the shared default.
        shed_drop_diameter = 1e-3,             # D_shed [m]
        shed_drop_mass = FT(π) / 6 * thermodynamic_constants.liquid.density *
                         shed_drop_diameter^3, # cloud and wet-growth shedding
        shed_drop_mass_liqfrac = shed_drop_mass, # liquid-fraction shedding

        # Wet growth
        wet_growth_hydrometeor_threshold = 1e-6,
        wet_growth_excess_threshold = 1e-10,

        # Refreezing
        refreezing_timescale = 10.0,

        # Deposition nucleation
        ice_nucleation_temperature_threshold = 258.15,
        ice_nucleation_supersaturation_threshold = 0.05,
        maximum_ice_nucleation_concentration = 100e3,
        ice_nucleation_timescale = 10.0,
        ice_nucleation_coefficient = 5.0,
        # Cooper (1986): N = c exp(b (T₀ - T)) with b = 0.304 K⁻¹
        ice_nucleation_temperature_coefficient = 0.304,

        # Immersion freezing
        maximum_immersion_freezing_temperature = 269.15,
        immersion_freezing_coefficient = 0.65,
        # Barklie-Gokhale nucleation coefficient
        immersion_freezing_nucleation_coefficient = 2.0,

        # Rime splintering
        minimum_splintering_temperature = 265.15,
        maximum_splintering_temperature = 270.15,
        splintering_temperature_peak = 268.15,
        # Hallett-Mossop: 3.5e5 splinters/g × 1000 g/kg = 3.5e8 splinters/kg
        splintering_rate = 3.5e8,
        # A 10 μm splinter at 900 kg/m³: m = π/6 ρᵢ D³ ≈ 4.712e-13 kg. Same
        # freshly-formed-ice density as `nucleated_ice_density` above, not the
        # 917 kg/m³ `pure_ice_density`; the Hallett-Mossop section of
        # `docs/src/microphysics/p3_theory.md` fixes `D_init,HM = 10 μm` at `ρᵢ = 900`.
        splintering_crystal_diameter = 10e-6,
        splintering_crystal_density = nucleated_ice_density,
        splintering_crystal_mass = FT(π) / 6 * splintering_crystal_density *
                                  splintering_crystal_diameter^3,
        # 250 μm for a single ice category; 1000 μm with more than one
        splintering_diameter_threshold = 250e-6,
        # Cloud-riming splintering scale: 1.0 includes it (single ice category),
        # 0.0 excludes it (more than one category).
        splintering_cloud_riming_scale = 1.0,
        maximum_splintering_liquid_fraction = 0.1,
        # Warm-surface shutoff: nCat=1 uses 282 K, nCat>1 sets Inf (no shutoff).
        maximum_splintering_surface_temperature = 282.0,

        # Initial rain drop
        # A 25 μm radius; mass follows the configured liquid density.
        initial_rain_drop_mass = 4 * FT(π) / 3 * thermodynamic_constants.liquid.density * (25e-6)^3,

        # Homogeneous freezing
        homogeneous_freezing_temperature = 233.15,
        homogeneous_freezing_timescale = 10.0,

        # Rime densification
        rime_densification_timescale = 10.0,

        # Cloud PSD bounds, as the largest and smallest number-weighted mean droplet
        # diameter the distribution may take (see `cloud_slope_bounds`).
        maximum_mean_droplet_diameter = 40e-6,
        minimum_mean_droplet_diameter = 1e-6,

        # Rain PSD slope bounds, λʳ = (μʳ + 1) / D. With μʳ = 0 they correspond to the
        # largest and smallest mean drop diameters the distribution may take.
        minimum_rain_slope = 500.0,    # [1/m], D_max ≈ 2 mm
        maximum_rain_slope = 100000.0, # [1/m], D_min ≈ 10 μm

        # Sink-limiting safety timescale
        sink_limiting_timescale = 10.0, # dt_safety [s]

        # Coupled donor-budget limiter
        coupled_sink_limiting_iterations::Integer = 4,

        # Global ice number limiter: a relaxation sink drains nⁱ toward the
        # configured maximum divided by ρ.
        maximum_ice_number_density = 2e6,  # [1/m³]

        # Liquid fraction clipping (Milbrandt et al. 2025)
        liquid_fraction_clipping_threshold = 0.01,
        complete_melting_liquid_fraction = 0.99,

        # Tiny-ice threshold for warm pre-processing. Ice holding less
        # than this at T ≥ T₀ is converted to rain outright.
        tiny_ice_to_rain_threshold = 1e-12,

        # Tiny-mass instant-evaporation clauses of the saturation adjustment
        tiny_mass_evaporation_threshold = 1e-12,
        subsaturation_evaporation_threshold = 0.001,

        # Liquid fraction treatment
        liquid_fraction = PrognosticLiquidFraction(),

        # Vapor excess treatment
        vapor_excess = DiagnosticVaporExcess(),

        # Deposition/sublimation calibration factors
        calibration_factor_deposition = 1.0,
        calibration_factor_sublimation = 1.0,

        # Numerical floors (see `NumericalFloors`)
        floors = NumericalFloors(FT))

    coupled_sink_limiting_iterations > 0 ||
        throw(ArgumentError("coupled_sink_limiting_iterations must be positive"))

    FT(minimum_rime_impact) <= FT(rime_density_transition_impact) < FT(maximum_rime_impact) ||
        throw(ArgumentError("rime impact bounds must satisfy minimum_rime_impact ≤ rime_density_transition_impact < maximum_rime_impact"))

    return ProcessRate{FT, typeof(vapor_excess), typeof(liquid_fraction)}(
        FT(thermodynamic_constants.liquid.density),
        FT(thermodynamic_constants.ice.density),
        FT(freezing_temperature),
        FT(reference_air_density),
        FT(fall_speed_density_correction_exponent),
        FT(minimum_fall_speed_air_density),
        FT(nucleated_ice_mass),
        FT(activated_droplet_radius),
        FT(activation_supersaturation_threshold),
        FT(autoconversion_coefficient),
        FT(autoconversion_exponent_cloud),
        FT(autoconversion_exponent_droplet),
        FT(autoconversion_threshold),
        FT(autoconversion_reference_concentration),
        FT(accretion_coefficient),
        FT(accretion_exponent),
        FT(rain_self_collection_coefficient),
        FT(rain_breakup_diameter_threshold),
        FT(rain_breakup_coefficient),
        FT(rain_evaporation_timescale),
        FT(maximum_aggregation_efficiency),
        FT(minimum_aggregation_efficiency),
        FT(aggregation_efficiency_ramp_start_temperature),
        FT(aggregation_efficiency_ramp_end_temperature),
        FT(minimum_aggregation_rime_fraction),
        FT(maximum_aggregation_rime_fraction),
        FT(cloud_ice_collection_efficiency),
        FT(rain_ice_collection_efficiency),
        FT(minimum_rime_density),
        FT(maximum_rime_density),
        FT(rime_impact_coefficient),
        FT(minimum_rime_impact),
        FT(maximum_rime_impact),
        FT(minimum_riming_supercooling),
        FT(unrimed_rime_density),
        FT(rime_density_constant_coefficient),
        FT(rime_density_linear_coefficient),
        FT(rime_density_quadratic_coefficient),
        FT(rime_density_transition_impact),
        FT(shed_drop_mass),
        FT(shed_drop_mass_liqfrac),
        FT(wet_growth_hydrometeor_threshold),
        FT(wet_growth_excess_threshold),
        FT(refreezing_timescale),
        FT(ice_nucleation_temperature_threshold),
        FT(ice_nucleation_supersaturation_threshold),
        FT(maximum_ice_nucleation_concentration),
        FT(ice_nucleation_timescale),
        FT(ice_nucleation_coefficient),
        FT(ice_nucleation_temperature_coefficient),
        FT(maximum_immersion_freezing_temperature),
        FT(immersion_freezing_coefficient),
        FT(immersion_freezing_nucleation_coefficient),
        FT(minimum_splintering_temperature),
        FT(maximum_splintering_temperature),
        FT(splintering_temperature_peak),
        FT(splintering_rate),
        FT(splintering_crystal_mass),
        FT(splintering_diameter_threshold),
        FT(splintering_cloud_riming_scale),
        FT(maximum_splintering_liquid_fraction),
        FT(maximum_splintering_surface_temperature),
        FT(initial_rain_drop_mass),
        FT(homogeneous_freezing_temperature),
        FT(homogeneous_freezing_timescale),
        FT(rime_densification_timescale),
        FT(maximum_mean_droplet_diameter),
        FT(minimum_mean_droplet_diameter),
        FT(minimum_rain_slope),
        FT(maximum_rain_slope),
        FT(sink_limiting_timescale),
        Int(coupled_sink_limiting_iterations),
        FT(maximum_ice_number_density),
        FT(liquid_fraction_clipping_threshold),
        FT(complete_melting_liquid_fraction),
        FT(tiny_ice_to_rain_threshold),
        FT(tiny_mass_evaporation_threshold),
        FT(subsaturation_evaporation_threshold),
        liquid_fraction,
        vapor_excess,
        FT(calibration_factor_deposition),
        FT(calibration_factor_sublimation),
        NumericalFloors{FT}(floors)
    )
end

# Gate a rate on the vapor excess treatment. Dispatching on the type folds the branch
# at compile time.
@inline gate_prognostic_vapor_excess(::ProcessRate{FT, DiagnosticVaporExcess}, x) where FT = 0 * x
@inline gate_prognostic_vapor_excess(::ProcessRate{FT, PrognosticVaporExcess}, x) where FT = x

# Whether liquid on ice is tracked. A compile-time constant, so `ifelse` gates fold.
@inline tracks_liquid_on_ice(::ProcessRate{FT, VE, PrognosticLiquidFraction}) where {FT, VE} = true
@inline tracks_liquid_on_ice(::ProcessRate{FT, VE, NoLiquidFraction}) where {FT, VE} = false

Base.summary(::ProcessRate) = "ProcessRate"

function Base.show(io::IO, p::ProcessRate)
    print(io, summary(p), "(")
    print(io, "T₀=", p.freezing_temperature, "K, ")
    print(io, "ρʷ=", p.liquid_water_density, "kg/m³, ")
    print(io, "Eᶜⁱ=", p.cloud_ice_collection_efficiency, ")")
end
