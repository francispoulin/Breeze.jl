#####
##### PSD correction factors for spherical drop immersion freezing
#####
##### For a gamma PSD N'(D) = N₀ D^μ exp(-λD), volume-dependent per-drop freezing
##### gives a PSD-integrated mass freezing rate enhanced relative to the
##### mean-mass monodisperse approximation. For spherical drops the
##### correction is exactly:
#####
#####   C(μ) = Γ(μ+7) Γ(μ+1) / Γ(μ+4)²
#####
##### The per-drop freezing rate scales as droplet volume ∝ D³, so the mass freezing
##### rate ∝ mass × droplet volume ∝ D⁶ per drop. The correction is the ratio of the
##### PSD-integrated D⁶ moment to the mean-mass approximation (D_m)⁶:
#####   C(μ) = M₆ M₀ / M₃²  where Mₖ = ∫ Dᵏ N'(D) dD
#####

export psd_correction_spherical_volume

"""
$(TYPEDSIGNATURES)

Compute the analytically exact PSD correction factor for volume-dependent
immersion freezing of spherical drops with a gamma size distribution.

For a gamma PSD N'(D) = N₀ D^μ exp(−λD), the Barklie-Gokhale (1959) freezing probability
per drop scales with volume ∝ D³, so the mass freezing rate ∝ mass × volume ∝ D⁶. The
PSD-integrated rate is therefore ``M₆``, against ``M₃²/M₀`` for the mean-mass
approximation, where ``M_k = ∫ D^k N'(D) \\, dD``. Their ratio is:

```math
C(\\mu) = \\frac{\\Gamma(\\mu + 7)\\,\\Gamma(\\mu + 1)}{\\Gamma(\\mu + 4)^2}
```

Evaluated through the equivalent rational form
`(μ+6)(μ+5)(μ+4) / ((μ+3)(μ+2)(μ+1))` — exact, overflow-free, and free of the
three `loggamma` calls the gamma form would cost at every grid point.

Exact values:
- μ = 0: 720 × 1 / 36 = 20.0
- μ = 2: 40320 × 2 / 14400 = 5.6
- μ = 5: 11×10×9 / (8×7×6) ≈ 2.946
- Monotonically decreasing with μ (narrower PSD → less enhancement)

# Arguments
- `mu`: Shape parameter μ of the gamma PSD [-]

# Example

```jldoctest
using Breeze.Microphysics.PredictedParticleProperties: psd_correction_spherical_volume
psd_correction_spherical_volume(0.0)

# output
20.0
```
"""
@inline psd_correction_spherical_volume(mu) =
    (mu + 6) * (mu + 5) * (mu + 4) / ((mu + 3) * (mu + 2) * (mu + 1))
