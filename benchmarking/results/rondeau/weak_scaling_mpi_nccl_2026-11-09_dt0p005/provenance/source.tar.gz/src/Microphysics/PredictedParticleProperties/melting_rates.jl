#####
##### Melting
#####

"""
$(TYPEDSIGNATURES)

Compute ice melting rate using the heat balance equation from
Morrison & Milbrandt (2015a) Eq. 44.

The melting rate is determined by the heat flux to the particle:

```math
\\frac{dm}{dt} = -\\frac{2π \\, \\text{capm}}{ℒᶠʳ} × [Kᵃ(T-T_0) + ρ ℒˡ Dᵛ(q^v - q^{v+}_0)] × f^{ve}
```

where capm = cap × D is the P3 capacitance convention (2× physical C).

where:
- C is the capacitance
- ℒᶠʳ is the latent heat of fusion
- Kᵃ is thermal conductivity of air
- T_0 is the freezing temperature
- ℒˡ is latent heat of vaporization
- Dᵛ is diffusivity of water vapor
- qᵛ, qᵛ⁺(T₀) are the vapor and saturation specific humidities (total-air mass
  fractions) at T₀; qᵛ⁺(T₀) = ρᵛ⁺(T₀)/ρ so that ρ (qᵛ - qᵛ⁺(T₀)) = ρᵛ - ρᵛ⁺(T₀)
- fᵛᵉ is the ventilation factor

# Arguments
- `p3`: P3 microphysics scheme (provides parameters)
- `qⁱ`: Ice mass fraction [kg/kg]
- `nⁱ`: Ice number concentration [1/kg]
- `T`: Temperature [K]
- `qᵛ`: Vapor mass fraction [kg/kg]
- `Fᶠ`: Rime fraction [-]
- `ρᶠ`: Rime density [kg/m³]
- `ρ`: Air density [kg/m³]
- `constants`: Thermodynamic constants
- `transport`: Pre-computed air transport properties `(; Dᵛ, Kᵃ, ν)`

# Returns
- Rate of ice → rain conversion [kg/kg/s]
"""
@inline ice_melting_rate(p3, qⁱ, nⁱ, qʷⁱ, T, qᵛ, Fᶠ, ρᶠ, ρ,
                         constants, transport) =
    ice_melting_rate_and_ventilation(p3, qⁱ, nⁱ, qʷⁱ, T, qᵛ, Fᶠ, ρᶠ, ρ,
                                     constants, transport)[1]

# Returns `(melt_rate, small, large)`. The small/large split of the ventilation
# integral sets the rain-vs-coating partition in `ice_melting_rates`, and comes free
# with the four table reads the melt rate already makes at the bracket.
@inline function ice_melting_rate_and_ventilation(p3, qⁱ, nⁱ, qʷⁱ, T, qᵛ, Fᶠ, ρᶠ, ρ,
                                                  constants, transport)
    FT = typeof(qⁱ)
    parameters = p3.process_rates
    floors = parameters.floors

    # Liquid fraction for the Fˡ-blended ventilation tables.
    qⁱ_total = max(total_ice_mass(qⁱ, qʷⁱ), FT(floors.mass_scale))
    Fˡ = liquid_fraction_on_ice(qⁱ, qʷⁱ, floors)

    # Table lookup uses the total mass per particle, not the dry-only mass,
    # because the tables are indexed by total mass.
    # With no particles the rate below is nⁱ₊ * dm/dt = 0 regardless, so the
    # fallback mean mass only has to sit inside the table's mass axis.
    m_mean = safe_divide(qⁱ_total, max(0, nⁱ), FT(floors.mean_particle_mass_fallback))
    ρ_correction = ice_air_density_correction(parameters, p3.ice.fall_speed.reference_air_density, ρ)
    prep = ice_table_bracket(p3.ice.deposition.small_ice_ventilation_constant,
                             m_mean, Fᶠ, Fˡ, ρᶠ, floors)

    return ice_melting_at_bracket(p3, qⁱ, nⁱ, T, qᵛ, ρ, constants, transport,
                                  ρ_correction, prep)
end

# Shared body. With `P3IceLookups` the bracket floors `nⁱ` at `floors.number_scale` where the
# standalone form above floors it at zero; the coordinates agree for `nⁱ ≥ number_scale`, and
# below it the melt rate `nⁱ₊ × dm/dt` is negligible.
@inline function ice_melting_at_bracket(p3, qⁱ, nⁱ, T, qᵛ, ρ, constants, transport,
                                        ρ_correction, prep)
    FT = typeof(qⁱ)
    parameters = p3.process_rates

    qⁱ₊ = max(0, qⁱ)
    nⁱ₊ = max(0, nⁱ)

    T₀ = parameters.freezing_temperature

    # Only melt above freezing
    ΔT = T - T₀
    is_melting = ΔT > 0

    # Thermodynamic constants: ℒᶠʳ and ℒˡ are T-dependent.
    ℒᶠʳ = fusion_latent_heat(constants, T)
    ℒˡ = vaporization_latent_heat(constants, T)
    # T,P-dependent transport properties (pre-computed or computed on demand)
    Kᵃ = transport.Kᵃ       # Thermal conductivity of air [W/m/K]
    Dᵛ = transport.Dᵛ       # Diffusivity of water vapor [m²/s]
    ν  = transport.ν        # Kinematic viscosity [m²/s]

    q_sat0 = freezing_point_saturation_mass_fraction(constants, T₀, ρ)

    # Use the dry-ice PSD ventilation tables (small + large) for melting. The total
    # Ventilation/VentilationEnhanced tables use the wet-ice PSD and are not
    # appropriate for melting (they are not flagged as melting integrals during
    # table generation, so they are not evaluated over the dry-ice PSD).
    # All 4 tables share Table-1 axes, so they are read at the one bracket `prep`.
    dep = p3.ice.deposition
    sc_corr = ventilation_sc_correction(ν, Dᵛ, ρ_correction, parameters.floors)
    small = evaluate_at(dep.small_ice_ventilation_constant, prep) +
            sc_corr * evaluate_at(dep.small_ice_ventilation_reynolds, prep)
    large = evaluate_at(dep.large_ice_ventilation_constant, prep) +
            sc_corr * evaluate_at(dep.large_ice_ventilation_reynolds, prep)
    ventilated_capacitance = small + large

    # Heat flux terms (Eq. 44 from MM15a)
    # Sensible heat: Kᵃ × (T - T₀)
    𝒬ᵀ = Kᵃ * ΔT

    # Latent heat: ℒˡ × Dᵛ × ρ × (qᵛ - q_sat0)
    # When subsaturated, this is negative and opposes melting
    𝒬ᵛ = ℒˡ * Dᵛ * ρ * (qᵛ - q_sat0)

    # Total heat flux
    𝒬ᵗ = 𝒬ᵀ + 𝒬ᵛ

    # Melting rate per particle (negative dm/dt → positive melt rate)
    # Uses 2π (not 4π) because ventilation integral stores capm = cap × D
    # (the P3 convention), which is 2× the physical capacitance.
    dm_dt_melt = 2 * FT(π) * ventilated_capacitance * 𝒬ᵗ / ℒᶠʳ

    # Clamp to positive (only melting, not refreezing here)
    dm_dt_melt = max(0, dm_dt_melt)

    # Total rate
    melt_rate = nⁱ₊ * dm_dt_melt

    # Limit melting rate: physical heat-transfer rate is the true limiter.
    # Guard against numerical overflow with a safety timescale (dt_safety).
    # The driver or time integrator must additionally limit melting to
    # available ice per dt.
    max_melt = qⁱ₊ / p3.process_rates.sink_limiting_timescale
    melt_rate = min(melt_rate, max_melt)

    return (ifelse(is_melting, melt_rate, zero(FT)), small, large)
end

"""
$(TYPEDSIGNATURES)

Compute partitioned ice melting rates using PSD-resolved partitioning.

Above freezing, ice particles melt. The meltwater is partitioned using
tabulated small/large ice ventilation integrals:
- **Complete melting** (small particles, D ≤ D_crit): Meltwater sheds to rain
- **Partial melting** (large particles, D > D_crit): Meltwater stays as liquid coating (qʷⁱ)

Requires tabulated small/large ice ventilation integrals.

# Arguments
- `p3`: P3 microphysics scheme (provides parameters)
- `qⁱ`: Ice mass fraction [kg/kg]
- `nⁱ`: Ice number concentration [1/kg]
- `qʷⁱ`: Liquid water on ice [kg/kg]
- `T`: Temperature [K]
- `qᵛ`: Vapor mass fraction [kg/kg]
- `Fᶠ`: Rime fraction [-]
- `ρᶠ`: Rime density [kg/m³]
- `ρ`: Air density [kg/m³]
- `constants`: Thermodynamic constants
- `transport`: Pre-computed air transport properties `(; Dᵛ, Kᵃ, ν)`

# Returns
- NamedTuple with `partial_melting` and `complete_melting` rates [kg/kg/s]
"""
@inline function ice_melting_rates(p3, qⁱ, nⁱ, qʷⁱ, T, qᵛ, Fᶠ, ρᶠ, ρ,
                                   constants, transport)
    # Total melting rate, plus the small/large ventilation split it already had to
    # look up. Passing qʷⁱ gives the Fˡ-blended ventilation.
    total_melt, small, large =
        ice_melting_rate_and_ventilation(p3, qⁱ, nⁱ, qʷⁱ, T, qᵛ, Fᶠ, ρᶠ, ρ,
                                         constants, transport)

    return partition_melting(total_melt, small, large)
end

# Shared-lookup variant used by `p3_phase1_rates`.
@inline function ice_melting_rates(p3, qⁱ, nⁱ, T, qᵛ, ρ, constants, transport,
                                   lookups::P3IceLookups)
    total_melt, small, large =
        ice_melting_at_bracket(p3, qⁱ, nⁱ, T, qᵛ, ρ, constants, transport,
                               lookups.ρ_correction, lookups.prep)
    return partition_melting(total_melt, small, large)
end

@inline function partition_melting(total_melt, small, large)
    rain_fraction = psd_melting_rain_fraction(small, large)

    complete = total_melt * rain_fraction
    partial  = total_melt * (1 - rain_fraction)

    return (partial_melting = partial, complete_melting = complete)
end

# Fraction of melting that goes to rain (small particles, D ≤ D_crit), from the
# PSD-integrated small/large ice ventilation integrals computed by
# `ice_melting_rate_and_ventilation`.
@inline function psd_melting_rain_fraction(small, large)
    FT = typeof(small)
    total = small + large

    # With no tabulated ventilation on either side of the split there is nothing to
    # weight with, so the meltwater is divided evenly between rain and coating.
    degenerate_rain_fraction = FT(1) / 2
    return ifelse(total > eps(FT), clamp(small / total, FT(0), FT(1)), degenerate_rain_fraction)
end

"""
$(TYPEDSIGNATURES)

Compute ice number loss from melting.

Number of melted particles equals number of rain drops produced.

# Arguments
- `qⁱ`: Ice mass fraction [kg/kg]
- `nⁱ`: Ice number concentration [1/kg]
- `qⁱ_melt_rate`: Ice mass melting rate [kg/kg/s]

# Returns
- Rate of ice number loss [1/kg/s] (positive magnitude; sign applied in tendency assembly)
"""
@inline function ice_melting_number_rate(qⁱ, nⁱ, qⁱ_melt_rate)
    FT = typeof(qⁱ)

    qⁱ₊ = max(0, qⁱ)
    nⁱ₊ = max(0, nⁱ)

    # |∂nⁱ/∂t| = nⁱ × (∂qⁱ_melt/∂t) / qⁱ (positive magnitude)
    # Sign convention: returns positive; caller subtracts in tendency assembly.
    #
    # Form the melted fraction before multiplying by nⁱ. The ratio nⁱ/qⁱ overflows when qⁱ
    # is subnormal (reachable in Float32 as melting drains the dry ice), and Inf × 0 = NaN
    # when nothing melts. The melt rate is limited to qⁱ / sink_limiting_timescale, so the
    # fraction stays bounded.
    melted_fraction = safe_divide(qⁱ_melt_rate, qⁱ₊, zero(FT))

    return nⁱ₊ * melted_fraction
end
