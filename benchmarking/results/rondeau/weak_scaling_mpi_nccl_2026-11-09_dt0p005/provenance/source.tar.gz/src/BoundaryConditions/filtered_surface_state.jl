#####
##### Filtered Surface State for Bulk Boundary Conditions
#####
##### Temporal filtering of near-surface velocity and scalar fields
##### to mitigate spurious u*-u' correlations and resolution dependence
##### in bulk flux computations (Shin, Yang & Howland 2025;
##### Nishizawa & Kitamura 2018).
#####
##### `FilteredSurfaceVelocities` holds the filtered velocity components and the
##### filtered surface-layer virtual potential temperature difference `Δθᵥ = θᵥ(z₁) - θᵥˢ`,
##### the stability input of stability-dependent bulk coefficients. Per-BC scalar
##### sensible heat differences (Δθ, Δs) and vapor differences (Δqᵛ) are held separately
##### in `FilteredSurfaceScalar`.
#####

using KernelAbstractions: @kernel, @index
using Oceananigans: architecture
using Oceananigans.Fields: interpolate
using Oceananigans.Grids: xnode, ynode, topology, Flat
using Oceananigans.Utils: launch!, KernelParameters, prettysummary

#####
##### FilteredSurfaceVelocities
#####

struct FilteredSurfaceVelocities{U, V, Θ, H, FT, R, RΘ}
    u :: U   # Field{Face, Center, Nothing}
    v :: V   # Field{Center, Face, Nothing}
    Δθᵥ :: Θ # Field{Center, Center, Nothing} — filtered surface-layer difference θᵥ(z₁) - θᵥˢ
    height :: H
    filter_timescale :: FT
    last_update :: R      # Ref{Tuple{Int, Int}} on CPU, Tuple{Int, Int} on GPU (for u, v)
    last_Δθᵥ_update :: RΘ # independent Ref for Δθᵥ (only stability-dependent coefficients update it)
end

"""
    FilteredSurfaceVelocities(grid; filter_timescale, height=nothing)

Two-dimensional fields storing temporally filtered near-surface velocities and the
surface-layer virtual potential temperature difference for use in bulk flux boundary
conditions.
Filtering the matching velocity mitigates log-layer mismatch in wall-modeled
large-eddy simulations by removing the spurious correlation between the
instantaneous friction velocity and matching-velocity fluctuations
([Nishizawa & Kitamura (2018)](@cite NishizawaKitamura2018);
[Shin, Yang & Howland (2025)](@cite ShinYangHowland2025)).

The filtered velocities `ū`, `v̄` (and the surface-layer difference `Δθ̄ᵥ` when a
stability-dependent bulk coefficient is attached) are updated each time step via
an exponential (first-order) filter:

    ū ← (ū + ϵ u_new) / (1 + ϵ),     ϵ = Δt / τ

where `τ` is the `filter_timescale`. There is no default: `τ` sets how much of the
near-surface variability the wall model sees, so it must be chosen for the flow at hand.
For a wall model driven by the instantaneous near-surface state, omit `filtered_velocities`
from the bulk boundary condition instead.

`Δθ̄ᵥ` filters the *result* the stability correction needs, ``Δθᵥ = θᵥ(z₁) - θᵥˢ``,
formed at every update by the attached `PolynomialCoefficient` from the instantaneous
first-cell virtual potential temperature and specific humidity, the surface
temperature, the moisture availability and the surface phase. Filtering the one
difference rather than each of its inputs stores a single field, and is exact since
the filter is linear. When the bulk coefficient carries no stability correction the
field is allocated but unused.

# Keyword Arguments

- `filter_timescale` (required): Filter time scale `τ` in seconds; must be positive and finite.
- `height`: Reference height (m) for velocity evaluation. If `nothing` (default),
  the first grid cell center value is used. If a number, velocity is linearly
  interpolated to that height. (`Δθ̄ᵥ` is always formed at the first cell center,
  matching the height at which `bulk_coefficient` evaluates stability.)
"""
function FilteredSurfaceVelocities(grid; filter_timescale, height=nothing)
    validate_filter_timescale(filter_timescale)
    u  = Field{Face, Center, Nothing}(grid)
    v  = Field{Center, Face, Nothing}(grid)
    Δθᵥ = Field{Center, Center, Nothing}(grid)
    FT = typeof(filter_timescale)
    return FilteredSurfaceVelocities(u, v, Δθᵥ, height, FT(filter_timescale),
                                     Ref((0, 0)), Ref((0, 0)))
end

# `τ = Inf` gives `ϵ = Δt / τ = 0`, which freezes the filtered state at its initial value.
validate_filter_timescale(τ) = 0 < τ < Inf ||
    throw(ArgumentError("filter_timescale must be positive and finite, got $τ"))

_deref(r::Ref) = r[]
_deref(t::Tuple) = t

Adapt.adapt_structure(to, fv::FilteredSurfaceVelocities) =
    FilteredSurfaceVelocities(Adapt.adapt(to, fv.u),
                              Adapt.adapt(to, fv.v),
                              Adapt.adapt(to, fv.Δθᵥ),
                              fv.height,
                              fv.filter_timescale,
                              _deref(fv.last_update),
                              _deref(fv.last_Δθᵥ_update))

Base.summary(fv::FilteredSurfaceVelocities) =
    string("FilteredSurfaceVelocities(height=", fv.height,
           ", filter_timescale=", fv.filter_timescale, ")")

function Base.show(io::IO, fv::FilteredSurfaceVelocities)
    print(io, summary(fv), ":\n",
          "├── u: ", prettysummary(fv.u), '\n',
          "├── v: ", prettysummary(fv.v), '\n',
          "├── Δθᵥ: ", prettysummary(fv.Δθᵥ), '\n',
          "├── height: ", prettysummary(fv.height), '\n',
          "├── filter_timescale: ", prettysummary(fv.filter_timescale), '\n',
          "├── last_update: ", fv.last_update, '\n',
          "└── last_Δθᵥ_update: ", fv.last_Δθᵥ_update)
end

#####
##### FilteredSurfaceScalar
#####

struct FilteredSurfaceScalar{F, H, FT, R}
    field :: F   # Field{Center, Center, Nothing}
    height :: H
    filter_timescale :: FT
    last_update :: R  # Ref{Tuple{Int, Int}} on CPU, Tuple{Int, Int} on GPU
end

"""
    FilteredSurfaceScalar(grid; filter_timescale, height=nothing)

A two-dimensional field storing a temporally filtered near-surface scalar
for use in bulk flux boundary conditions. The bulk scalar fluxes store the complete
near-wall difference of their scalar (``Δθ``, ``Δs``, or ``Δqᵛ``), so the wall value
is filtered together with the atmospheric value.

The filter update is the same exponential form as `FilteredSurfaceVelocities`.

# Keyword Arguments

- `filter_timescale` (required): Filter time scale `τ` in seconds; must be positive and finite.
- `height`: Reference height (m) for scalar evaluation. If `nothing`, the
  first grid cell center value is used.
"""
function FilteredSurfaceScalar(grid; filter_timescale, height=nothing)
    validate_filter_timescale(filter_timescale)
    field = Field{Center, Center, Nothing}(grid)
    FT = typeof(filter_timescale)
    return FilteredSurfaceScalar(field, height, FT(filter_timescale), Ref((0, 0)))
end

Adapt.adapt_structure(to, fs::FilteredSurfaceScalar) =
    FilteredSurfaceScalar(Adapt.adapt(to, fs.field),
                          fs.height,
                          fs.filter_timescale,
                          _deref(fs.last_update))

Base.summary(fs::FilteredSurfaceScalar) =
    string("FilteredSurfaceScalar(height=", fs.height,
           ", filter_timescale=", fs.filter_timescale, ")")

function Base.show(io::IO, fs::FilteredSurfaceScalar)
    print(io, summary(fs), ":\n",
          "├── field: ", prettysummary(fs.field), '\n',
          "├── height: ", prettysummary(fs.height), '\n',
          "├── filter_timescale: ", prettysummary(fs.filter_timescale), '\n',
          "└── last_update: ", fs.last_update)
end

#####
##### Kernel parameters for filtered surface fields
#####

# Use 1:N+1 to cover the extra face point, avoiding fill_halo_regions!
filtered_range(::Flat, N) = 1:N
filtered_range(topo, N) = 1:N+1

function filtered_kernel_parameters(grid)
    TX, TY, _ = topology(grid)
    Nx, Ny, _ = size(grid)
    return KernelParameters(filtered_range(TX(), Nx), filtered_range(TY(), Ny))
end

#####
##### Height interpolation helper
#####

# No height specified: use first grid cell value
@inline interpolate_or_surface(i, j, grid, field, ℓx, ℓy, ::Nothing) = @inbounds field[i, j, 1]

# Fixed reference height: interpolate using Oceananigans.Fields.interpolate
@inline function interpolate_or_surface(i, j, grid, field, ℓx, ℓy, z)
    x = xnode(i, j, 1, grid, ℓx, ℓy, Center())
    y = ynode(i, j, 1, grid, ℓx, ℓy, Center())
    return interpolate((x, y, z), field, (ℓx, ℓy, Center()), grid)
end

#####
##### Update kernels
#####

# `nothing` selects direct sampling at initialization, which also discards stale NaNs.
@inline filter_surface_value(previous, current, ::Nothing) = current
@inline filter_surface_value(previous, current, ϵ) = (previous + ϵ * current) / (1 + ϵ)

@kernel function _update_filtered_velocities!(û, v̂, u, v, grid, height, ϵ)
    i, j = @index(Global, NTuple)
    uⁿ = interpolate_or_surface(i, j, grid, u, Face(), Center(), height)
    vⁿ = interpolate_or_surface(i, j, grid, v, Center(), Face(), height)
    @inbounds û[i, j, 1] = filter_surface_value(û[i, j, 1], uⁿ, ϵ)
    @inbounds v̂[i, j, 1] = filter_surface_value(v̂[i, j, 1], vⁿ, ϵ)
end

@kernel function _update_filtered_scalar!(f̂, field_3d, grid, height, ϵ)
    i, j = @index(Global, NTuple)
    fⁿ = interpolate_or_surface(i, j, grid, field_3d, Center(), Center(), height)
    @inbounds f̂[i, j, 1] = filter_surface_value(f̂[i, j, 1], fⁿ, ϵ)
end

# The surface-layer difference θᵥ(z₁) - θᵥˢ is formed at the first cell (the height at
# which the bulk coefficient evaluates stability) from the instantaneous state and the
# surface temperature `Tˢ` (a number, a field on the bottom, or a function of the wall
# coordinates and time, evaluated by `wall_value`), and the result is filtered. `fields`
# is the surface-layer field tuple the instantaneous θᵥ diagnostic reads.
@kernel function _update_filtered_Δθᵥ!(Δθ̂ᵥ, coef, Tˢ, grid, clock, fields, ϵ)
    i, j = @index(Global, NTuple)
    Tˢᵢⱼ = wall_value(i, j, grid, Bottom(), Tˢ, clock)
    pˢ = wall_air_pressure(i, j, 1, grid, Bottom(), nothing, fields, coef.thermodynamic_constants)
    Δθᵥⁿ = surface_layer_Δθᵥ(i, j, 1, grid, coef, Tˢᵢⱼ, fields, pˢ)
    @inbounds Δθ̂ᵥ[i, j, 1] = filter_surface_value(Δθ̂ᵥ[i, j, 1], Δθᵥⁿ, ϵ)
end

#####
##### Public initialize! and update! methods
#####

"""
$(TYPEDSIGNATURES)

Set filtered surface velocities to the current near-surface values.
"""
function initialize!(fv::FilteredSurfaceVelocities, velocities, grid)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    launch!(arch, grid, kp, _update_filtered_velocities!,
            fv.u, fv.v, velocities.u, velocities.v, grid, fv.height, nothing)
    return nothing
end

"""
$(TYPEDSIGNATURES)

Set filtered surface scalar to the current near-surface value.
"""
function initialize!(fs::FilteredSurfaceScalar, field_3d, grid)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    launch!(arch, grid, kp, _update_filtered_scalar!,
            fs.field, field_3d, grid, fs.height, nothing)
    return nothing
end

"""
$(TYPEDSIGNATURES)

Update the filtered surface velocities using the exponential filter
with time step `Δt`. `velocities` should be a `NamedTuple` with
fields `u` and `v`.
"""
function update!(fv::FilteredSurfaceVelocities, velocities, grid, Δt)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    ϵ = Δt / fv.filter_timescale
    launch!(arch, grid, kp, _update_filtered_velocities!,
            fv.u, fv.v, velocities.u, velocities.v, grid, fv.height, ϵ)
    return nothing
end

"""
$(TYPEDSIGNATURES)

Update the filtered surface scalar using the exponential filter
with time step `Δt`.
"""
function update!(fs::FilteredSurfaceScalar, field_3d, grid, Δt)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    ϵ = Δt / fs.filter_timescale
    launch!(arch, grid, kp, _update_filtered_scalar!,
            fs.field, field_3d, grid, fs.height, ϵ)
    return nothing
end

"""
$(TYPEDSIGNATURES)

Set the filtered surface-layer virtual potential temperature difference to its current
value, formed by the bulk coefficient `coef` from the first-cell state and the surface
temperature `Tˢ` (a number, a field on the bottom, or a function of the wall coordinates
and time, evaluated at `clock.time`).

`fields` is the surface-layer field tuple ([`surface_layer_state`](@ref)); it is mandatory rather
than defaulted, because the instantaneous θᵥ diagnostic evaluates itself from it and a kernel
cannot report a useful error when it is missing.
"""
function initialize_Δθᵥ!(fv::FilteredSurfaceVelocities, coef, Tˢ, grid, clock, fields)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    launch!(arch, grid, kp, _update_filtered_Δθᵥ!, fv.Δθᵥ, coef, Tˢ, grid, clock, fields, nothing)
    return nothing
end

"""
$(TYPEDSIGNATURES)

Apply the exponential filter to the surface-layer virtual potential temperature difference,
with the surface temperature `Tˢ` evaluated at `clock.time`. `fields` carries the same
requirement as [`initialize_Δθᵥ!`](@ref).
"""
function update_Δθᵥ!(fv::FilteredSurfaceVelocities, coef, Tˢ, grid, clock, Δt, fields)
    arch = architecture(grid)
    kp = filtered_kernel_parameters(grid)
    ϵ = Δt / fv.filter_timescale
    launch!(arch, grid, kp, _update_filtered_Δθᵥ!, fv.Δθᵥ, coef, Tˢ, grid, clock, fields, ϵ)
    return nothing
end

#####
##### Deduplication-aware initialize and update helpers
#####

initialize_filtered_surface_state!(::Nothing, model) = nothing
initialize_filtered_surface_state!(::Nothing, source_field, model) = nothing

function initialize_filtered_surface_state!(fv::FilteredSurfaceVelocities, model)
    initialize!(fv, model.velocities, model.grid)
    return nothing
end

function initialize_filtered_surface_state!(fs::FilteredSurfaceScalar, source_field, model)
    initialize!(fs, source_field, model.grid)
    return nothing
end

update_filtered_surface_state!(::Nothing, model) = nothing
update_filtered_surface_state!(::Nothing, source_field, model) = nothing

function update_filtered_surface_state!(fv::FilteredSurfaceVelocities, model)
    key = (model.clock.iteration, model.clock.stage)
    fv.last_update[] == key && return nothing
    Δt = model.clock.last_Δt
    isinf(Δt) && return nothing # no valid Δt yet (before first time step)
    update!(fv, model.velocities, model.grid, Δt)
    fv.last_update[] = key
    return nothing
end

function update_filtered_surface_state!(fs::FilteredSurfaceScalar, source_field, model)
    key = (model.clock.iteration, model.clock.stage)
    fs.last_update[] == key && return nothing
    Δt = model.clock.last_Δt
    isinf(Δt) && return nothing # no valid Δt yet (before first time step)
    update!(fs, source_field, model.grid, Δt)
    fs.last_update[] = key
    return nothing
end
