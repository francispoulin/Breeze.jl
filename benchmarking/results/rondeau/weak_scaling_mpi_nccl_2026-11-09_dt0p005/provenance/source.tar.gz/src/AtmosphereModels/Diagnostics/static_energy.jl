#####
##### Static energy
#####

struct StaticEnergyKernelFunction{F, R, μ, M, MF, TMP, TH}
    flavor :: F
    reference_state :: R
    microphysics :: μ
    microphysical_fields :: M
    specific_prognostic_moisture :: MF
    temperature :: TMP
    thermodynamic_constants :: TH
end

Adapt.adapt_structure(to, k::StaticEnergyKernelFunction) =
    StaticEnergyKernelFunction(adapt(to, k.flavor),
                               adapt(to, k.reference_state),
                               adapt(to, k.microphysics),
                               adapt(to, k.microphysical_fields),
                               adapt(to, k.specific_prognostic_moisture),
                               adapt(to, k.temperature),
                               adapt(to, k.thermodynamic_constants))

const StaticEnergy = KernelFunctionOperation{Center, Center, Center, <:Any, <:Any, <:StaticEnergyKernelFunction}

"""
    StaticEnergy(model, flavor=:specific)

Return a `KernelFunctionOperation` representing moist static energy ``s``.

Moist static energy is a conserved quantity in adiabatic, frictionless flow that
combines sensible heat, gravitational potential energy, and latent heat:

```math
s = cᵖᵐ T + g z - ℒˡ₀ qˡ - ℒⁱ₀ qⁱ
```

where ``cᵖᵐ`` is the moist air heat capacity, ``T`` is temperature,
``g`` is gravitational acceleration, ``z`` is height, and
``ℒˡ₀ qˡ + ℒⁱ₀ qⁱ`` uses latent-heat offsets extrapolated to zero kelvin.

This is the prognostic thermodynamic variable used in `StaticEnergyThermodynamics`.

# Arguments

- `model`: An `AtmosphereModel` instance.
- `flavor`: Either `:specific` (default) to return ``s``, or `:density` to return ``ρ s``.

# Examples

```jldoctest
using Breeze

grid = RectilinearGrid(size=(1, 1, 8), extent=(1, 1, 1e3))
model = AtmosphereModel(grid)
set!(model, θ=300)

s = StaticEnergy(model)
Field(s)

# output
1×1×8 Field{Center, Center, Center} on RectilinearGrid on CPU
├── grid: 1×1×8 RectilinearGrid{Float64, Periodic, Periodic, Bounded} on CPU with 1×1×3 halo
├── boundary conditions: FieldBoundaryConditions
│   └── west: Periodic, east: Periodic, south: Periodic, north: Periodic, bottom: ZeroFlux, top: ZeroFlux, immersed: Nothing
├── operand: KernelFunctionOperation at (Center, Center, Center)
├── status: time=0.0
└── data: 3×3×14 OffsetArray(::Array{Float64, 3}, 0:2, 0:2, -2:11) with eltype Float64 with indices 0:2×0:2×-2:11
    └── max=3.03019e5, min=302661.0, mean=3.0284e5
```
"""
function StaticEnergy(model, flavor_symbol=:specific)

    flavor = if flavor_symbol === :specific
        Specific()
    elseif flavor_symbol === :density
        Density()
    else
        msg = "`flavor` must be :specific or :density, received :$flavor_symbol"
        throw(ArgumentError(msg))
    end

    func = StaticEnergyKernelFunction(flavor,
                                      model.dynamics.reference_state,
                                      model.microphysics,
                                      model.microphysical_fields,
                                      specific_prognostic_moisture(model),
                                      model.temperature,
                                      model.thermodynamic_constants)

    return KernelFunctionOperation{Center, Center, Center}(func, model.grid)
end

function (d::StaticEnergyKernelFunction)(i, j, k, grid)
    @inbounds begin
        ρᵣ = d.reference_state.density[i, j, k]
        qᵛᵉ = d.specific_prognostic_moisture[i, j, k]
        T = d.temperature[i, j, k]
    end

    q = grid_moisture_fractions(i, j, k, grid, d.microphysics, ρᵣ, qᵛᵉ, d.microphysical_fields)
    cᵖᵐ = Thermodynamics.mixture_heat_capacity(q, d.thermodynamic_constants)

    g = d.thermodynamic_constants.gravitational_acceleration
    z = znode(i, j, k, grid, c, c, c)

    ℒˡ₀ = Thermodynamics.absolute_zero_latent_heat(d.thermodynamic_constants, d.thermodynamic_constants.liquid)
    ℒⁱ₀ = Thermodynamics.absolute_zero_latent_heat(d.thermodynamic_constants, d.thermodynamic_constants.ice)
    qˡ = q.liquid
    qⁱ = q.ice

    # Moist static energy
    s = cᵖᵐ * T + g * z - ℒˡ₀ * qˡ - ℒⁱ₀ * qⁱ

    if d.flavor isa Specific
        return s
    elseif d.flavor isa Density
        return ρᵣ * s
    end
end
