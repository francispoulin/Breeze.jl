#####
##### One-moment microphysics (CloudMicrophysics 1M)
#####
#
# This file implements one-moment bulk microphysics for cloud liquid and rain,
# supporting both saturation adjustment (equilibrium) and non-equilibrium
# cloud formation.
#
# References:
#   - Morrison, H. and Grabowski, W.W. (2008). A novel approach for representing ice
#     microphysics in models: Description and tests using a kinematic framework.
#     J. Atmos. Sci., 65, 1528–1548. https://doi.org/10.1175/2007JAS2491.1
#
# This file contains common infrastructure for all 1M schemes.
# Cloud liquid, rain, and tendency implementations are in one_moment_cloud_liquid_rain.jl
#
# ## MicrophysicalState pattern
#
# One-moment schemes use state structs (ℳ) to encapsulate local microphysical
# variables. This enables the same tendency functions to work for both grid-based
# LES and Lagrangian parcel models.
#
# For parcel models, the state is stored directly as `parcel.ℳ`.
# For grid models, the state is built via `grid_microphysical_state(i, j, k, grid, ...)`.
#####

using Breeze.AtmosphereModels: AbstractMicrophysicalState
using Breeze.AtmosphereModels: AtmosphereModels as AM

#####
##### MicrophysicalState structs for one-moment schemes
#####

"""
    WarmPhaseOneMomentState{FT} <: AbstractMicrophysicalState{FT}

Microphysical state for warm-phase one-moment bulk microphysics.

Contains the local mixing ratios needed to compute tendencies for cloud liquid
and rain. This state is used for both saturation adjustment and non-equilibrium
cloud formation in warm-phase (liquid only) simulations.

# Fields
- `qᶜˡ`: Cloud liquid mixing ratio (kg/kg)
- `qʳ`: Rain mixing ratio (kg/kg)
- `w`: Vertical velocity (m/s), used by the rain autoconversion
"""
struct WarmPhaseOneMomentState{FT} <: AbstractMicrophysicalState{FT}
    qᶜˡ :: FT  # cloud liquid mixing ratio
    qʳ  :: FT  # rain mixing ratio
    w   :: FT  # vertical velocity
end

"""
    MixedPhaseOneMomentState{FT} <: AbstractMicrophysicalState{FT}

Microphysical state for mixed-phase one-moment bulk microphysics.

Contains the local mixing ratios for cloud liquid, cloud ice, rain, and snow.
This state is used for both saturation adjustment and non-equilibrium
cloud formation in mixed-phase simulations.

# Fields
- `qᶜˡ`: Cloud liquid mixing ratio (kg/kg)
- `qᶜⁱ`: Cloud ice mixing ratio (kg/kg)
- `qʳ`: Rain mixing ratio (kg/kg)
- `qˢⁿ`: Snow mixing ratio (kg/kg)
- `w`: Vertical velocity (m/s), used by the rain autoconversion
"""
struct MixedPhaseOneMomentState{FT} <: AbstractMicrophysicalState{FT}
    qᶜˡ :: FT  # cloud liquid mixing ratio
    qᶜⁱ :: FT  # cloud ice mixing ratio
    qʳ  :: FT  # rain mixing ratio
    qˢⁿ :: FT  # snow mixing ratio
    w   :: FT  # vertical velocity
end

struct OneMomentCloudMicrophysicsCategories{P, V, FT}
    parameters :: P
    hydrometeor_velocities :: V
    freezing_temperature :: FT
end

struct TemperatureDependentIceFormation{FT, F} <: AbstractCondensateFormation
    rate :: FT
    frostenberg :: F
end

"""
$(TYPEDSIGNATURES)

Return one-moment categories backed by CloudMicrophysics' unified
`Microphysics1MParams` container.

# Keyword arguments
- `parameters`: CloudMicrophysics particle parameters and process options.
- `hydrometeor_velocities`: Terminal-velocity parameters for cloud condensate.
  Its rain and snow component is replaced with `parameters.terminal_velocity`
  so the two containers cannot diverge.
- `freezing_temperature`: Temperature used to route melting and freezing
  processes. Defaults to CloudMicrophysics' standard value, 273.15 K.
"""
function one_moment_cloud_microphysics_categories(
    FT::DataType = Oceananigans.defaults.FloatType;
    parameters = Microphysics1MParams(FT),
    hydrometeor_velocities = TerminalVelocityParams(FT),
    freezing_temperature = FT(273.15))

    # CloudMicrophysics owns the Blk1M rain and snow velocities. Retain Breeze's
    # aggregate velocity container for cloud condensate sedimentation, but make
    # its Blk1M component identical to the unified 1M parameter container.
    hydrometeor_velocities = TerminalVelocityParams(;
        hydrometeor_velocities.stokes,
        hydrometeor_velocities.chen2022,
        blk1m = parameters.terminal_velocity)
    freezing_temperature = convert(FT, freezing_temperature)

    return OneMomentCloudMicrophysicsCategories(parameters, hydrometeor_velocities, freezing_temperature)
end

const CM1MCategories = OneMomentCloudMicrophysicsCategories{<:Microphysics1MParams, <:TerminalVelocityParams}
const OneMomentCloudMicrophysics = BulkMicrophysics{<:Any, <:CM1MCategories}

"""
$(TYPEDSIGNATURES)

Return a `OneMomentCloudMicrophysics` microphysics scheme for warm-rain and mixed-phase precipitation.

The one-moment scheme uses CloudMicrophysics.jl 1M processes:
- Condensation/evaporation of cloud liquid (relaxation toward saturation)
- Autoconversion of cloud liquid to rain
- Accretion of cloud liquid by rain
- Terminal velocity for rain sedimentation

By default, non-equilibrium cloud formation is used, where cloud liquid is a prognostic
variable that evolves via condensation/evaporation tendencies following
[Morrison and Grabowski (2008)](@cite Morrison2008novel) (see Appendix A).
The prognostic variables are `ρqᶜˡ` (cloud liquid mass density) and `ρqʳ` (rain mass density).

For equilibrium (saturation adjustment) cloud formation, pass:

```jldoctest
using Breeze.Microphysics
cloud_formation = SaturationAdjustment(equilibrium=WarmPhaseEquilibrium())

# output
SaturationAdjustment{WarmPhaseEquilibrium, Breeze.Solvers.SecantSolver{Float64}}(WarmPhaseEquilibrium(), SecantSolver(reltol=0.0, abstol=0.0001, maxiter=20))
```

# Keyword arguments
- `categories`: One-moment parameters and terminal velocities, typically built
  with `one_moment_cloud_microphysics_categories`.
- `precipitation_boundary_condition`: Controls whether precipitation passes through the bottom boundary.
  - `nothing` (default): Rain exits through the bottom (open boundary)
  - `ImpenetrableBoundaryCondition()`: Rain collects at the bottom (zero terminal velocity at surface)

See the [CloudMicrophysics.jl documentation](https://clima.github.io/CloudMicrophysics.jl/dev/) for details.

# References
* Morrison, H. and Grabowski, W. W. (2008). A novel approach for representing ice
    microphysics in models: Description and tests using a kinematic framework.
    J. Atmos. Sci., 65, 1528–1548. <https://doi.org/10.1175/2007JAS2491.1>
"""
function OneMomentCloudMicrophysics(FT::DataType = Oceananigans.defaults.FloatType;
                                    cloud_formation = NonEquilibriumCloudFormation(nothing, nothing),
                                    categories = one_moment_cloud_microphysics_categories(FT),
                                    precipitation_boundary_condition = nothing,
                                    negative_moisture_correction = nothing)

    # For non-equilibrium schemes, materialize Breeze condensate-formation
    # models from the CloudMicrophysics process options.
    # This allows users to pass:
    #   - `nothing` as a placeholder → replaced with the configured option
    #   - `CloudLiquid` / `CloudIce` as phase indicators → replaced with the configured option
    #   - An `AbstractCondensateFormation` → used as-is
    if cloud_formation isa NonEquilibriumCloudFormation
        liquid = cloud_formation.liquid
        ice = cloud_formation.ice
        parameters = categories.parameters
        processes = parameters.processes
        process_params = parameters.process_params

        # Liquid: always materialize unless already an AbstractCondensateFormation
        liquid = materialize_condensate_formation(
            liquid,
            processes.cloud_liquid_formation,
            process_params.cloud_liquid_formation,
            parameters.cloud.liquid.ρw,
        )

        # Ice: `nothing` → warm-phase (no ice), otherwise materialize
        if ice !== nothing
            ice = materialize_condensate_formation(
                ice,
                processes.cloud_ice_formation,
                process_params.cloud_ice_formation,
                parameters.cloud.ice.ρᵢ,
            )
        end

        cloud_formation = NonEquilibriumCloudFormation(liquid, ice)
    end

    return BulkMicrophysics(cloud_formation, categories, precipitation_boundary_condition, negative_moisture_correction)
end

# Materialize a condensate-formation model from a placeholder, the process option,
# and the option's parameter data (the matching entry of `process_params`).
# If already an AbstractCondensateFormation, return as-is.
materialize_condensate_formation(cf::AbstractCondensateFormation, option, params, reference) = cf

function materialize_condensate_formation(cf, option, params, reference)
    return condensate_formation_from_option(option, params, reference)
end

condensate_formation_from_option(::Nothing, params, reference) = ConstantRateCondensateFormation(zero(reference))

function condensate_formation_from_option(::TemperatureDependent, params, reference)
    rate = convert(typeof(reference), inv(params.τ_relax))
    return TemperatureDependentIceFormation(rate, params.frostenberg)
end

function condensate_formation_from_option(option, params, reference)
    rate = convert(typeof(reference), inv(params.τ_relax))
    return ConstantRateCondensateFormation(rate)
end

# The Kessler rain autoconversion threshold and timescale blend between quiescent ("slow") and
# convective ("fast") values with the vertical velocity `w` (see `CloudMicrophysics.Parameters.KesslerAcnv`).
# With the default parameters the slow and fast values are equal and the rate does not depend on `w`.
@inline function liquid_autoconversion(parameters, qᶜˡ, w)
    micro = (; q_lcl = qᶜˡ)
    thermo = (; w)
    option = parameters.processes.rain_autoconversion
    return conv_q_lcl_to_q_rai(option, parameters, nothing, micro, thermo)
end

@inline function ice_autoconversion(parameters, q, qᶜⁱ, ρ, T, Tᶠ, constants)
    option = parameters.processes.snow_autoconversion
    return ice_autoconversion(option, parameters, q, qᶜⁱ, ρ, T, Tᶠ, constants)
end

@inline function ice_autoconversion(option, parameters, q, qᶜⁱ, ρ, T, Tᶠ, constants)
    micro = (; q_icl = qᶜⁱ)
    return conv_q_icl_to_q_sno(option, parameters, nothing, micro, nothing)
end

@inline function ice_autoconversion(
    option::WithSupersaturation,
    parameters,
    q,
    qᶜⁱ,
    ρ,
    T,
    Tᶠ,
    constants,
)
    return ice_autoconversion_with_supersaturation(
        option,
        parameters,
        q,
        qᶜⁱ,
        ρ,
        T,
        Tᶠ,
        constants,
    )
end

@inline function cloud_precipitation_accretion(
    ::Nothing,
    cloud,
    precipitation,
    velocity,
    qᶜ,
    qᵖ,
    ρ,
)
    return 0
end

@inline function cloud_precipitation_accretion(option, cloud, precipitation, velocity, qᶜ, qᵖ, ρ)
    E = convert(typeof(ρ), option.e)
    return accretion(cloud, precipitation, velocity, E, qᶜ, qᵖ, ρ)
end

@inline rain_sink_accretion(::Nothing, rain, cloud_ice, velocity, qᶜⁱ, qʳ, ρ) = 0

@inline function rain_sink_accretion(option, rain, cloud_ice, velocity, qᶜⁱ, qʳ, ρ)
    E = convert(typeof(ρ), option.e)
    return accretion_rain_sink(rain, cloud_ice, velocity, E, qᶜⁱ, qʳ, ρ)
end

@inline function rain_snow_accretion(
    ::Nothing,
    precipitation₁,
    precipitation₂,
    velocity₁,
    velocity₂,
    q₁,
    q₂,
    ρ,
)
    return 0
end

@inline function rain_snow_accretion(
    option,
    precipitation₁,
    precipitation₂,
    velocity₁,
    velocity₂,
    q₁,
    q₂,
    ρ,
)
    FT = typeof(ρ)
    E = convert(FT, option.e)
    velocity_dispersion = convert(FT, option.coeff_disp)
    return accretion_snow_rain(
        precipitation₁,
        precipitation₂,
        velocity₁,
        velocity₂,
        E,
        velocity_dispersion,
        q₁,
        q₂,
        ρ,
    )
end

@inline rain_evaporation_rate(::Nothing, rain, velocity, air, q, qʳ, ρ, T, constants) = 0

@inline function rain_evaporation_rate(option, rain, velocity, air, q, qʳ, ρ, T, constants)
    return rain_evaporation(rain, velocity, air, q, qʳ, ρ, T, constants)
end

@inline function snow_deposition_sublimation_rate(
    ::Nothing,
    snow,
    velocity,
    air,
    q,
    qˢⁿ,
    ρ,
    T,
    constants,
)
    return 0
end

@inline function snow_deposition_sublimation_rate(option, snow, velocity, air, q, qˢⁿ, ρ, T, constants)
    return snow_sublimation_deposition(snow, velocity, air, q, qˢⁿ, ρ, T, constants)
end

@inline function snow_deposition_sublimation_rate(
    ::SublimationOnly,
    snow,
    velocity,
    air,
    q,
    qˢⁿ,
    ρ,
    T,
    constants,
)
    return min(0, snow_sublimation_deposition(snow, velocity, air, q, qˢⁿ, ρ, T, constants))
end

@inline snow_melt_rate(::Nothing, snow, velocity, air, qˢⁿ, ρ, T, Tᶠ, constants) = 0

@inline function snow_melt_rate(option, snow, velocity, air, qˢⁿ, ρ, T, Tᶠ, constants)
    return snow_melting(snow, velocity, air, qˢⁿ, ρ, T, Tᶠ, constants)
end

@inline function cloud_ice_melt_rate(::Nothing, cloud_ice, air, qᶜⁱ, ρ, T, Tᶠ, constants)
    return 0
end

@inline function cloud_ice_melt_rate(
    ::CloudIceMelt,
    cloud_ice,
    air,
    qᶜⁱ,
    ρ,
    T,
    Tᶠ,
    constants,
)
    return cloud_ice_melting(cloud_ice, air, qᶜⁱ, ρ, T, Tᶠ, constants)
end

#####
##### Default fallbacks for OneMomentCloudMicrophysics
#####

const OMCM = OneMomentCloudMicrophysics

# Default fallback for OneMomentCloudMicrophysics tendencies (state-based)
@inline AM.microphysical_tendency(bμp::OMCM, name, ρ, ℳ, 𝒰, constants) = zero(ρ)

# Rain sedimentation velocity: stored as a vertical velocity component
@inline AM.sedimentation_velocity(bμp::OMCM, μ, ::Val{:ρqʳ}) = μ.wʳ

# Liquid fraction of each condensate mass (1 liquid, 0 ice), for the latent heat its sedimentation carries
@inline AM.condensate_liquid_fraction(bμp::OMCM, ::Val{:ρqᶜˡ}) = 1
@inline AM.condensate_liquid_fraction(bμp::OMCM, ::Val{:ρqʳ})  = 1
@inline AM.condensate_liquid_fraction(bμp::OMCM, ::Val{:ρqᶜⁱ}) = 0
@inline AM.condensate_liquid_fraction(bμp::OMCM, ::Val{:ρqˢⁿ}) = 0

#####
##### Type aliases
#####

# Shorthand for AbstractCondensateFormation (used in type constraints below)
const ACF = AbstractCondensateFormation

# Warm-phase saturation adjustment with 1M precipitation
const WP1M = BulkMicrophysics{<:WarmPhaseSaturationAdjustment, <:CM1MCategories}

# Mixed-phase saturation adjustment with 1M precipitation
const MP1M = BulkMicrophysics{<:MixedPhaseSaturationAdjustment, <:CM1MCategories}

# Non-equilibrium cloud formation type aliases (liquid only vs liquid + ice)
const WarmPhaseNE = NonEquilibriumCloudFormation{<:ACF, Nothing}
const MixedPhaseNE = NonEquilibriumCloudFormation{<:ACF, <:ACF}

# Warm-phase non-equilibrium with 1M precipitation
const WarmPhaseNonEquilibrium1M = BulkMicrophysics{<:WarmPhaseNE, <:CM1MCategories}
const WPNE1M = WarmPhaseNonEquilibrium1M

# Mixed-phase non-equilibrium with 1M precipitation
const MixedPhaseNonEquilibrium1M = BulkMicrophysics{<:MixedPhaseNE, <:CM1MCategories}
const MPNE1M = MixedPhaseNonEquilibrium1M

# Union types for dispatch
const WarmPhase1M = Union{WP1M, WPNE1M}
const MixedPhase1M = Union{MP1M, MPNE1M}
const NonEquilibrium1M = Union{WPNE1M, MPNE1M}
const OneMomentLiquidRain = Union{WP1M, WPNE1M, MP1M, MPNE1M}

@inline AM.precipitating_mass_fraction(i, j, k, ::WarmPhase1M, μ) = @inbounds μ.qʳ[i, j, k]
@inline AM.precipitating_mass_fraction(i, j, k, ::MixedPhase1M, μ) = @inbounds μ.qʳ[i, j, k] + μ.qˢⁿ[i, j, k]

# Snow sedimentation velocity (mixed-phase only)
@inline AM.sedimentation_velocity(bμp::MixedPhase1M, μ, ::Val{:ρqˢⁿ}) = μ.wˢⁿ

# Cloud liquid sedimentation velocity (non-equilibrium with cloud sedimentation)
@inline AM.sedimentation_velocity(bμp::NonEquilibrium1M, μ, ::Val{:ρqᶜˡ}) = μ.wᶜˡ

# Cloud ice sedimentation velocity (mixed-phase non-equilibrium)
@inline AM.sedimentation_velocity(bμp::MPNE1M, μ, ::Val{:ρqᶜⁱ}) = μ.wᶜⁱ

#####
##### Gridless MicrophysicalState construction
#####
#
# Microphysics schemes implement the gridless microphysical_state(microphysics, ρ, μ, 𝒰, velocities)
# which takes density-weighted prognostic variables μ (NamedTuple of scalars) and
# thermodynamic state 𝒰. The grid-indexed version is a generic wrapper that extracts
# μ from fields and calls this.
#
# For saturation adjustment: cloud condensate comes from 𝒰.moisture_mass_fractions
# For non-equilibrium: cloud condensate comes from prognostic μ

# Warm-phase saturation adjustment: cloud liquid from thermodynamic state, rain from prognostic
# The vertical velocity is kept for the rain autoconversion.
@inline function AM.microphysical_state(bμp::WP1M, ρ, μ, 𝒰, velocities)
    q = 𝒰.moisture_mass_fractions
    qʳ = μ.ρqʳ / ρ
    qᶜˡ = max(zero(qʳ), q.liquid - qʳ)  # cloud liquid = total liquid - rain
    return WarmPhaseOneMomentState(qᶜˡ, qʳ, velocities.w)
end

# Warm-phase non-equilibrium: all from prognostic μ
@inline function AM.microphysical_state(bμp::WPNE1M, ρ, μ, 𝒰, velocities)
    qᶜˡ = μ.ρqᶜˡ / ρ
    qʳ = μ.ρqʳ / ρ
    return WarmPhaseOneMomentState(qᶜˡ, qʳ, velocities.w)
end

# Mixed-phase saturation adjustment: cloud condensate from thermodynamic state
@inline function AM.microphysical_state(bμp::MP1M, ρ, μ, 𝒰, velocities)
    q = 𝒰.moisture_mass_fractions
    qʳ = μ.ρqʳ / ρ
    qˢⁿ = μ.ρqˢⁿ / ρ
    qᶜˡ = max(zero(qʳ), q.liquid - qʳ)  # cloud liquid = total liquid - rain
    qᶜⁱ = max(zero(qˢⁿ), q.ice - qˢⁿ)     # cloud ice = total ice - snow
    return MixedPhaseOneMomentState(qᶜˡ, qᶜⁱ, qʳ, qˢⁿ, velocities.w)
end

# Mixed-phase non-equilibrium: all from prognostic μ
@inline function AM.microphysical_state(bμp::MPNE1M, ρ, μ, 𝒰, velocities)
    qᶜˡ = μ.ρqᶜˡ / ρ
    qᶜⁱ = μ.ρqᶜⁱ / ρ
    qʳ = μ.ρqʳ / ρ
    qˢⁿ = μ.ρqˢⁿ / ρ
    return MixedPhaseOneMomentState(qᶜˡ, qᶜⁱ, qʳ, qˢⁿ, velocities.w)
end

#####
##### Relaxation timescales for non-equilibrium schemes
#####
#
# The `ConstantRateCondensateFormation.rate` field stores `1/τ_relax`, so we invert it.

@inline liquid_relaxation_timescale(cloud_formation, categories) = 1 / cloud_formation.liquid.rate

@inline function ice_relaxation_timescale(cloud_formation, categories, qᶜⁱ, T, qᵛ, qᵛ⁺ⁱ)
    return inv(cloud_formation.ice.rate)
end

@inline function ice_relaxation_timescale(
    cloud_formation::NonEquilibriumCloudFormation{L, I},
    categories,
    qᶜⁱ,
    T,
    qᵛ,
    qᵛ⁺ⁱ,
) where {L, I<:TemperatureDependentIceFormation}
    ice_formation = cloud_formation.ice
    parameters = categories.parameters
    τ_sub = inv(ice_formation.rate)
    τ_dep = temperature_dependent_ice_relaxation_timescale(
        parameters.cloud.ice,
        parameters.air_properties,
        ice_formation.frostenberg,
        qᶜⁱ,
        T,
    )
    return ifelse(qᵛ < qᵛ⁺ⁱ, τ_sub, τ_dep)
end

#####
##### Prognostic field names
#####

AM.prognostic_field_names(::WP1M) = (:ρqʳ,)
AM.prognostic_field_names(::WPNE1M) = (:ρqᶜˡ, :ρqʳ)
AM.prognostic_field_names(::MP1M) = (:ρqʳ, :ρqˢⁿ)
AM.prognostic_field_names(::MPNE1M) = (:ρqᶜˡ, :ρqᶜⁱ, :ρqʳ, :ρqˢⁿ)

# Negative moisture correction chains: heaviest → lightest → vapor
AM.correction_moisture_fields(::WP1M, μ) = (μ.ρqʳ,)
AM.correction_moisture_fields(::WPNE1M, μ) = (μ.ρqʳ, μ.ρqᶜˡ)
# Mixed-phase correction not yet implemented (requires energy adjustment for ice↔liquid)

#####
##### Field materialization
#####

const warm_phase_field_names = (:ρqʳ, :qᵛ, :qˡ, :qᶜˡ, :qʳ)
const ice_phase_field_names = (:ρqˢⁿ, :qⁱ, :qᶜⁱ, :qˢⁿ)

function AM.materialize_microphysical_fields(bμp::OneMomentLiquidRain, grid, bcs)
    if bμp isa WP1M
        center_names = (warm_phase_field_names..., :qᵉ)
    elseif bμp isa WPNE1M
        center_names = (:ρqᶜˡ, warm_phase_field_names...)
    elseif bμp isa MP1M
        center_names = (warm_phase_field_names..., ice_phase_field_names..., :qᵉ)
    elseif bμp isa MPNE1M
        center_names = (:ρqᶜˡ, :ρqᶜⁱ, warm_phase_field_names..., ice_phase_field_names...)
    end

    center_fields = center_field_tuple(grid, center_names...)

    # Sedimentation velocity fields (vertical components)
    wʳ = AM.sedimentation_velocity_field(grid)

    if bμp isa MPNE1M
        wˢⁿ = AM.sedimentation_velocity_field(grid)
        wᶜˡ = AM.sedimentation_velocity_field(grid)
        wᶜⁱ = AM.sedimentation_velocity_field(grid)
        return (; zip(center_names, center_fields)..., wʳ, wˢⁿ, wᶜˡ, wᶜⁱ)
    elseif bμp isa MP1M
        wˢⁿ = AM.sedimentation_velocity_field(grid)
        return (; zip(center_names, center_fields)..., wʳ, wˢⁿ)
    elseif bμp isa WPNE1M
        wᶜˡ = AM.sedimentation_velocity_field(grid)
        return (; zip(center_names, center_fields)..., wʳ, wᶜˡ)
    end

    return (; zip(center_names, center_fields)..., wʳ)
end

#####
##### update_microphysical_auxiliaries! for one-moment schemes
#####
#
# This single function updates all auxiliary (non-prognostic) microphysical fields.
# Grid indices (i, j, k) are needed because:
# 1. Fields must be written at specific grid points
# 2. Terminal velocity needs k == 1 check for bottom boundary condition

# Warm-phase one-moment schemes
@inline function AM.update_microphysical_auxiliaries!(μ, i, j, k, grid, bμp::WarmPhase1M, ℳ::WarmPhaseOneMomentState, ρ, 𝒰, constants)
    # State fields
    @inbounds μ.qᶜˡ[i, j, k] = ℳ.qᶜˡ
    @inbounds μ.qʳ[i, j, k] = ℳ.qʳ

    # Vapor from thermodynamic state
    @inbounds μ.qᵛ[i, j, k] = 𝒰.moisture_mass_fractions.vapor

    # Derived: total liquid
    @inbounds μ.qˡ[i, j, k] = ℳ.qᶜˡ + ℳ.qʳ

    # Sedimentation velocity with bottom boundary condition
    parameters = bμp.categories.parameters
    𝕎ʳ = terminal_velocity(parameters.precip.rain, parameters.terminal_velocity.rain, ρ, ℳ.qʳ)
    write_sedimentation_velocity!(μ.wʳ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ʳ)

    return nothing
end

# Mixed-phase one-moment schemes
@inline function AM.update_microphysical_auxiliaries!(μ, i, j, k, grid, bμp::MixedPhase1M, ℳ::MixedPhaseOneMomentState, ρ, 𝒰, constants)
    # State fields
    @inbounds μ.qᶜˡ[i, j, k] = ℳ.qᶜˡ
    @inbounds μ.qᶜⁱ[i, j, k] = ℳ.qᶜⁱ
    @inbounds μ.qʳ[i, j, k] = ℳ.qʳ
    @inbounds μ.qˢⁿ[i, j, k] = ℳ.qˢⁿ

    # Vapor from thermodynamic state
    @inbounds μ.qᵛ[i, j, k] = 𝒰.moisture_mass_fractions.vapor

    # Derived: total liquid and ice
    @inbounds μ.qˡ[i, j, k] = ℳ.qᶜˡ + ℳ.qʳ
    @inbounds μ.qⁱ[i, j, k] = ℳ.qᶜⁱ + ℳ.qˢⁿ

    # Sedimentation velocities with bottom boundary condition
    categories = bμp.categories
    parameters = categories.parameters

    # Rain sedimentation velocity
    𝕎ʳ = terminal_velocity(parameters.precip.rain, parameters.terminal_velocity.rain, ρ, ℳ.qʳ)
    write_sedimentation_velocity!(μ.wʳ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ʳ)

    # Snow sedimentation velocity
    𝕎ˢⁿ = terminal_velocity(parameters.precip.snow, parameters.terminal_velocity.snow, ρ, ℳ.qˢⁿ)
    write_sedimentation_velocity!(μ.wˢⁿ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ˢⁿ)

    return nothing
end

# Warm-phase non-equilibrium: adds cloud liquid sedimentation
@inline function AM.update_microphysical_auxiliaries!(μ, i, j, k, grid, bμp::WPNE1M, ℳ::WarmPhaseOneMomentState, ρ, 𝒰, constants)
    # State fields
    @inbounds μ.qᶜˡ[i, j, k] = ℳ.qᶜˡ
    @inbounds μ.qʳ[i, j, k] = ℳ.qʳ

    # Vapor from thermodynamic state
    @inbounds μ.qᵛ[i, j, k] = 𝒰.moisture_mass_fractions.vapor

    # Derived: total liquid
    @inbounds μ.qˡ[i, j, k] = ℳ.qᶜˡ + ℳ.qʳ

    categories = bμp.categories
    parameters = categories.parameters

    # Rain sedimentation velocity with bottom boundary condition
    𝕎ʳ = terminal_velocity(parameters.precip.rain, parameters.terminal_velocity.rain, ρ, ℳ.qʳ)
    write_sedimentation_velocity!(μ.wʳ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ʳ)

    # Cloud liquid sedimentation velocity (Stokes regime)
    𝕎ᶜˡ = CMNonEq.terminal_velocity(parameters.cloud.liquid, categories.hydrometeor_velocities.stokes, ρ, ℳ.qᶜˡ)
    write_sedimentation_velocity!(μ.wᶜˡ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ᶜˡ)

    return nothing
end

# Mixed-phase non-equilibrium: adds cloud liquid and ice sedimentation
@inline function AM.update_microphysical_auxiliaries!(μ, i, j, k, grid, bμp::MPNE1M, ℳ::MixedPhaseOneMomentState, ρ, 𝒰, constants)
    # State fields
    @inbounds μ.qᶜˡ[i, j, k] = ℳ.qᶜˡ
    @inbounds μ.qᶜⁱ[i, j, k] = ℳ.qᶜⁱ
    @inbounds μ.qʳ[i, j, k] = ℳ.qʳ
    @inbounds μ.qˢⁿ[i, j, k] = ℳ.qˢⁿ

    # Vapor from thermodynamic state
    @inbounds μ.qᵛ[i, j, k] = 𝒰.moisture_mass_fractions.vapor

    # Derived: total liquid and ice
    @inbounds μ.qˡ[i, j, k] = ℳ.qᶜˡ + ℳ.qʳ
    @inbounds μ.qⁱ[i, j, k] = ℳ.qᶜⁱ + ℳ.qˢⁿ

    categories = bμp.categories
    parameters = categories.parameters

    # Rain sedimentation velocity
    𝕎ʳ = terminal_velocity(parameters.precip.rain, parameters.terminal_velocity.rain, ρ, ℳ.qʳ)
    write_sedimentation_velocity!(μ.wʳ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ʳ)

    # Snow sedimentation velocity
    𝕎ˢⁿ = terminal_velocity(parameters.precip.snow, parameters.terminal_velocity.snow, ρ, ℳ.qˢⁿ)
    write_sedimentation_velocity!(μ.wˢⁿ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ˢⁿ)

    # Cloud liquid sedimentation velocity (Stokes regime)
    𝕎ᶜˡ = CMNonEq.terminal_velocity(parameters.cloud.liquid, categories.hydrometeor_velocities.stokes, ρ, ℳ.qᶜˡ)
    write_sedimentation_velocity!(μ.wᶜˡ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ᶜˡ)

    # Cloud ice sedimentation velocity (Chen 2022 small ice)
    𝕎ᶜⁱ = CMNonEq.terminal_velocity(parameters.cloud.ice, categories.hydrometeor_velocities.chen2022.small_ice, ρ, ℳ.qᶜⁱ)
    write_sedimentation_velocity!(μ.wᶜⁱ, i, j, k, bμp.precipitation_boundary_condition, 𝕎ᶜⁱ)

    return nothing
end

#####
##### Moisture fraction computation
#####

# State-based (gridless) moisture fraction computation for warm-phase 1M microphysics.
# Works with WarmPhaseOneMomentState which contains specific quantities (qᶜˡ, qʳ).
# Used by parcel models. Grid models use grid_moisture_fractions instead, which splits
# saturation adjustment from non-equilibrium the same way.

# Saturation adjustment: `specific_prognostic_moisture` returns the equilibrium
# moisture qᵉ = qᵛ + qᶜˡ, so cloud has to be removed to recover vapor.
@inline function AM.moisture_fractions(bμp::WP1M, ℳ::WarmPhaseOneMomentState, qᵉ)
    qˡ = ℳ.qᶜˡ + ℳ.qʳ
    qᵛ = qᵉ - ℳ.qᶜˡ
    return MoistureMassFractions(qᵛ, qˡ)
end

# Non-equilibrium: `specific_prognostic_moisture` already returned true vapor
# (qᵗ minus every condensate), so subtracting cloud again would double-count it.
@inline function AM.moisture_fractions(bμp::WPNE1M, ℳ::WarmPhaseOneMomentState, qᵛ)
    qˡ = ℳ.qᶜˡ + ℳ.qʳ
    return MoistureMassFractions(qᵛ, qˡ)
end

# State-based moisture fraction computation for mixed-phase 1M microphysics.
# SA: qᵉ is equilibrium moisture, subtract condensate to get vapor
@inline function AM.moisture_fractions(bμp::MP1M, ℳ::MixedPhaseOneMomentState, qᵉ)
    qˡ = ℳ.qᶜˡ + ℳ.qʳ
    qⁱ = ℳ.qᶜⁱ + ℳ.qˢⁿ
    qᵛ = qᵉ - ℳ.qᶜˡ - ℳ.qᶜⁱ
    return MoistureMassFractions(qᵛ, qˡ, qⁱ)
end

# NE: input is vapor; subtract condensate to get vapor (for parcel models).
@inline function AM.moisture_fractions(bμp::MPNE1M, ℳ::MixedPhaseOneMomentState, qᵛ)
    qˡ = ℳ.qᶜˡ + ℳ.qʳ
    qⁱ = ℳ.qᶜⁱ + ℳ.qˢⁿ
    return MoistureMassFractions(qᵛ, qˡ, qⁱ)
end

#####
##### grid_moisture_fractions for saturation adjustment schemes
#####
# Saturation adjustment schemes read cloud condensate from diagnostic fields (set in previous timestep).
# maybe_adjust_thermodynamic_state will then adjust to equilibrium for the current state.
@inline function AM.grid_moisture_fractions(i, j, k, grid, bμp::WP1M, ρ, qᵉ, μ)
    qᶜˡ = @inbounds μ.qᶜˡ[i, j, k]
    qʳ  = @inbounds μ.ρqʳ[i, j, k] / ρ
    qˡ = qᶜˡ + qʳ
    qᵛ = qᵉ - qᶜˡ
    return MoistureMassFractions(qᵛ, qˡ)
end

# Warm-phase non-equilibrium: prognostic stores true vapor; construct fractions directly.
@inline function AM.grid_moisture_fractions(i, j, k, grid, bμp::WPNE1M, ρ, qᵛ, μ)
    qᶜˡ = @inbounds μ.ρqᶜˡ[i, j, k] / ρ
    qʳ  = @inbounds μ.ρqʳ[i, j, k] / ρ
    qˡ = qᶜˡ + qʳ
    return MoistureMassFractions(qᵛ, qˡ)
end

# Mixed-phase saturation adjustment: read moisture partition from diagnostic fields.
@inline function AM.grid_moisture_fractions(i, j, k, grid, bμp::MP1M, ρ, qᵉ, μ)
    qᶜˡ = @inbounds μ.qᶜˡ[i, j, k]
    qᶜⁱ = @inbounds μ.qᶜⁱ[i, j, k]
    qʳ  = @inbounds μ.ρqʳ[i, j, k] / ρ
    qˢⁿ = @inbounds μ.ρqˢⁿ[i, j, k] / ρ
    qˡ = qᶜˡ + qʳ
    qⁱ = qᶜⁱ + qˢⁿ
    qᵛ = qᵉ - qᶜˡ - qᶜⁱ
    return MoistureMassFractions(qᵛ, qˡ, qⁱ)
end

# Mixed-phase non-equilibrium: prognostic stores true vapor; construct fractions directly.
@inline function AM.grid_moisture_fractions(i, j, k, grid, bμp::MPNE1M, ρ, qᵛ, μ)
    qᶜˡ = @inbounds μ.ρqᶜˡ[i, j, k] / ρ
    qʳ  = @inbounds μ.ρqʳ[i, j, k]  / ρ
    qᶜⁱ = @inbounds μ.ρqᶜⁱ[i, j, k] / ρ
    qˢⁿ = @inbounds μ.ρqˢⁿ[i, j, k] / ρ
    qˡ = qᶜˡ + qʳ
    qⁱ = qᶜⁱ + qˢⁿ
    return MoistureMassFractions(qᵛ, qˡ, qⁱ)
end

#####
##### Thermodynamic state adjustment
#####

# Non-equilibrium: no adjustment (cloud liquid and ice are prognostic)
@inline AM.maybe_adjust_thermodynamic_state(𝒰₀, bμp::NonEquilibrium1M, qᵛ, constants) = 𝒰₀

# Warm-phase schemes carry no snow
@inline snow_mass_fraction(::WP1M, μ, ρ) = zero(ρ)
@inline snow_mass_fraction(::MP1M, μ, ρ) = μ.ρqˢⁿ / ρ

# Saturation adjustment (warm-phase and mixed-phase)
@inline function AM.maybe_adjust_thermodynamic_state(𝒰₀, bμp::Union{WP1M, MP1M}, qᵉ, constants, μ, ρ)
    qʳ = μ.ρqʳ / ρ
    qˢⁿ = snow_mass_fraction(bμp, μ, ρ)
    q₁ = MoistureMassFractions(qᵉ, qʳ, qˢⁿ)
    𝒰₁ = with_moisture(𝒰₀, q₁)
    return adjust_thermodynamic_state(𝒰₁, bμp.cloud_formation, constants, (qʳ, qˢⁿ))
end

#####
##### Condensation/evaporation for non-equilibrium cloud formation
#####
#
# The condensation rate follows Morrison and Grabowski (2008, JAS), Appendix Eq. (A3):
#
#   dqˡ/dt = (qᵛ - qᵛ⁺) / (Γˡ τˡ)
#
# where qᵛ⁺ is the saturation specific humidity, τˡ is the relaxation timescale,
# and Γˡ is a thermodynamic adjustment factor that accounts for latent heating:
#
#   Γˡ = 1 + (ℒˡ / cᵖᵐ) ⋅ dqᵛ⁺/dT
#
# This factor arises because condensation releases latent heat, which increases
# temperature and hence increases the saturation specific humidity, creating a
# negative feedback that slows the approach to equilibrium.
#
# The derivative dqᵛ*/dT follows from the Clausius-Clapeyron equation:
#
#   dqᵛ⁺/dT = qᵛ⁺ ⋅ (ℒˡ / (Rᵛ T²) - 1/T)
#
# See Morrison and Grabowski (2008, JAS), Appendix A, especially Eq. (A3).
#####
#
# `thermodynamic_adjustment_factor` and `condensation_rate` are defined in `Breeze.Microphysics`
# so they can be shared by multiple bulk microphysics schemes.

#####
##### Rain tendency for warm-phase saturation adjustment 1M (WP1M)
#####
#
# Rain mass evolves via:
#   - Autoconversion: cloud liquid → rain (source)
#   - Accretion: cloud liquid + rain → rain (source)
#   - Evaporation: rain → vapor in subsaturated air (sink)
#
# The non-equilibrium and mixed-phase schemes evaluate these processes in their tendency bundles below.
#####

# Numerical timescale for limiting negative-value relaxation
const τⁿᵘᵐ = 10  # seconds

# Fraction of a donor's process rates that can be honoured without draining more than
# its content `q` over τⁿᵘᵐ: 1 when the summed sink rate `ΣS` fits, `q⁺ / (τⁿᵘᵐ ΣS)` otherwise.
@inline function donor_limiter(q, ΣS)
    q⁺ = max(0, q)
    # Disabled processes return integer zeros; retain the moisture precision for zero demand.
    demand = oftype(q, τⁿᵘᵐ) * ΣS
    # Protect the eagerly evaluated quotient at zero demand without flooring positive demand.
    denominator = ifelse(iszero(demand), one(demand), demand)
    return ifelse(demand > q⁺, q⁺ / denominator, one(demand))
end

#####
##### The two densities of the one-moment tendencies
#####
#
# `ρ` is the density that weights the prognostic mass fractions, so it converts specific rates S into
# the density tendencies ρ S. Saturation and every process rate depend on the air's own density ρᵐ
# = density(𝒰, constants): qᵛ⁺ = pᵛ⁺ / (ρᵐ Rᵛ T). On the compressible core the two coincide. On the
# anelastic core ρ is the reference density ρᵣ(z), a dry profile about 1% heavier than moist air at
# qᵛ = 16 g/kg, so saturating on ρ places qᵛ⁺ about 1% too low and condenses water in subsaturated air.

# State-based rain tendency for WP1M
@inline function AM.microphysical_tendency(bμp::WP1M, ::Val{:ρqʳ}, ρ, ℳ::WarmPhaseOneMomentState, 𝒰, constants)
    categories = bμp.categories
    parameters = categories.parameters
    processes = parameters.processes
    process_params = parameters.process_params
    cloud_liquid = parameters.cloud.liquid
    rain = parameters.precip.rain
    rain_velocity = parameters.terminal_velocity.rain
    qᶜˡ = ℳ.qᶜˡ
    qʳ = ℳ.qʳ
    ρᵐ = density(𝒰, constants)  # the air's own density; `ρ` only weights the tendencies

    # Autoconversion: cloud liquid → rain
    Sᵃᶜⁿᵛ = liquid_autoconversion(parameters, qᶜˡ, ℳ.w)

    # Accretion: cloud liquid captured by falling rain
    Sᵃᶜᶜ = cloud_precipitation_accretion(
        process_params.cloud_liquid_rain_accretion,
        cloud_liquid,
        rain,
        rain_velocity,
        qᶜˡ,
        qʳ,
        ρᵐ,
    )

    # Rain evaporation in subsaturated air
    T = temperature(𝒰, constants)
    q = 𝒰.moisture_mass_fractions
    Sᵉᵛᵃᵖ = rain_evaporation_rate(
        processes.rain_condensation_evaporation,
        rain,
        rain_velocity,
        parameters.air_properties,
        q,
        qʳ,
        ρᵐ,
        T,
        constants,
    )

    # Limit evaporation to available rain
    Sᵉᵛᵃᵖ_min = -max(0, qʳ) / τⁿᵘᵐ
    Sᵉᵛᵃᵖ = max(Sᵉᵛᵃᵖ, Sᵉᵛᵃᵖ_min)

    # Total tendency for ρqʳ
    ΣρS = ρ * (Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ)

    # Numerical relaxation for negative values
    ρSⁿᵘᵐ = -ρ * qʳ / τⁿᵘᵐ

    return ifelse(qʳ ≥ 0, ΣρS, ρSⁿᵘᵐ)
end

# Saturation adjustment partitions ρqᵉ diagnostically, so precipitation sources are drawn from ρqᵉ.
@inline AM.microphysical_tendency(bμp::WP1M, ::Val{:ρqᵉ}, ρ, ℳ, 𝒰, constants) =
    - AM.microphysical_tendency(bμp, Val(:ρqʳ), ρ, ℳ, 𝒰, constants)

#####
##### Microphysical tendencies for warm-phase non-equilibrium 1M (WPNE1M)
#####
#
# Conservation: d(ρqᵛ)/dt + d(ρqᶜˡ)/dt + d(ρqʳ)/dt = 0 (from phase changes)
#
# The bundle function computes all phase-change rates once and returns every
# tendency derived from them. This guarantees discrete conservation: the same
# rate value appears in every tendency that references it.
#
#   ρqᵛ:  −Sᶜᵒⁿᵈ − Sᵉᵛᵃᵖ    (vapor loses to condensation; evaporation restores vapor)
#   ρqᶜˡ: +Sᶜᵒⁿᵈ − Sᵃᶜⁿᵛ − Sᵃᶜᶜ  (condensation source; autoconversion/accretion sinks)
#   ρqʳ:  +Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ  (autoconversion/accretion sources; evaporation sink)
#####

@inline function wpne1m_tendencies(bμp::WPNE1M, ρ, ℳ::WarmPhaseOneMomentState, 𝒰, constants)
    categories = bμp.categories
    parameters = categories.parameters
    processes = parameters.processes
    process_params = parameters.process_params
    cloud_liquid = parameters.cloud.liquid
    rain = parameters.precip.rain
    rain_velocity = parameters.terminal_velocity.rain
    τᶜˡ = liquid_relaxation_timescale(bμp.cloud_formation, categories)
    qᶜˡ = ℳ.qᶜˡ
    qʳ = ℳ.qʳ

    T = temperature(𝒰, constants)
    q = 𝒰.moisture_mass_fractions
    qᵛ = q.vapor
    ρᵐ = density(𝒰, constants)  # the air's own density; `ρ` only weights the tendencies

    # Condensation: vapor ↔ cloud liquid
    qᵛ⁺ = saturation_specific_humidity(T, ρᵐ, constants, PlanarLiquidSurface())
    Sᶜᵒⁿᵈ = condensation_rate(qᵛ, qᵛ⁺, qᶜˡ, T, ρᵐ, q, τᶜˡ, constants)
    Sᶜᵒⁿᵈ = ifelse(isnan(Sᶜᵒⁿᵈ), zero(Sᶜᵒⁿᵈ), Sᶜᵒⁿᵈ)

    # Evaporation: rain → vapor (Sᵉᵛᵃᵖ < 0 when rain evaporates)
    Sᵉᵛᵃᵖ = rain_evaporation_rate(
        processes.rain_condensation_evaporation,
        rain,
        rain_velocity,
        parameters.air_properties,
        q,
        qʳ,
        ρᵐ,
        T,
        constants,
    )
    Sᵉᵛᵃᵖ = max(Sᵉᵛᵃᵖ, -max(0, qʳ) / τⁿᵘᵐ)

    # Collection: cloud liquid → rain (does not involve vapor)
    Sᵃᶜⁿᵛ = liquid_autoconversion(parameters, qᶜˡ, ℳ.w)
    Sᵃᶜᶜ = cloud_precipitation_accretion(
        process_params.cloud_liquid_rain_accretion,
        cloud_liquid,
        rain,
        rain_velocity,
        qᶜˡ,
        qʳ,
        ρᵐ,
    )

    # Physics tendencies — conserved by construction: ρqᵛ_phys + ρqᶜˡ_phys + ρqʳ_phys = 0
    ρqᵛ_phys  = ρ * (-Sᶜᵒⁿᵈ - Sᵉᵛᵃᵖ)
    ρqᶜˡ_phys = ρ * ( Sᶜᵒⁿᵈ - Sᵃᶜⁿᵛ - Sᵃᶜᶜ)
    ρqʳ_phys  = ρ * ( Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ)

    # Numerical relaxation guards — conserved by routing each correction to its exchange partner.
    # When q < 0, replace with -ρq/τⁿᵘᵐ and route the delta: v→cl, cl→r, r→v.
    # This preserves ρqᵛ + ρqᶜˡ + ρqʳ = 0 regardless of which guards fire.
    δᵛ  = ifelse(qᵛ  ≥ 0, zero(ρqᵛ_phys),  -ρ * qᵛ  / τⁿᵘᵐ      - ρqᵛ_phys)
    δᶜˡ = ifelse(qᶜˡ ≥ 0, zero(ρqᶜˡ_phys), -ρ * qᶜˡ / τⁿᵘᵐ      - ρqᶜˡ_phys)
    δʳ  = ifelse(qʳ  ≥ 0, zero(ρqʳ_phys),  -ρ * qʳ  / τⁿᵘᵐ      - ρqʳ_phys)

    ρqᵛ  = ρqᵛ_phys  + δᵛ  - δʳ
    ρqᶜˡ = ρqᶜˡ_phys + δᶜˡ - δᵛ
    ρqʳ  = ρqʳ_phys  + δʳ  - δᶜˡ

    return (; ρqᵛ, ρqᶜˡ, ρqʳ)
end

@inline function AM.microphysical_tendency(bμp::WPNE1M, ::Val{:ρqᵛ}, ρ, ℳ::WarmPhaseOneMomentState, 𝒰, constants)
    return wpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqᵛ
end

@inline function AM.microphysical_tendency(bμp::WPNE1M, ::Val{:ρqᶜˡ}, ρ, ℳ::WarmPhaseOneMomentState, 𝒰, constants)
    return wpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqᶜˡ
end

@inline function AM.microphysical_tendency(bμp::WPNE1M, ::Val{:ρqʳ}, ρ, ℳ::WarmPhaseOneMomentState, 𝒰, constants)
    return wpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqʳ
end

#####
##### Precipitation process rates shared by the mixed-phase 1M schemes
#####
#
# Every process that moves mass into or out of rain and snow, evaluated identically for the
# non-equilibrium (MPNE1M) and saturation-adjustment (MP1M) schemes. Vapor ↔ cloud exchange is not
# here: MPNE1M relaxes it prognostically and saturation adjustment owns it for MP1M.

@inline function mixed_phase_precipitation_rates(bμp, ρ, ℳ::MixedPhaseOneMomentState, q, T, Tᶠ, constants)
    parameters = bμp.categories.parameters
    processes = parameters.processes
    process_params = parameters.process_params
    cloud_liquid = parameters.cloud.liquid
    cloud_ice = parameters.cloud.ice
    rain = parameters.precip.rain
    snow = parameters.precip.snow
    rain_velocity = parameters.terminal_velocity.rain
    snow_velocity = parameters.terminal_velocity.snow
    air = parameters.air_properties
    qᶜˡ, qᶜⁱ, qʳ, qˢⁿ = ℳ.qᶜˡ, ℳ.qᶜⁱ, ℳ.qʳ, ℳ.qˢⁿ

    # Evaporation: rain → vapor (Sᵉᵛᵃᵖ < 0 when rain evaporates)
    Sᵉᵛᵃᵖ = rain_evaporation_rate(processes.rain_condensation_evaporation,
                                  rain, rain_velocity, air, q, qʳ, ρ, T, constants)

    # Snow sublimation/deposition: snow ↔ vapor (positive = deposition)
    Sˢᵘᵇˡ = snow_deposition_sublimation_rate(processes.snow_deposition_sublimation,
                                             snow, snow_velocity, air, q, qˢⁿ, ρ, T, constants)

    # Snow melting: snow → rain (always non-negative)
    Sᵐᵉˡᵗ = snow_melt_rate(processes.snow_melt, snow, snow_velocity, air, qˢⁿ, ρ, T, Tᶠ, constants)

    # Collection: cloud liquid → rain
    Sᵃᶜⁿᵛ = liquid_autoconversion(parameters, qᶜˡ, ℳ.w)
    Sᵃᶜᶜ = cloud_precipitation_accretion(process_params.cloud_liquid_rain_accretion,
                                         cloud_liquid, rain, rain_velocity, qᶜˡ, qʳ, ρ)

    # Ice → snow autoconversion
    Sᵃᶜⁿᵛⁱˢⁿ = ice_autoconversion(parameters, q, qᶜⁱ, ρ, T, Tᶠ, constants)

    # Accretion: cloud liquid + snow (riming when cold, shedding to rain when warm)
    Sᵃᶜᶜˡˢⁿ = cloud_precipitation_accretion(process_params.cloud_liquid_snow_accretion,
                                            cloud_liquid, snow, snow_velocity, qᶜˡ, qˢⁿ, ρ)

    # Accretion: cloud ice + snow → snow
    Sᵃᶜᶜⁱˢⁿ = cloud_precipitation_accretion(process_params.cloud_ice_snow_accretion,
                                            cloud_ice, snow, snow_velocity, qᶜⁱ, qˢⁿ, ρ)

    # Accretion: cloud ice + rain → snow (ice sink) and the matching rain sink
    Sᵃᶜᶜⁱʳ = cloud_precipitation_accretion(process_params.cloud_ice_rain_accretion,
                                           cloud_ice, rain, rain_velocity, qᶜⁱ, qʳ, ρ)
    Sᵃᶜᶜʳⁱ = rain_sink_accretion(process_params.cloud_ice_rain_accretion,
                                 rain, cloud_ice, rain_velocity, qᶜⁱ, qʳ, ρ)

    # Rain-snow collisions (computed for both cold and warm pathways)
    Sʳˢⁿ = rain_snow_accretion(process_params.rain_snow_accretion,
                               snow, rain, snow_velocity, rain_velocity, qˢⁿ, qʳ, ρ)
    Sˢⁿʳ = rain_snow_accretion(process_params.rain_snow_accretion,
                               rain, snow, rain_velocity, snow_velocity, qʳ, qˢⁿ, ρ)

    return (; Sᵉᵛᵃᵖ, Sˢᵘᵇˡ, Sᵐᵉˡᵗ, Sᵃᶜⁿᵛ, Sᵃᶜᶜ, Sᵃᶜⁿᵛⁱˢⁿ, Sᵃᶜᶜˡˢⁿ, Sᵃᶜᶜⁱˢⁿ, Sᵃᶜᶜⁱʳ, Sᵃᶜᶜʳⁱ, Sʳˢⁿ, Sˢⁿʳ)
end

#####
##### Microphysical tendencies for mixed-phase non-equilibrium 1M (MPNE1M)
#####
#
# The deposition rate follows Morrison and Grabowski (2008, JAS), Appendix Eq. (A3), but for ice:
#
#   dqⁱ/dt = (qᵛ - qᵛ⁺ⁱ) / (Γⁱ τⁱ)
#
# where qᵛ⁺ⁱ is the saturation specific humidity over ice, τⁱ is the ice relaxation
# timescale, and Γⁱ is the thermodynamic adjustment factor using ice latent heat.
#
# `ice_thermodynamic_adjustment_factor` and `deposition_rate` are defined in `Breeze.Microphysics`
# so they can be shared by multiple bulk microphysics schemes.
#
#   ρqᵛ:  −Sᶜᵒⁿᵈ − Sᵈᵉᵖ − Sᵉᵛᵃᵖ − Sˢᵘᵇˡ
#   ρqᶜˡ: +Sᶜᵒⁿᵈ − Sᵃᶜⁿᵛ − Sᵃᶜᶜ − Sᵃᶜᶜˡˢⁿ + Sᵐᵉˡᵗᶜⁱ
#   ρqᶜⁱ: +Sᵈᵉᵖ − Sᵃᶜⁿᵛⁱˢⁿ − Sᵃᶜᶜⁱˢⁿ − Sᵃᶜᶜⁱʳ − Sᵐᵉˡᵗᶜⁱ
#   ρqʳ:  +Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ − Sᵃᶜᶜʳⁱ + Sᵐᵉˡᵗ + T-routed(Sᵃᶜᶜˡˢⁿ, Sʳˢⁿ, Sˢⁿʳ, α)
#   ρqˢⁿ: +Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ + Sᵃᶜᶜʳⁱ + Sˢᵘᵇˡ − Sᵐᵉˡᵗ + T-routed(Sᵃᶜᶜˡˢⁿ, Sʳˢⁿ, Sˢⁿʳ, α)
#####

@inline function mpne1m_tendencies(bμp::MPNE1M, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    categories = bμp.categories
    parameters = categories.parameters
    processes = parameters.processes
    cloud_ice = parameters.cloud.ice
    air = parameters.air_properties
    τᶜˡ = liquid_relaxation_timescale(bμp.cloud_formation, categories)
    qᶜˡ = ℳ.qᶜˡ
    qᶜⁱ = ℳ.qᶜⁱ
    qʳ = ℳ.qʳ
    qˢⁿ = ℳ.qˢⁿ

    T = temperature(𝒰, constants)
    Tᶠ = categories.freezing_temperature
    q = 𝒰.moisture_mass_fractions
    qᵛ = q.vapor
    ρᵐ = density(𝒰, constants)  # the air's own density; `ρ` only weights the tendencies

    # Condensation: vapor ↔ cloud liquid
    qᵛ⁺ = saturation_specific_humidity(T, ρᵐ, constants, PlanarLiquidSurface())
    Sᶜᵒⁿᵈ = condensation_rate(qᵛ, qᵛ⁺, qᶜˡ, T, ρᵐ, q, τᶜˡ, constants)
    Sᶜᵒⁿᵈ = ifelse(isnan(Sᶜᵒⁿᵈ), zero(Sᶜᵒⁿᵈ), Sᶜᵒⁿᵈ)

    # Deposition: vapor ↔ cloud ice
    # Suppress warm cloud-ice growth, matching CloudMicrophysics' INP limiter.
    qᵛ⁺ⁱ = saturation_specific_humidity(T, ρᵐ, constants, PlanarIceSurface())
    τᶜⁱ = ice_relaxation_timescale(bμp.cloud_formation, categories, qᶜⁱ, T, qᵛ, qᵛ⁺ⁱ)
    Sᵈᵉᵖ = deposition_rate(qᵛ, qᵛ⁺ⁱ, qᶜⁱ, T, ρᵐ, q, τᶜⁱ, constants)
    Sᵈᵉᵖ = ifelse(isnan(Sᵈᵉᵖ), zero(Sᵈᵉᵖ), Sᵈᵉᵖ)
    Sᵈᵉᵖ = ifelse((T > Tᶠ) & (Sᵈᵉᵖ > 0), zero(Sᵈᵉᵖ), Sᵈᵉᵖ)

    (; Sᵉᵛᵃᵖ, Sˢᵘᵇˡ, Sᵐᵉˡᵗ, Sᵃᶜⁿᵛ, Sᵃᶜᶜ, Sᵃᶜⁿᵛⁱˢⁿ, Sᵃᶜᶜˡˢⁿ, Sᵃᶜᶜⁱˢⁿ, Sᵃᶜᶜⁱʳ, Sᵃᶜᶜʳⁱ, Sʳˢⁿ, Sˢⁿʳ) =
        mixed_phase_precipitation_rates(bμp, ρᵐ, ℳ, q, T, Tᶠ, constants)

    Sᵉᵛᵃᵖ = max(Sᵉᵛᵃᵖ, -max(0, qʳ) / τⁿᵘᵐ)
    Sˢᵘᵇˡ = max(Sˢᵘᵇˡ, -max(0, qˢⁿ) / τⁿᵘᵐ)
    Sᵐᵉˡᵗ = min(Sᵐᵉˡᵗ, max(0, qˢⁿ) / τⁿᵘᵐ)

    # Cloud ice melting: cloud ice → cloud liquid
    Sᵐᵉˡᵗᶜⁱ = cloud_ice_melt_rate(processes.cloud_ice_melt, cloud_ice, air, qᶜⁱ, ρᵐ, T, Tᶠ, constants)
    Sᵐᵉˡᵗᶜⁱ = min(Sᵐᵉˡᵗᶜⁱ, max(0, qᶜⁱ) / τⁿᵘᵐ)

    # Thermal melt factor for warm accretion
    α = warm_accretion_melt_factor(T, Tᶠ, constants)

    # Temperature routing (branchless)
    is_warm = T ≥ Tᶠ

    # Positivity: every process draws from exactly one donor reservoir. Scale each donor's
    # processes together so that the donor cannot lose more than its content over τⁿᵘᵐ.
    # Scaling a process scales its source and its sink alike, so conservation is untouched.
    Sᶜᵒⁿᵈ⁺, Sᶜᵒⁿᵈ⁻ = max(Sᶜᵒⁿᵈ, 0), min(Sᶜᵒⁿᵈ, 0)
    Sᵈᵉᵖ⁺, Sᵈᵉᵖ⁻ = max(Sᵈᵉᵖ, 0), min(Sᵈᵉᵖ, 0)
    Sᵉᵛᵃᵖ⁺, Sᵉᵛᵃᵖ⁻ = max(Sᵉᵛᵃᵖ, 0), min(Sᵉᵛᵃᵖ, 0)
    Sˢᵘᵇˡ⁺, Sˢᵘᵇˡ⁻ = max(Sˢᵘᵇˡ, 0), min(Sˢᵘᵇˡ, 0)
    Sʳˢⁿᶜ = ifelse(is_warm, zero(Sʳˢⁿ), Sʳˢⁿ)                       # cold: rain → snow

    fᵛ  = donor_limiter(qᵛ,  Sᶜᵒⁿᵈ⁺ + Sᵈᵉᵖ⁺ + Sᵉᵛᵃᵖ⁺ + Sˢᵘᵇˡ⁺)
    fᶜˡ = donor_limiter(qᶜˡ, -Sᶜᵒⁿᵈ⁻ + Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵃᶜᶜˡˢⁿ)
    fᶜⁱ = donor_limiter(qᶜⁱ, -Sᵈᵉᵖ⁻ + Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ + Sᵐᵉˡᵗᶜⁱ)
    fʳ  = donor_limiter(qʳ,  -Sᵉᵛᵃᵖ⁻ + Sᵃᶜᶜʳⁱ + Sʳˢⁿᶜ)

    # Collected liquid supplies heat for the melt rate α Sᵃᶜᶜˡˢⁿ. Limit collection before
    # computing this melt demand, then cap all snow sinks against the available snow.
    Sᵃᶜᶜˡˢⁿ = fᶜˡ * Sᵃᶜᶜˡˢⁿ
    Sˢⁿʷ = ifelse(is_warm, α * Sᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T))
    fˢⁿ = donor_limiter(qˢⁿ, -Sˢᵘᵇˡ⁻ + Sᵐᵉˡᵗ + Sˢⁿʷ)

    Sᶜᵒⁿᵈ = fᵛ * Sᶜᵒⁿᵈ⁺ + fᶜˡ * Sᶜᵒⁿᵈ⁻
    Sᵈᵉᵖ  = fᵛ * Sᵈᵉᵖ⁺  + fᶜⁱ * Sᵈᵉᵖ⁻
    Sᵉᵛᵃᵖ = fᵛ * Sᵉᵛᵃᵖ⁺ + fʳ  * Sᵉᵛᵃᵖ⁻
    Sˢᵘᵇˡ = fᵛ * Sˢᵘᵇˡ⁺ + fˢⁿ * Sˢᵘᵇˡ⁻
    Sᵃᶜⁿᵛ, Sᵃᶜᶜ = fᶜˡ * Sᵃᶜⁿᵛ, fᶜˡ * Sᵃᶜᶜ
    Sᵃᶜⁿᵛⁱˢⁿ, Sᵃᶜᶜⁱˢⁿ, Sᵃᶜᶜⁱʳ, Sᵐᵉˡᵗᶜⁱ = fᶜⁱ * Sᵃᶜⁿᵛⁱˢⁿ, fᶜⁱ * Sᵃᶜᶜⁱˢⁿ, fᶜⁱ * Sᵃᶜᶜⁱʳ, fᶜⁱ * Sᵐᵉˡᵗᶜⁱ
    Sᵃᶜᶜʳⁱ = fʳ * Sᵃᶜᶜʳⁱ
    Sᵐᵉˡᵗ = fˢⁿ * Sᵐᵉˡᵗ
    # Sᵃᶜᶜˡˢⁿ: the cloud-liquid part draws on cloud liquid, its warm melt part (α Sᵃᶜᶜˡˢⁿ) on snow.
    # Sʳˢⁿ: rain donor when cold, its warm melt part (α Sʳˢⁿ) on snow. Sˢⁿʳ: snow donor (warm).
    αSᵃᶜᶜˡˢⁿ = α * fˢⁿ * Sᵃᶜᶜˡˢⁿ
    Sʳˢⁿ = ifelse(is_warm, fˢⁿ, fʳ) * Sʳˢⁿ
    Sˢⁿʳ = fˢⁿ * Sˢⁿʳ

    # Physics tendencies — conserved by construction: sum of all five = 0
    ρqᵛ_phys  = ρ * (-Sᶜᵒⁿᵈ - Sᵈᵉᵖ - Sᵉᵛᵃᵖ - Sˢᵘᵇˡ)
    ρqᶜˡ_phys = ρ * ( Sᶜᵒⁿᵈ - Sᵃᶜⁿᵛ - Sᵃᶜᶜ - Sᵃᶜᶜˡˢⁿ + Sᵐᵉˡᵗᶜⁱ)
    ρqᶜⁱ_phys = ρ * ( Sᵈᵉᵖ - Sᵃᶜⁿᵛⁱˢⁿ - Sᵃᶜᶜⁱˢⁿ - Sᵃᶜᶜⁱʳ - Sᵐᵉˡᵗᶜⁱ)
    ρqʳ_phys  = ρ * ( Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ - Sᵃᶜᶜʳⁱ + Sᵐᵉˡᵗ
                     + ifelse(is_warm, Sᵃᶜᶜˡˢⁿ + αSᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T))
                     - ifelse(is_warm, zero(T), Sʳˢⁿ))
    ρqˢⁿ_phys = ρ * ( Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ + Sᵃᶜᶜʳⁱ + Sˢᵘᵇˡ - Sᵐᵉˡᵗ
                     + ifelse(is_warm, zero(T), Sᵃᶜᶜˡˢⁿ + Sʳˢⁿ)
                     - ifelse(is_warm, αSᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T)))

    # Numerical relaxation guards — conserved by routing each correction to its exchange partner.
    # When q < 0, replace with -ρq/τⁿᵘᵐ and route the delta to the coupled tracer:
    # Exchange partners are v↔cl, cl↔r, ci↔v, r↔v, and s↔v.
    # This preserves ρqᵛ + ρqᶜˡ + ρqᶜⁱ + ρqʳ + ρqˢⁿ = 0 regardless of which guards fire.
    δᵛ  = ifelse(qᵛ  ≥ 0, zero(ρqᵛ_phys),  -ρ * qᵛ  / τⁿᵘᵐ - ρqᵛ_phys)
    δᶜˡ = ifelse(qᶜˡ ≥ 0, zero(ρqᶜˡ_phys), -ρ * qᶜˡ / τⁿᵘᵐ - ρqᶜˡ_phys)
    δᶜⁱ = ifelse(qᶜⁱ ≥ 0, zero(ρqᶜⁱ_phys), -ρ * qᶜⁱ / τⁿᵘᵐ - ρqᶜⁱ_phys)
    δʳ  = ifelse(qʳ  ≥ 0, zero(ρqʳ_phys),  -ρ * qʳ  / τⁿᵘᵐ - ρqʳ_phys)
    δˢⁿ = ifelse(qˢⁿ ≥ 0, zero(ρqˢⁿ_phys), -ρ * qˢⁿ / τⁿᵘᵐ - ρqˢⁿ_phys)

    ρqᵛ  = ρqᵛ_phys  + δᵛ  - δᶜⁱ - δʳ - δˢⁿ
    ρqᶜˡ = ρqᶜˡ_phys + δᶜˡ - δᵛ
    ρqᶜⁱ = ρqᶜⁱ_phys + δᶜⁱ
    ρqʳ  = ρqʳ_phys  + δʳ  - δᶜˡ
    ρqˢⁿ = ρqˢⁿ_phys + δˢⁿ

    return (; ρqᵛ, ρqᶜˡ, ρqᶜⁱ, ρqʳ, ρqˢⁿ)
end

@inline function AM.microphysical_tendency(bμp::MPNE1M, ::Val{:ρqᵛ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
   G = mpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants)
   return G.ρqᵛ
end

@inline function AM.microphysical_tendency(bμp::MPNE1M, ::Val{:ρqᶜˡ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    return mpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqᶜˡ
end

@inline function AM.microphysical_tendency(bμp::MPNE1M, ::Val{:ρqᶜⁱ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    return mpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqᶜⁱ
end

@inline function AM.microphysical_tendency(bμp::MPNE1M, ::Val{:ρqʳ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    return mpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqʳ
end

@inline function AM.microphysical_tendency(bμp::MPNE1M, ::Val{:ρqˢⁿ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    return mpne1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqˢⁿ
end

#####
##### Fused microphysics tendency for MPNE1M
#####
#
# `mpne1m_tendencies` bundles all 5 prognostic tendencies in one call. We override
# `compute_microphysical_tendencies!` to compute the bundle once per cell and
# write to all 5 G fields in a single kernel.

@kernel function _compute_mpne1m_tendencies!(Gρqᵛ, Gρqᶜˡ, Gρqᶜⁱ, Gρqʳ, Gρqˢⁿ,
                                             grid, microphysics, dynamics, formulation,
                                             constants, specific_prognostic_moisture,
                                             microphysical_fields, velocities)
    i, j, k = @index(Global, NTuple)

    ρ_field = AM.total_density(dynamics)
    @inbounds ρ = ρ_field[i, j, k]
    @inbounds qᵛ = specific_prognostic_moisture[i, j, k]

    # Reconstruct moisture fractions and thermodynamic state at this cell.
    q = AM.grid_moisture_fractions(i, j, k, grid, microphysics, ρ, qᵛ, microphysical_fields)
    𝒰 = AM.diagnose_thermodynamic_state(i, j, k, grid, formulation, dynamics, q)

    # Build the microphysical state directly to avoid interpolating the horizontal velocities
    # in `grid_microphysical_state`: only the vertical velocity is used (by the rain autoconversion).
    @inbounds qᶜˡ = microphysical_fields.ρqᶜˡ[i, j, k] / ρ
    @inbounds qᶜⁱ = microphysical_fields.ρqᶜⁱ[i, j, k] / ρ
    @inbounds qʳ  = microphysical_fields.ρqʳ[i, j, k]  / ρ
    @inbounds qˢⁿ = microphysical_fields.ρqˢⁿ[i, j, k] / ρ
    w = ℑzᵃᵃᶜ(i, j, k, grid, velocities.w)
    ℳ = MixedPhaseOneMomentState(qᶜˡ, qᶜⁱ, qʳ, qˢⁿ, w)

    G = mpne1m_tendencies(microphysics, ρ, ℳ, 𝒰, constants)

    @inbounds Gρqᵛ[i, j, k]  += G.ρqᵛ
    @inbounds Gρqᶜˡ[i, j, k] += G.ρqᶜˡ
    @inbounds Gρqᶜⁱ[i, j, k] += G.ρqᶜⁱ
    @inbounds Gρqʳ[i, j, k]  += G.ρqʳ
    @inbounds Gρqˢⁿ[i, j, k]  += G.ρqˢⁿ
end

function AM.compute_microphysical_tendencies!(microphysics::MPNE1M, model)
    grid = model.grid
    arch = grid.architecture
    G = model.timestepper.Gⁿ

    launch!(arch, grid, :xyz, _compute_mpne1m_tendencies!,
            G.ρqᵛ, G.ρqᶜˡ, G.ρqᶜⁱ, G.ρqʳ, G.ρqˢⁿ,
            grid, microphysics, model.dynamics, model.formulation,
            model.thermodynamic_constants, AM.specific_prognostic_moisture(model),
            model.microphysical_fields, model.velocities)

    return nothing
end

#####
##### Microphysical tendencies for mixed-phase saturation-adjustment 1M (MP1M)
#####
#
# Saturation adjustment partitions the equilibrium moisture ρqᵉ = ρ(qᵛ + qᶜˡ + qᶜⁱ) into vapor,
# cloud liquid and cloud ice every stage, so only the exchanges with the two precipitating
# reservoirs are tendencies. Each rate below is the MPNE1M rate of the same process:
#
#   ρqʳ:  +Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ − Sᵃᶜᶜʳⁱ + Sᵐᵉˡᵗ + T-routed(Sᵃᶜᶜˡˢⁿ, Sʳˢⁿ, Sˢⁿʳ, α)
#   ρqˢⁿ: +Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ + Sᵃᶜᶜʳⁱ + Sˢᵘᵇˡ − Sᵐᵉˡᵗ + T-routed(Sᵃᶜᶜˡˢⁿ, Sʳˢⁿ, Sˢⁿʳ, α)
#   ρqᵉ:  −(ρqʳ + ρqˢⁿ)
#
# Sinks are limited per donor reservoir (vapor, cloud liquid, cloud ice, rain, snow) with
# `donor_limiter`, which keeps every reservoir non-negative without breaking conservation.
#####

@inline function mp1m_tendencies(bμp::MP1M, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    categories = bμp.categories
    qᶜˡ = ℳ.qᶜˡ
    qᶜⁱ = ℳ.qᶜⁱ
    qʳ = ℳ.qʳ
    qˢⁿ = ℳ.qˢⁿ

    T = temperature(𝒰, constants)
    Tᶠ = categories.freezing_temperature
    q = 𝒰.moisture_mass_fractions
    qᵛ = q.vapor
    ρᵐ = density(𝒰, constants)  # the air's own density; `ρ` only weights the tendencies

    (; Sᵉᵛᵃᵖ, Sˢᵘᵇˡ, Sᵐᵉˡᵗ, Sᵃᶜⁿᵛ, Sᵃᶜᶜ, Sᵃᶜⁿᵛⁱˢⁿ, Sᵃᶜᶜˡˢⁿ, Sᵃᶜᶜⁱˢⁿ, Sᵃᶜᶜⁱʳ, Sᵃᶜᶜʳⁱ, Sʳˢⁿ, Sˢⁿʳ) =
        mixed_phase_precipitation_rates(bμp, ρᵐ, ℳ, q, T, Tᶠ, constants)

    α = warm_accretion_melt_factor(T, Tᶠ, constants)
    is_warm = T ≥ Tᶠ

    # Donor-limited process rates (see `donor_limiter`)
    Sᵉᵛᵃᵖ⁺, Sᵉᵛᵃᵖ⁻ = max(Sᵉᵛᵃᵖ, 0), min(Sᵉᵛᵃᵖ, 0)
    Sˢᵘᵇˡ⁺, Sˢᵘᵇˡ⁻ = max(Sˢᵘᵇˡ, 0), min(Sˢᵘᵇˡ, 0)
    Sʳˢⁿᶜ = ifelse(is_warm, zero(Sʳˢⁿ), Sʳˢⁿ)

    fᵛ  = donor_limiter(qᵛ,  Sᵉᵛᵃᵖ⁺ + Sˢᵘᵇˡ⁺)
    fᶜˡ = donor_limiter(qᶜˡ, Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵃᶜᶜˡˢⁿ)
    fᶜⁱ = donor_limiter(qᶜⁱ, Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ)
    fʳ  = donor_limiter(qʳ,  -Sᵉᵛᵃᵖ⁻ + Sᵃᶜᶜʳⁱ + Sʳˢⁿᶜ)

    # Collected liquid supplies heat for the melt rate α Sᵃᶜᶜˡˢⁿ. Limit collection before
    # computing this melt demand, then cap all snow sinks against the available snow.
    Sᵃᶜᶜˡˢⁿ = fᶜˡ * Sᵃᶜᶜˡˢⁿ
    Sˢⁿʷ = ifelse(is_warm, α * Sᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T))
    fˢⁿ = donor_limiter(qˢⁿ, -Sˢᵘᵇˡ⁻ + Sᵐᵉˡᵗ + Sˢⁿʷ)

    Sᵉᵛᵃᵖ = fᵛ * Sᵉᵛᵃᵖ⁺ + fʳ * Sᵉᵛᵃᵖ⁻
    Sˢᵘᵇˡ = fᵛ * Sˢᵘᵇˡ⁺ + fˢⁿ * Sˢᵘᵇˡ⁻
    Sᵃᶜⁿᵛ, Sᵃᶜᶜ = fᶜˡ * Sᵃᶜⁿᵛ, fᶜˡ * Sᵃᶜᶜ
    Sᵃᶜⁿᵛⁱˢⁿ, Sᵃᶜᶜⁱˢⁿ, Sᵃᶜᶜⁱʳ = fᶜⁱ * Sᵃᶜⁿᵛⁱˢⁿ, fᶜⁱ * Sᵃᶜᶜⁱˢⁿ, fᶜⁱ * Sᵃᶜᶜⁱʳ
    Sᵃᶜᶜʳⁱ = fʳ * Sᵃᶜᶜʳⁱ
    Sᵐᵉˡᵗ = fˢⁿ * Sᵐᵉˡᵗ
    αSᵃᶜᶜˡˢⁿ = α * fˢⁿ * Sᵃᶜᶜˡˢⁿ
    Sʳˢⁿ = ifelse(is_warm, fˢⁿ, fʳ) * Sʳˢⁿ
    Sˢⁿʳ = fˢⁿ * Sˢⁿʳ

    ρqʳ_phys  = ρ * ( Sᵃᶜⁿᵛ + Sᵃᶜᶜ + Sᵉᵛᵃᵖ - Sᵃᶜᶜʳⁱ + Sᵐᵉˡᵗ
                     + ifelse(is_warm, Sᵃᶜᶜˡˢⁿ + αSᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T))
                     - ifelse(is_warm, zero(T), Sʳˢⁿ))
    ρqˢⁿ_phys = ρ * ( Sᵃᶜⁿᵛⁱˢⁿ + Sᵃᶜᶜⁱˢⁿ + Sᵃᶜᶜⁱʳ + Sᵃᶜᶜʳⁱ + Sˢᵘᵇˡ - Sᵐᵉˡᵗ
                     + ifelse(is_warm, zero(T), Sᵃᶜᶜˡˢⁿ + Sʳˢⁿ)
                     - ifelse(is_warm, αSᵃᶜᶜˡˢⁿ + Sˢⁿʳ + α * Sʳˢⁿ, zero(T)))

    # Negative precipitation (from transport) relaxes back toward zero, drawing on ρqᵉ.
    ρqʳ  = ifelse(qʳ  ≥ 0, ρqʳ_phys,  -ρ * qʳ  / τⁿᵘᵐ)
    ρqˢⁿ = ifelse(qˢⁿ ≥ 0, ρqˢⁿ_phys, -ρ * qˢⁿ / τⁿᵘᵐ)
    ρqᵉ  = -ρqʳ - ρqˢⁿ

    return (; ρqᵉ, ρqʳ, ρqˢⁿ)
end

@inline AM.microphysical_tendency(bμp::MP1M, ::Val{:ρqʳ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants) =
    mp1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqʳ

@inline AM.microphysical_tendency(bμp::MP1M, ::Val{:ρqˢⁿ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants) =
    mp1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqˢⁿ

@inline AM.microphysical_tendency(bμp::MP1M, ::Val{:ρqᵉ}, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants) =
    mp1m_tendencies(bμp, ρ, ℳ, 𝒰, constants).ρqᵉ

# Evaluate the bundle once for a request for several names (parcel models).
@inline function AM.microphysical_tendencies(bμp::MP1M, names::Tuple, ρ, ℳ::MixedPhaseOneMomentState, 𝒰, constants)
    G = mp1m_tendencies(bμp, ρ, ℳ, 𝒰, constants)
    return map(name -> getproperty(G, name), names)
end

# Fused kernel: evaluate the MP1M bundle once per cell and write all three tendencies.
@kernel function _compute_mp1m_tendencies!(Gρqᵉ, Gρqʳ, Gρqˢⁿ, grid, microphysics, dynamics, formulation,
                                           constants, specific_prognostic_moisture, microphysical_fields, velocities)
    i, j, k = @index(Global, NTuple)

    ρ_field = AM.total_density(dynamics)
    @inbounds ρ = ρ_field[i, j, k]
    @inbounds qᵉ = specific_prognostic_moisture[i, j, k]

    q = AM.grid_moisture_fractions(i, j, k, grid, microphysics, ρ, qᵉ, microphysical_fields)
    𝒰 = AM.diagnose_thermodynamic_state(i, j, k, grid, formulation, dynamics, q)
    U = (; w = ℑzᵃᵃᶜ(i, j, k, grid, velocities.w))  # only the vertical velocity is used (by the rain autoconversion)
    ℳ = AM.microphysical_state(microphysics, ρ, microphysical_fields_at(microphysical_fields, i, j, k), 𝒰, U)

    G = mp1m_tendencies(microphysics, ρ, ℳ, 𝒰, constants)

    @inbounds Gρqᵉ[i, j, k]  += G.ρqᵉ
    @inbounds Gρqʳ[i, j, k]  += G.ρqʳ
    @inbounds Gρqˢⁿ[i, j, k] += G.ρqˢⁿ
end

@inline microphysical_fields_at(μ, i, j, k) = @inbounds (; ρqʳ = μ.ρqʳ[i, j, k], ρqˢⁿ = μ.ρqˢⁿ[i, j, k])

function AM.compute_microphysical_tendencies!(microphysics::MP1M, model)
    grid = model.grid
    G = model.timestepper.Gⁿ
    launch!(grid.architecture, grid, :xyz, _compute_mp1m_tendencies!,
            G.ρqᵉ, G.ρqʳ, G.ρqˢⁿ, grid, microphysics, model.dynamics, model.formulation,
            model.thermodynamic_constants, AM.specific_prognostic_moisture(model),
            model.microphysical_fields, model.velocities)
    return nothing
end
