
#####
##### Benchmark utilities
#####

function memory_reclaim(arch)
    # Reclaim memory, so that next benchmarks will start from a clean state.
    if arch isa GPU{CUDABackend}
        CUDA.reclaim()
    elseif arch isa GPU{ROCBackend}
        AMDGPU.reclaim()
    end
end

reactant_compile_options() = Reactant.CompileOptions(raise = true,
                                                     raise_first = true,
                                                     sync = true)

"""
    benchmark_time_stepping(model;
                            time_steps = 100,
                            Δt = 0.05,
                            warmup_steps = 10,
                            name = "benchmark",
                            verbose = true,
                            advection::AbstractString = "",
                            closure::AbstractString = "",
                            dynamics::AbstractString = "",
                            microphysics::AbstractString = "",
                            backend::AbstractString = "vanilla",
                            ad::Bool = false,
                            checkpointing = true,
                            )

Run a benchmark by executing `time_steps` time steps of the given model.

If the model lives on a `ReactantState` architecture, the whole stepping loop
is traced with `Reactant.@trace` (see `step_loop!`) and compiled as a single
program with `Reactant.@compile` using `reactant_compile_options()` (raising,
with while-loop batch fission and while elementwise-reduction-to-reduce disabled) — compile time is recorded separately.
The compiled program is then executed once for warmup and once timed. The vanilla path drives `many_time_steps!`
directly through eager `time_step!`.

With `ad=true` (Reactant only) the forward+backward pass `grad_loss!` is
benchmarked instead, using `checkpointing` as the loop checkpointing strategy
for the reverse pass (`true`, `false`, `Reactant.Periodic(n)`, or
`Reactant.Binomial(budget)`; see `loss` in timestepping.jl).

Returns a `BenchmarkResult` containing timing information and system metadata.
"""
function benchmark_time_stepping(model;
                                 time_steps = 100,
                                 Δt = 0.05,
                                 warmup_steps = 10,
                                 name = "benchmark",
                                 verbose = true,
                                 advection::AbstractString = "",
                                 closure::AbstractString = "",
                                 dynamics::AbstractString = "",
                                 microphysics::AbstractString = "",
                                 backend::AbstractString = "vanilla",
                                 ad::Bool = false,
                                 checkpointing = true,
                                 )

    grid = model.grid
    arch = Oceananigans.Architectures.architecture(grid)
    FT = eltype(grid)
    Δt_FT = FT(Δt)
    Nx, Ny, Nz = size(grid)
    total_points = Nx * Ny * Nz
    is_reactant = arch isa ReactantState
    mode = ad ? "ad" : "forward"
    # `true` is Reactant's default for a static-bound loop, Periodic(isqrt(N));
    # resolve it here so the recorded strategy names the actual checkpoint count.
    checkpointing = checkpointing === true ? Reactant.Periodic(isqrt(time_steps)) : checkpointing
    checkpointing_str = ad ? checkpointing_label(checkpointing) : ""

    ad && !is_reactant && error("AD benchmark requires a Reactant backend (got $backend)")

    if verbose
        @info "Benchmark: $name"
        @info "  Architecture: $arch"
        @info "  Backend: $backend"
        @info "  Mode: $mode"
        ad && @info "  Checkpointing: $checkpointing_str"
        @info "  Float type: $FT"
        @info "  Grid size: $Nx × $Ny × $Nz ($total_points points)"
        @info "  Time step: $(Δt_FT) s"
        @info "  Warmup steps: $warmup_steps"
        @info "  Benchmark steps: $time_steps"
    end

    # Compile the stepping loop (or its forward+backward AD wrapper) up
    # front for Reactant; eager backends compile on first call. For AD we
    # build θ_init / dθ_init on the same grid as `model` and run reverse
    # mode through `loss` — see `grad_loss!` in timestepping.jl.
    # The compile is broken down into tracing / MLIR / XLA stages by `timed_reactant_compile`
    compile_timings = (total = 0.0, tracing = 0.0, mlir = 0.0, xla = 0.0)
    invoke! = nothing
    if is_reactant
        if ad
            θ_init  = CenterField(grid); set!(θ_init,  (args...) -> FT(300.0))
            dθ_init = CenterField(grid); set!(dθ_init, 0)
            dmodel  = Enzyme.make_zero(model)
            if verbose
                @info "  Compiling grad_loss!(model, dmodel, θ_init, dθ_init, Δt, $(time_steps), $(checkpointing)) with Reactant (raise=true)..."
            end
            compiled_grad!, compile_timings = timed_reactant_compile() do
                Reactant.@compile compile_options=reactant_compile_options() grad_loss!(
                    model, dmodel, θ_init, dθ_init, Δt_FT, time_steps, checkpointing)
            end
            invoke! = () -> compiled_grad!(model, dmodel, θ_init, dθ_init, Δt_FT, time_steps, checkpointing)
        else
            if verbose
                @info "  Compiling step_loop!(model, Δt, $(time_steps)) with Reactant (raise=true)..."
            end
            compiled_loop!, compile_timings = timed_reactant_compile() do
                Reactant.@compile compile_options=reactant_compile_options() step_loop!(model, Δt_FT, time_steps)
            end
            invoke! = () -> compiled_loop!(model, Δt_FT, time_steps)
        end
        if verbose
            @info "    Compile time: $(@sprintf("%.3f", compile_timings.total)) s"
        end
    end

    # Warmup phase. For Reactant we run one full execution of the compiled
    # program (which already encodes `time_steps` iterations); `warmup_steps`
    # only affects the vanilla path's eager loop.
    if verbose
        @info "  Running warmup..."
    end
    if is_reactant
        invoke!()
    else
        many_time_steps!(model, Δt_FT, warmup_steps)
    end

    # Synchronize device before timing
    synchronize_device(arch)

    # Benchmark phase
    if verbose
        @info "  Running benchmark..."
    end
    start_time = time_ns()
    if is_reactant
        invoke!()
    else
        many_time_steps!(model, Δt_FT, time_steps)
    end
    synchronize_device(arch)
    end_time = time_ns()

    total_time_seconds = (end_time - start_time) / 1e9
    time_per_step_seconds = total_time_seconds / time_steps
    steps_per_second = time_steps / total_time_seconds
    grid_points_per_second = total_points / time_per_step_seconds

    gpu_memory_used = arch isa GPU{CUDABackend} ? CUDACore.MemoryInfo().pool_used_bytes : 0
    metadata = BenchmarkMetadata(arch)

    result = BenchmarkResult(
        name,
        string(FT),
        String(advection),
        String(closure),
        String(dynamics),
        String(microphysics),
        String(backend),
        mode,
        checkpointing_str,
        (Nx, Ny, Nz),
        time_steps,
        Δt_FT,
        total_time_seconds,
        time_per_step_seconds,
        steps_per_second,
        grid_points_per_second,
        compile_timings.total,
        compile_timings.tracing,
        compile_timings.mlir,
        compile_timings.xla,
        gpu_memory_used,
        metadata,
    )

    verbose && log_benchmark_result(result)

    memory_reclaim(arch)

    return result
end

#####
##### Full simulation with output (for validation and longer runs)
#####

"""
    run_benchmark_simulation(model;
                             stop_time = 2hours,
                             Δt = 0.5,
                             output_interval = 10minutes,
                             output_dir = ".",
                             name = "benchmark_simulation",
                             output_fields = (:u, :v, :w, :θ),
                             verbose = true,
                             advection::AbstractString = "",
                             closure::AbstractString = "",
                             dynamics::AbstractString = "",
                             microphysics::AbstractString = "",
                             )

Run a full simulation with output writers for validation and longer benchmarks.

Based on the FastEddy CBL case (Sauer & Munoz-Esparza 2020), which runs for
approximately 2 hours to reach quasi-steady convective state.

# Arguments
- `model`: The AtmosphereModel to simulate

# Keyword Arguments
- `stop_time`: Total simulation time (default: 2 hours)
- `Δt`: Time step size (default: 0.5 s, suitable for production runs)
- `output_interval`: Interval between output snapshots (default: 10 minutes)
- `output_dir`: Directory for output files (default: current directory)
- `name`: Name for the simulation (used in output filename)
- `output_fields`: Tuple of field names to save (default: u, v, w, θ)
- `verbose`: Print progress information
- `advection`: Name of the advection scheme
- `closure`: Name of the closure
- `dynamics`: Name of the dynamics
- `microphysics`: Name of the microphysics

# Returns
A `SimulationResult` containing timing information and the output file path.
"""
function run_benchmark_simulation(model;
                                  stop_time = 2hours,
                                  Δt = 0.5,
                                  output_interval = 10minutes,
                                  output_dir = ".",
                                  name = "benchmark_simulation",
                                  output_fields = (:u, :v, :w, :θ),
                                  verbose = true,
                                  advection::AbstractString = "",
                                  closure::AbstractString = "",
                                  dynamics::AbstractString = "",
                                  microphysics::AbstractString = "",
                                  )

    grid = model.grid
    arch = Oceananigans.Architectures.architecture(grid)
    FT = eltype(grid)
    Nx, Ny, Nz = size(grid)
    total_points = Nx * Ny * Nz

    # Build output filename
    timestamp = Dates.format(now(UTC), "yyyy-mm-dd_HHMMSS")
    output_filename = joinpath(output_dir, "$(name)_$(timestamp).jld2")

    # Final snapshot filename
    final_filename = replace(output_filename, ".jld2" => "_final.jld2")

    if verbose
        @info "Benchmark Simulation: $name"
        @info "  Architecture: $arch"
        @info "  Float type: $FT"
        @info "  Grid size: $Nx × $Ny × $Nz ($total_points points)"
        @info "  Time step: $Δt s"
        @info "  Stop time: $(stop_time) s ($(stop_time / 3600) hours)"
        @info "  Output interval: $(output_interval) s ($(output_interval / 60) minutes)"
        @info "  Surface output: $output_filename (2D slices at z=0)"
        @info "  Final 3D snapshot: $final_filename"
    end

    # Create simulation
    simulation = Simulation(model; Δt, stop_time)

    # Add progress callback
    if verbose
        wall_time_ref = Ref(time_ns())
        function progress(sim)
            elapsed = (time_ns() - wall_time_ref[]) / 1e9
            wall_time_ref[] = time_ns()
            u_max = maximum(abs, sim.model.velocities.u)
            @info @sprintf("Time: %.1f/%.1f hours, Δt: %.2f s, max|u|: %.2f m/s, wall: %.1f s",
                           time(sim) / 3600, stop_time / 3600, sim.Δt, u_max, elapsed)
        end
        simulation.callbacks[:progress] = Callback(progress, TimeInterval(output_interval))
    end

    # Build outputs dictionary from field names
    outputs = Dict{Symbol, Any}()
    for field_name in output_fields
        if haskey(model.velocities, field_name)
            outputs[field_name] = model.velocities[field_name]
        elseif hasproperty(model, :tracers) && haskey(model.tracers, field_name)
            outputs[field_name] = model.tracers[field_name]
        elseif field_name == :θ
            # Potential temperature is a common diagnostic
            outputs[:θ] = model.thermodynamic_state.θ
        end
    end

    # Periodic output: only save the lowest level (2D slices) to reduce I/O cost
    simulation.output_writers[:surface] = JLD2Writer(model, outputs;
        filename = output_filename,
        indices = (:, :, 1),
        schedule = TimeInterval(output_interval),
        overwrite_existing = true
    )

    # Final snapshot: save full 3D fields at the end of the simulation
    simulation.output_writers[:final_3d] = JLD2Writer(model, outputs;
        filename = final_filename,
        schedule = IterationInterval(typemax(Int)),  # Never triggers during run
        overwrite_existing = true
    )

    # Add callback to write final 3D snapshot at end of simulation
    function save_final_snapshot(sim)
        @info "  Saving final 3D snapshot to: $final_filename"
        # Manually trigger the output writer
        Oceananigans.OutputWriters.write_output!(sim.output_writers[:final_3d], sim)
    end
    simulation.callbacks[:final_snapshot] = Callback(save_final_snapshot, SpecifiedTimes(stop_time))

    # Synchronize before timing
    synchronize_device(arch)

    if verbose
        @info "  Starting simulation..."
    end

    # Run simulation and time it
    start_time = time_ns()
    run!(simulation)
    synchronize_device(arch)
    end_time = time_ns()

    wall_time_seconds = (end_time - start_time) / 1e9
    time_steps = iteration(simulation)
    time_per_step_seconds = wall_time_seconds / time_steps
    steps_per_second = time_steps / wall_time_seconds
    grid_points_per_second = total_points / time_per_step_seconds

    gpu_memory_used = arch isa GPU{CUDABackend} ? CUDACore.MemoryInfo().pool_used_bytes : 0
    metadata = BenchmarkMetadata(arch)

    result = SimulationResult(
        name,
        string(FT),
        String(advection),
        String(closure),
        String(dynamics),
        String(microphysics),
        (Nx, Ny, Nz),
        FT(stop_time),
        time_steps,
        FT(Δt),
        wall_time_seconds,
        time_per_step_seconds,
        steps_per_second,
        grid_points_per_second,
        output_filename,
        gpu_memory_used,
        metadata,
    )

    if verbose
        @info "  Simulation complete!"
        @info "    Wall time: $(@sprintf("%.1f", wall_time_seconds)) s ($(@sprintf("%.2f", wall_time_seconds / 3600)) hours)"
        @info "    Time steps: $time_steps"
        @info "    Time per step: $(@sprintf("%.6f", time_per_step_seconds)) s"
        @info "    Grid points/s: $(@sprintf("%.2e", grid_points_per_second))"
        @info "    Surface timeseries: $output_filename"
        @info "    Final 3D snapshot: $final_filename"
        if arch isa GPU
            @info "    GPU memory usage: $(Base.format_bytes(gpu_memory_used))"
        end
    end

    memory_reclaim(arch)

    return result
end

#####
##### Device synchronization
#####

synchronize_device(::Oceananigans.Architectures.CPU) = nothing

function synchronize_device(::Oceananigans.Architectures.GPU{CUDABackend})
    CUDA.synchronize()
    return nothing
end

function synchronize_device(::Oceananigans.Architectures.GPU{ROCBackend})
    AMDGPU.synchronize()
    return nothing
end

function synchronize_device(::Oceananigans.Architectures.GPU{MetalBackend})
    Metal.synchronize()
    return nothing
end

"""
    timed_reactant_compile(compile)

Call `compile()`, a thunk wrapping `Reactant.@compile`, and return
`(compiled, timings)` where `timings` is a `NamedTuple` `(; total, tracing, mlir, xla)`
of times in seconds.
"""
function timed_reactant_compile(compile)
    compiled, timings = Reactant.Profiler.profile_compile_timings(compile)
    return compiled, (total   = timings.total_compile_time_μs / 1e6,
                      tracing = timings.tracing_time_μs / 1e6,
                      mlir    = timings.mlir_time_μs / 1e6,
                      xla     = timings.xla_time_μs / 1e6)
end

# Reactant compiled functions invoked via @compile sync=true block until
# completion on the underlying device, so no extra sync is required here.
synchronize_device(::ReactantState) = nothing
