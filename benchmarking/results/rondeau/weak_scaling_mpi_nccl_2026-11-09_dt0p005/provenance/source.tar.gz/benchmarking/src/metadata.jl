#####
##### System metadata
#####

struct BenchmarkMetadata
    julia_version::String
    oceananigans_version::String
    breeze_version::String
    architecture::String
    gpu_name::Union{String, Nothing}
    cuda_version::Union{String, Nothing}
    cpu_model::String
    num_threads::Int
    hostname::String
    package_versions::Dict{String, String}
    timestamp::DateTime
end

const TRACKED_PACKAGES = ("Oceananigans", "CUDA", "GPUCompiler", "LLVM", "Enzyme", "Reactant", "Reactant_jll")

function loaded_package_versions(names = TRACKED_PACKAGES)
    versions = Dict{String, String}()
    for (id, mod) in Base.loaded_modules
        id.name in names || continue
        version = pkgversion(mod)
        isnothing(version) || (versions[id.name] = string(version))
    end
    return versions
end

function BenchmarkMetadata(arch)
    gpu_name = nothing
    cuda_version = nothing

    # ReactantState targeting a CUDA GPU records the device the same way
    # as a direct CUDA backend.
    if arch isa GPU{CUDABackend} || (arch isa ReactantState && CUDA.functional())
        try
            gpu_name = CUDA.name(CUDA.device())
            cuda_version = string(CUDA.runtime_version())
        catch
            gpu_name = "Unknown GPU"
            cuda_version = "Unknown"
        end
    elseif arch isa GPU{ROCBackend}
        try
            gpu_name = unsafe_string(pointer(UInt8.(collect(AMDGPU.HIP.properties(AMDGPU.device()).name))))
        catch
            gpu_name = "Unknown GPU"
        end
        cuda_version = "unknown"
    elseif arch isa GPU{MetalBackend}
        gpu_name = string(Metal.device().name)
        cuda_version = "unknown"
    elseif arch isa ReactantState
        # Non-CUDA Reactant (e.g. TPU): label by the XLA platform ("TPU") so
        # these results aren't recorded with a `nothing` device.
        try
            gpu_name = uppercase(Reactant.XLA.platform_name(Reactant.XLA.default_backend()))
        catch
            gpu_name = "Reactant"
        end
    end

    # Get CPU model
    cpu_model = "$(Sys.cpu_info()[1].model) ($(Sys.CPU_NAME))"

    return BenchmarkMetadata(
        string(VERSION),
        string(pkgversion(Oceananigans)),
        string(pkgversion(Breeze)),
        string(typeof(arch)),
        gpu_name,
        cuda_version,
        cpu_model,
        Threads.nthreads(),
        gethostname(),
        loaded_package_versions(),
        now(UTC)
    )
end

function Base.show(io::IO, ::MIME"text/plain", m::BenchmarkMetadata)
    println(io, "BenchmarkMetadata")
    println(io, "├── julia_version: ", m.julia_version)
    println(io, "├── oceananigans_version: ", m.oceananigans_version)
    println(io, "├── breeze_version: ", m.breeze_version)
    println(io, "├── architecture: ", m.architecture)
    if !isnothing(m.gpu_name)
        println(io, "├── gpu_name: ", m.gpu_name)
        println(io, "├── cuda_version: ", m.cuda_version)
    end
    println(io, "├── cpu_model: ", m.cpu_model)
    println(io, "├── num_threads: ", m.num_threads)
    println(io, "├── hostname: ", m.hostname)
    for name in sort!(collect(keys(m.package_versions)))
        println(io, "├── ", name, ": ", m.package_versions[name])
    end
    print(io,   "└── timestamp: ", m.timestamp)
end
