"""
Julia package for finite-volume GPU and CPU large eddy simulations (LES)
of atmospheric flows. The abstractions, design, and finite-volume engine
are based on Oceananigans.
"""
module Breeze

export
    # AtmosphereModel
    MoistAirBuoyancy,
    ThermodynamicConstants,
    ReferenceState,
    ExnerReferenceState,
    compute_reference_state!,
    set_to_mean!,
    surface_density,
    AnelasticDynamics,
    AnelasticModel,
    CompressibleDynamics,
    CompressibleModel,
    SplitExplicitTimeDiscretization,
    AcousticOuterScheme,
    WickerSkamarock3,
    AcousticSubstepDistribution,
    ProportionalSubsteps,
    MonolithicFirstStage,
    AcousticDampingStrategy,
    NoDivergenceDamping,
    ThermalDivergenceDamping,
    DirectDivergenceDamping,
    UpperSponge,
    AbstractRamp,
    LinearRamp,
    CubicRamp,
    Sin2Ramp,
    GaussianRamp,
    ExplicitTimeStepping,
    balance_adiabatically!,
    AdiabaticBalancer,
    HydrostaticallyBalancedDensity,
    PrescribedDensity,
    PrescribedDynamics,
    KinematicModel,
    AtmosphereModel,
    SingleColumnGrid,
    StaticEnergyFormulation,
    LiquidIcePotentialTemperatureFormulation,
    VaporEquivalentExponent,
    DryExponent,
    RadiativeTransferModel,
    BackgroundAtmosphere,
    standard_ozone_profile,
    GrayOptics,
    ClearSkyOptics,
    AllSkyOptics,
    EcCKDOptics,
    CloudScatteringTables,
    OverlyingAtmosphereColumn,
    standard_atmosphere_temperature,
    AbstractSolarPosition,
    ApparentSolarPosition,
    DiurnalSolarPosition,
    FixedCosineZenith,
    ConstantRadiusParticles,
    TemperatureField,
    IdealGas,
    CondensedPhase,
    mixture_gas_constant,
    mixture_heat_capacity,
    continuity_density,
    dynamics_pressure,
    total_density,

    # Advective timescale control for the time-step wizard
    CellAdvectionTimescale,
    HorizontalFormulation,
    ThreeDimensionalFormulation,

    # Diagnostics
    compute_hydrostatic_pressure!,
    PotentialTemperature,
    VirtualPotentialTemperature,
    EquivalentPotentialTemperature,
    StabilityEquivalentPotentialTemperature,
    LiquidIcePotentialTemperature,
    StaticEnergy,
    azimuthal_mean,
    azimuthal_mean!,
    static_energy_density,
    static_energy,
    total_energy,
    total_energy_density_name,
    liquid_ice_potential_temperature_density,
    liquid_ice_potential_temperature,
    precipitation_rate,
    bottom_precipitation_flux,
    precipitation_flux,
    MicrophysicalProcessRate,
    total_pressure,
    specific_humidity,
    moisture_prognostic_name,
    total_moisture_density_name,
    moisture_specific_name,
    specific_prognostic_moisture,

    # Solvers
    NewtonSolver,
    SecantSolver,
    FixedIterations,

    # Thermodynamics
    temperature,
    supersaturation,
    saturation_specific_humidity,
    adiabatic_hydrostatic_density,
    dry_air_gas_constant,
    vapor_gas_constant,
    PlanarLiquidSurface,
    PlanarIceSurface,

    # Microphysics
    aerosol_field_names,
    prognostic_field_names,
    SaturationAdjustment,
    InstantaneousPrecipitation,
    MixedPhaseEquilibrium,
    WarmPhaseEquilibrium,
    SaturationSpecificHumidity,
    SaturationSpecificHumidityField,
    DewpointTemperature,
    DewpointTemperatureField,
    equilibrium_saturation_specific_humidity,
    RelativeHumidity,
    RelativeHumidityField,
    Supersaturation,
    SupersaturationField,
    number_concentration,
    number_concentration_field,
    BulkMicrophysics,
    initial_aerosol_number,
    initial_aerosol_number_density,
    compute_hydrostatic_pressure!,
    NonEquilibriumCloudFormation,
    ConstantRateCondensateFormation,
    P3Microphysics,
    PredictedParticlePropertiesMicrophysics,
    DiagnosticVaporExcess,
    PrognosticVaporExcess,
    PrognosticLiquidFraction,
    NoLiquidFraction,

    # BoundaryConditions
    BulkDrag,
    BulkSensibleHeatFlux,
    BulkVaporFlux,
    PolynomialCoefficient,
    FittedStabilityFunction,
    FilteredSurfaceVelocities,
    FilteredSurfaceScalar,
    TKEGustiness,
    default_neutral_drag_polynomial,
    default_neutral_sensible_heat_polynomial,
    default_neutral_latent_heat_polynomial,

    # Forcing utilities
    geostrophic_forcings,
    SubsidenceForcing,
    SpecificForcing,
    TemperatureForcing,

    # Grid utilities
    PiecewiseStretchedDiscretization,
    TerrainFollowingVerticalDiscretization,
    LinearDecay,
    TwoLevelDecay,
    materialize_terrain!,
    build_terrain_metrics,
    TerrainMetrics,
    SlopeOutsideInterpolation,
    SlopeInsideInterpolation,

    # TimeSteppers
    SSPRungeKutta3,
    AcousticRungeKutta3,
    AcousticSubstepper,
    RoundToNearest,
    StochasticRounding,

    # ParcelDynamics
    ParcelDynamics,
    ParcelModel,
    ParcelState,
    PrescribedVerticalVelocity,
    PrognosticVerticalVelocity

using Oceananigans: Oceananigans, @at, AnisotropicMinimumDissipation, Average,
                    AveragedTimeInterval, BackgroundField, BetaPlane, Bounded, BoundaryConditionOperation,
                    CPU, Callback, Center, CenterField, Centered, Checkpointer, Clock,
                    ConstantCartesianCoriolis, Distributed, DynamicSmagorinsky,
                    ExponentialDiscretization, FPlane, Face, Field, FieldBoundaryConditions,
                    FieldDataset, FieldTimeSeries, Flat, FluxBoundaryCondition, Forcing,
                    Relaxation, GaussianMask, GPU,
                    GradientBoundaryCondition, GridFittedBottom,
                    HydrostaticSphericalCoriolis,
                    ImmersedBoundaryCondition, ImmersedBoundaryGrid, InMemory,
                    Integral, IterationInterval, JLD2Writer,
                    KernelFunctionOperation, LagrangianParticles,
                    LatitudeLongitudeGrid, NetCDFWriter,
                    NonTraditionalBetaPlane, OnDisk, NormalFlowBoundaryCondition,
                    PartialCellBottom, Partition, Periodic,
                    PerturbationAdvection, RectilinearGrid, Simulation,
                    SphericalCoriolis,
                    SmagorinskyLilly, SpecifiedTimes, TimeInterval,
                    UpwindBiased, ValueBoundaryCondition, WENO, FluxFormAdvection,
                    WallTimeInterval, XFaceField, YFaceField, ZFaceField,
                    add_callback!, compute!, conjure_time_step_wizard!,
                    interior, iteration, minimum_xspacing, minimum_yspacing,
                    minimum_zspacing, nodes, prettytime, regrid!, run!, set!,
                    time_step!, xnodes, xspacings, ynodes, yspacings, znodes,
                    zspacings, ∂x, ∂y, ∂z

using Oceananigans.Grids: znode, MutableVerticalDiscretization
using Oceananigans.BoundaryConditions: ImpenetrableBoundaryCondition
# Reused to select the direction of `CellAdvectionTimescale` (see AtmosphereModels/cell_advection_timescale.jl)
using Oceananigans.TurbulenceClosures: HorizontalFormulation, ThreeDimensionalFormulation

export
    CPU, GPU,
    Center, Face, Periodic, Bounded, Flat,
    RectilinearGrid, LatitudeLongitudeGrid, ExponentialDiscretization, PiecewiseStretchedDiscretization, MutableVerticalDiscretization, Clock,
    nodes, xnodes, ynodes, znodes,
    znode,
    xspacings, yspacings, zspacings,
    minimum_xspacing, minimum_yspacing, minimum_zspacing,
    ImmersedBoundaryGrid, GridFittedBottom, PartialCellBottom, ImmersedBoundaryCondition,
    Distributed, Partition,
    Centered, UpwindBiased, WENO, FluxFormAdvection,
    FluxBoundaryCondition, ValueBoundaryCondition, GradientBoundaryCondition, ImpenetrableBoundaryCondition,
    NormalFlowBoundaryCondition, PerturbationAdvection, FieldBoundaryConditions,
    BoundaryConditionOperation,
    Field, CenterField, XFaceField, YFaceField, ZFaceField,
    Average, Integral,
    BackgroundField, interior, set!, compute!, regrid!,
    Forcing, Relaxation, GaussianMask,
    FPlane, ConstantCartesianCoriolis, BetaPlane, NonTraditionalBetaPlane,
    SphericalCoriolis, HydrostaticSphericalCoriolis,
    SmagorinskyLilly, AnisotropicMinimumDissipation, DynamicSmagorinsky,
    TKEBasedTurbulenceClosure, AbstractMixingLength, LocalMinimumMixingLength, IntegralMixingLength,
    GradientLimitedMixingLength, ConstantStabilityFunctions,
    RationalStabilityFunction,
    DryStaticStability, MoistStaticStability,
    LagrangianParticles,
    conjure_time_step_wizard!,
    time_step!, Simulation, run!, Callback, add_callback!, iteration,
    NetCDFWriter, JLD2Writer, Checkpointer,
    TimeInterval, IterationInterval, WallTimeInterval, AveragedTimeInterval, SpecifiedTimes,
    FieldTimeSeries, FieldDataset, InMemory, OnDisk,
    ∂x, ∂y, ∂z, @at, KernelFunctionOperation,
    prettytime

include("Utils.jl")
using .Utils

include("Solvers.jl")
using .Solvers

include("RoundingTreatments.jl")
using .RoundingTreatments

include("Thermodynamics/Thermodynamics.jl")
using .Thermodynamics

include("MoistAirBuoyancies.jl")
using .MoistAirBuoyancies

# Solar geometry, needed by the radiation interface in AtmosphereModels
include("CelestialMechanics/CelestialMechanics.jl")
using .CelestialMechanics

include("AtmosphereModels/AtmosphereModels.jl")
using .AtmosphereModels

# BoundaryConditions is loaded early so formulation modules can use BC conversion utilities
include("BoundaryConditions/BoundaryConditions.jl")
using .BoundaryConditions

# Thermodynamic formulation modules (included after AtmosphereModels so they can dispatch on AtmosphereModel)
include("StaticEnergyFormulations/StaticEnergyFormulations.jl")
using .StaticEnergyFormulations: StaticEnergyFormulation

include("PotentialTemperatureFormulations/PotentialTemperatureFormulations.jl")
using .PotentialTemperatureFormulations: LiquidIcePotentialTemperatureFormulation

# TerrainFollowingDiscretization (needed by CompressibleEquations for terrain physics)
include("TerrainFollowingDiscretization/TerrainFollowingDiscretization.jl")
using .TerrainFollowingDiscretization

# Dynamics modules (included after AtmosphereModels so they can dispatch on AtmosphereModel)
include("AnelasticEquations/AnelasticEquations.jl")
using .AnelasticEquations: AnelasticDynamics, AnelasticModel

include("CompressibleEquations/CompressibleEquations.jl")
using .CompressibleEquations: CompressibleDynamics, CompressibleModel, AcousticSubstepper,
                              SplitExplicitTimeDiscretization,
                              AcousticOuterScheme, WickerSkamarock3,
                              AcousticSubstepDistribution, ProportionalSubsteps, MonolithicFirstStage,
                              AcousticDampingStrategy, NoDivergenceDamping, ThermalDivergenceDamping, DirectDivergenceDamping,
                              UpperSponge,
                              AbstractRamp, LinearRamp, CubicRamp, Sin2Ramp, GaussianRamp,
                              ExplicitTimeStepping

include("KinematicDriver/KinematicDriver.jl")
using .KinematicDriver: PrescribedDensity, PrescribedDynamics, KinematicModel

include("TimeSteppers/TimeSteppers.jl")
using .TimeSteppers

include("ParcelModels/ParcelModels.jl")
using .ParcelModels

include("Microphysics/Microphysics.jl")
using .Microphysics

include("TurbulenceClosures/TurbulenceClosures.jl")
using .TurbulenceClosures

include("Advection.jl")
using .Advection

include("Forcings/Forcings.jl")
using .Forcings

include("VerticalGrids.jl")
using .VerticalGrids

# Loaded last: single-column / column-ensemble mode extends the dynamics, closure, and model modules.
include("single_column_mode.jl")
using .SingleColumnMode: SingleColumnMode, SingleColumnGrid

end # module Breeze
