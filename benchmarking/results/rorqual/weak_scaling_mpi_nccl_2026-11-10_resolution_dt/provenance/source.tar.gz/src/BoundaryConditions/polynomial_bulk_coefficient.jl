#####
##### PolynomialCoefficient: Wind and stability-dependent transfer coefficients
#####

# Default neutral polynomials (a₀, a₁, a₂) from Large & Yeager (2009),
# "The global climatology of an interannually varying air–sea flux data set",
# Climate Dynamics 33(2), 341–364.
# The polynomial evaluates to the transfer coefficient itself; Large and Yeager (2009) publish
# their coefficients in units of 10⁻³ — (0.142, 0.076, 2.7) for drag and so on — so the defaults
# carry the scaling explicitly. Exact decimal literals, rather than `.* 1e-3`, keep the stored
# values round-tripping cleanly through `show`.
const default_neutral_drag_polynomial            = (1.42e-4, 7.6e-5, 2.7e-3)
const default_neutral_sensible_heat_polynomial   = (1.28e-4, 6.8e-5, 2.43e-3)
const default_neutral_latent_heat_polynomial     = (1.2e-4,  7.0e-5, 2.55e-3)

#####
##### StabilityFunction: Ψ function constants
#####

struct StabilityFunction{FT}
    γᴰ :: FT
    γᵀ :: FT
    a :: FT
    b :: FT
    c :: FT
    d :: FT
end

"""
    StabilityFunction(FT = Oceananigans.defaults.FloatType;
                      γᴰ = 19.3, γᵀ = 11.6, a = 1, b = 2/3, c = 5, d = 0.35)

Parameters for the integrated Monin-Obukhov stability functions ``Ψ^D(ζ)``
and ``Ψ^T(ζ)``.

Note: we use superscript D (drag/momentum) and T (temperature/scalar) to match the
transfer coefficient notation ``Cᴰ``, ``Cᵀ`` established in `notation.md`.
In the literature these are commonly written ``Ψ_m`` and ``Ψ_h``.

For unstable conditions (``ζ < 0``), uses [Hogström (1996)](@cite hogstrom1996review):
- ``φ^D = (1 - γ^D ζ)^{-1/4}``
- ``φ^T = 0.95(1 - γ^T ζ)^{-1/2}``

For stable conditions (``ζ ≥ 0``), uses [Beljaars & Holtslag (1991)](@cite beljaars1991flux):
- ``Ψ^D = -[a ζ + b (ζ - c/d) e^{-dζ} + bc/d]``
- ``Ψ^T = -[(1 + 2aζ/3)^{3/2} + b (ζ - c/d) e^{-dζ} + bc/d - 1]``

# References

* Beljaars, A. C. M., & Holtslag, A. A. M. (1991). Flux parameterization over land surfaces
  for atmospheric models. Journal of Applied Meteorology, 30, 327-341.
* Hogström, U. L. F. (1996). Review of some basic characteristics of the atmospheric surface layer.
  Boundary-Layer Meteorology, 78, 215-246.
"""
function StabilityFunction(FT = Oceananigans.defaults.FloatType;
                           γᴰ = 19.3, γᵀ = 11.6, a = 1, b = 2/3, c = 5, d = 0.35)
    return StabilityFunction{FT}(FT(γᴰ), FT(γᵀ), FT(a), FT(b), FT(c), FT(d))
end

#####
##### RichardsonNumberMapping: Li et al. (2010) regression coefficients
#####

struct RichardsonNumberMapping{FT}
    # Regime thresholds
    stable_unstable_transition :: FT
    strongly_stable_transition :: FT

    # Unstable regime (Eq. 12)
    aᵘ₁₁ :: FT
    bᵘ₁₁ :: FT
    bᵘ₁₂ :: FT
    aᵘ₂₁ :: FT
    aᵘ₂₂ :: FT
    bᵘ₃₁ :: FT
    bᵘ₃₂ :: FT
    bᵘ₃₃ :: FT

    # Weakly stable regime (Eq. 14)
    aʷ₁₁ :: FT
    aʷ₁₂ :: FT
    aʷ₂₁ :: FT
    aʷ₂₂ :: FT
    bʷ₁₁ :: FT
    bʷ₁₂ :: FT
    bʷ₂₁ :: FT
    bʷ₂₂ :: FT

    # Strongly stable regime (Eq. 16)
    aˢ₁₁ :: FT
    aˢ₂₁ :: FT
    bˢ₁₁ :: FT
    bˢ₂₁ :: FT
    bˢ₂₂ :: FT
end

"""
    RichardsonNumberMapping(FT = Oceananigans.defaults.FloatType;
                            stable_unstable_transition = 0,
                            strongly_stable_transition = 0.2,
                            aᵘ₁₁ =  0.0450, bᵘ₁₁ =  0.0030, bᵘ₁₂ =  0.0059,
                            aᵘ₂₁ = -0.0828, aᵘ₂₂ =  0.8845,
                            bᵘ₃₁ =  0.1739, bᵘ₃₂ = -0.9213, bᵘ₃₃ = -0.1057,
                            aʷ₁₁ =  0.5738, aʷ₁₂ = -0.4399,
                            aʷ₂₁ = -4.901,  aʷ₂₂ = 52.50,
                            bʷ₁₁ = -0.0539, bʷ₁₂ =  1.540,
                            bʷ₂₁ = -0.6690, bʷ₂₂ = -3.282,
                            aˢ₁₁ =  0.7529, aˢ₂₁ = 14.94,
                            bˢ₁₁ =  0.1569, bˢ₂₁ = -0.3091, bˢ₂₂ = -1.303)

Regression coefficients for the non-iterative mapping from bulk Richardson number
``Riᴮ`` to the Monin-Obukhov stability parameter ``ζ = z/L``, following
[Li et al. (2010)](@cite Li2010).

The superscripts u, w, s denote unstable, weakly stable, and strongly stable
regimes respectively. Subscript indices follow the original paper.

Three regimes:
- **Unstable** (``Riᴮ <`` `stable_unstable_transition`): Eq. (12)
- **Weakly stable** (`stable_unstable_transition` ``≤ Riᴮ ≤`` `strongly_stable_transition`): Eq. (14)
- **Strongly stable** (``Riᴮ >`` `strongly_stable_transition`): Eq. (16)

# References

* Li, Y., Gao, Z., Lenschow, D. H., & Chen, F. (2010). An improved approach for
  parameterizing surface-layer turbulent transfer coefficients in numerical models.
  Boundary-Layer Meteorology, 137, 153-165.
"""
function RichardsonNumberMapping(FT = Oceananigans.defaults.FloatType;
                                 stable_unstable_transition = 0,
                                 strongly_stable_transition = 0.2,
                                 aᵘ₁₁ =  0.0450, bᵘ₁₁ =  0.0030, bᵘ₁₂ =  0.0059,
                                 aᵘ₂₁ = -0.0828, aᵘ₂₂ =  0.8845,
                                 bᵘ₃₁ =  0.1739, bᵘ₃₂ = -0.9213, bᵘ₃₃ = -0.1057,
                                 aʷ₁₁ =  0.5738, aʷ₁₂ = -0.4399,
                                 aʷ₂₁ = -4.901,  aʷ₂₂ = 52.50,
                                 bʷ₁₁ = -0.0539, bʷ₁₂ =  1.540,
                                 bʷ₂₁ = -0.6690, bʷ₂₂ = -3.282,
                                 aˢ₁₁ =  0.7529, aˢ₂₁ = 14.94,
                                 bˢ₁₁ =  0.1569, bˢ₂₁ = -0.3091, bˢ₂₂ = -1.303)
    return RichardsonNumberMapping{FT}(
        FT(stable_unstable_transition), FT(strongly_stable_transition),
        FT(aᵘ₁₁), FT(bᵘ₁₁), FT(bᵘ₁₂), FT(aᵘ₂₁), FT(aᵘ₂₂), FT(bᵘ₃₁), FT(bᵘ₃₂), FT(bᵘ₃₃),
        FT(aʷ₁₁), FT(aʷ₁₂), FT(aʷ₂₁), FT(aʷ₂₂), FT(bʷ₁₁), FT(bʷ₁₂), FT(bʷ₂₁), FT(bʷ₂₂),
        FT(aˢ₁₁), FT(aˢ₂₁), FT(bˢ₁₁), FT(bˢ₂₁), FT(bˢ₂₂))
end

#####
##### FittedStabilityFunction
#####

struct FittedStabilityFunction{FT, RM, SP}
    scalar_roughness_length :: FT
    richardson_number_mapping :: RM
    stability_function :: SP
end

"""
    FittedStabilityFunction(scalar_roughness_length;
                            richardson_number_mapping = RichardsonNumberMapping(typeof(scalar_roughness_length)),
                            stability_function = StabilityFunction(typeof(scalar_roughness_length)))

Stability correction based on Monin-Obukhov similarity theory using the
[Li et al. (2010)](@cite Li2010) analytical mapping from bulk Richardson
number to the stability parameter ``ζ = z/L``.

Uses [Hogström (1996)](@cite hogstrom1996review) integrated stability functions
for unstable conditions and [Beljaars & Holtslag (1991)](@cite beljaars1991flux)
for stable conditions.

Applies structurally correct (and different) corrections for momentum vs scalar transfer:
- Momentum: ``Cᴰ = Cᴰ_N [α / (α - Ψᴰ)]²``
- Scalar:   ``Cᵀ = Cᵀ_N [α / (α - Ψᴰ)] [β_h / (β_h - Ψᵀ)]``

where ``α = \\ln(z/ℓʳ)``, ``β_h = \\ln(z/ℓʳ_h)``.

`FittedStabilityFunction` is callable: `sf(Riᴮ, α, β)` returns the momentum
stability correction factor, and `sf(Riᴮ, α, β, Val(:scalar))` returns the
scalar correction factor.

# Arguments
- `scalar_roughness_length`: Roughness length for heat/moisture ``ℓʳ_h`` (m).

# Keyword Arguments
- `richardson_number_mapping`: [`RichardsonNumberMapping`](@ref) coefficients (default: [Li et al. (2010)](@cite Li2010)).
- `stability_function`: [`StabilityFunction`](@ref) (default: [Hogström (1996)](@cite hogstrom1996review) / [Beljaars & Holtslag (1991)](@cite beljaars1991flux)).

# References

* Beljaars, A. C. M., & Holtslag, A. A. M. (1991). Flux parameterization over land surfaces
  for atmospheric models. Journal of Applied Meteorology, 30, 327-341.
* Hogström, U. L. F. (1996). Review of some basic characteristics of the atmospheric surface layer.
  Boundary-Layer Meteorology, 78, 215-246.
* Li, Y., Gao, Z., Lenschow, D. H., & Chen, F. (2010). An improved approach for
  parameterizing surface-layer turbulent transfer coefficients in numerical models.
  Boundary-Layer Meteorology, 137, 153-165.
"""
function FittedStabilityFunction(scalar_roughness_length;
                                 richardson_number_mapping = RichardsonNumberMapping(typeof(scalar_roughness_length)),
                                 stability_function = StabilityFunction(typeof(scalar_roughness_length)))
    return FittedStabilityFunction(scalar_roughness_length,
                                   richardson_number_mapping,
                                   stability_function)
end

Base.summary(::FittedStabilityFunction) = "FittedStabilityFunction (Li et al. 2010)"

function Base.show(io::IO, sf::FittedStabilityFunction)
    println(io, "FittedStabilityFunction (Li et al. 2010)")
    println(io, "├── scalar_roughness_length: ", sf.scalar_roughness_length, " m")
    println(io, "├── Riᴮ → ζ mapping: Li et al. (2010)")
    println(io, "├── Unstable Ψᴰ, Ψᵀ: Hogström (1996)")
    print(io,   "└── Stable Ψᴰ, Ψᵀ: Beljaars & Holtslag (1991)")
end

# Callable interface: compute stability correction factor
@inline function (sf::FittedStabilityFunction)(Riᴮ, α, β, transfer_type=Val(:momentum))
    ζ = bulk_to_flux_richardson_number(Riᴮ, α, β, sf.richardson_number_mapping)
    Ψᴰ = integrated_stability_momentum(ζ, sf.stability_function)
    Ψᵀ = integrated_stability_scalar(ζ, sf.stability_function)
    return stability_correction_factor(α, β, Ψᴰ, Ψᵀ, transfer_type)
end

#####
##### Li et al. (2010) bulk Richardson number to flux Richardson number mapping
#####

"""
$(TYPEDSIGNATURES)

Map bulk Richardson number ``Riᴮ`` to the Monin-Obukhov stability parameter
``ζ = z/L`` using the regression equations of Li et al. (2010).

# Arguments
- `Riᴮ`: Bulk Richardson number
- `α`: ``\\ln(z / ℓʳ)``
- `β`: ``\\ln(ℓʳ / ℓʳ_h)``
- `mapping`: [`RichardsonNumberMapping`](@ref) with regression coefficients
"""
@inline function bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    ζ⁻ = unstable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    ζʷ = weakly_stable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    ζˢ = strongly_stable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    return ifelse(Riᴮ < mapping.stable_unstable_transition,
                  ζ⁻,
                  ifelse(Riᴮ ≤ mapping.strongly_stable_transition, ζʷ, ζˢ))
end

# Unstable regime (Riᴮ < 0), Li et al. (2010) Eq. 12. The fit is a parabola in Riᴮ that is monotonic
# only above its vertex Riᴮ = -B / 2A: below it ζ turns back towards zero and, for Riᴮ < -B / A, becomes
# positive, so that light winds over a warm surface (free convection, Riᴮ ≪ 0) would be treated as strongly
# stable and the transfer coefficients would collapse to zero. ζ is held at its vertex value beyond it.
@inline function unstable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    A = mapping.aᵘ₁₁ * α
    B = (mapping.bᵘ₁₁ * β + mapping.bᵘ₁₂) * α^2 +
        (mapping.aᵘ₂₁ * β + mapping.aᵘ₂₂) * α +
        (mapping.bᵘ₃₁ * β^2 + mapping.bᵘ₃₂ * β + mapping.bᵘ₃₃)
    Ri = max(Riᴮ, - B / (2A))
    return A * Ri^2 + B * Ri
end

# Weakly stable regime (0 ≤ Riᴮ ≤ Ri*), Li et al. (2010) Eq. 14
@inline function weakly_stable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    A = (mapping.aʷ₁₁ * β + mapping.aʷ₁₂) * α + (mapping.aʷ₂₁ * β + mapping.aʷ₂₂)
    B = (mapping.bʷ₁₁ * β + mapping.bʷ₁₂) * α + (mapping.bʷ₂₁ * β + mapping.bʷ₂₂)
    return A * Riᴮ^2 + B * Riᴮ
end

# Strongly stable regime (Riᴮ > Ri*), Li et al. (2010) Eq. 16
@inline function strongly_stable_bulk_to_flux_richardson_number(Riᴮ, α, β, mapping)
    return (mapping.aˢ₁₁ * α + mapping.aˢ₂₁) * Riᴮ +
            mapping.bˢ₁₁ * α + mapping.bˢ₂₁ * β + mapping.bˢ₂₂
end

#####
##### Integrated MOST stability functions
#####

"""
$(TYPEDSIGNATURES)

Integrated stability function for momentum ``Ψᴰ(ζ)``.

Note: ``Ψᴰ`` corresponds to ``Ψ_m`` in the literature.
"""
@inline function integrated_stability_momentum(ζ, params)
    FT = typeof(ζ)
    Ψ⁻ = unstable_Ψᴰ(ζ, params)
    Ψ⁺ = stable_Ψᴰ(ζ, params)
    return ifelse(ζ < zero(FT), Ψ⁻, Ψ⁺)
end

"""
$(TYPEDSIGNATURES)

Integrated stability function for scalars (heat, moisture) ``Ψᵀ(ζ)``.

Note: ``Ψᵀ`` corresponds to ``Ψ_h`` in the literature.
"""
@inline function integrated_stability_scalar(ζ, params)
    FT = typeof(ζ)
    Ψ⁻ = unstable_Ψᵀ(ζ, params)
    Ψ⁺ = stable_Ψᵀ(ζ, params)
    return ifelse(ζ < zero(FT), Ψ⁻, Ψ⁺)
end

# Hogström (1996) unstable Ψᴰ: φᴰ = (1 - γᴰ ζ)^{-1/4}
@inline function unstable_Ψᴰ(ζ, params)
    FT = typeof(ζ)
    x = sqrt(sqrt(max(1 - params.γᴰ * ζ, zero(FT))))
    return 2 * log((1 + x) / 2) + log((1 + x^2) / 2) - 2 * atan(x) + FT(π) / 2
end

# Hogström (1996) unstable Ψᵀ: φᵀ = 0.95(1 - γᵀ ζ)^{-1/2}
@inline function unstable_Ψᵀ(ζ, params)
    FT = typeof(ζ)
    y = sqrt(max(1 - params.γᵀ * ζ, zero(FT)))
    return 2 * log((1 + y) / 2)
end

# Beljaars & Holtslag (1991) stable Ψᴰ
@inline function stable_Ψᴰ(ζ, params)
    (; a, b, c, d) = params
    return -(a * ζ + b * (ζ - c / d) * exp(-d * ζ) + b * c / d)
end

# Beljaars & Holtslag (1991) stable Ψᵀ
@inline function stable_Ψᵀ(ζ, params)
    FT = typeof(ζ)
    (; a, b, c, d) = params
    x = max(1 + 2 * a / 3 * ζ, zero(FT))
    return -(x * sqrt(x) + b * (ζ - c / d) * exp(-d * ζ) + b * c / d - 1)
end

#####
##### Stability correction factors for momentum and scalar transfer
#####

@inline function stability_correction_factor(α, β, Ψᴰ, Ψᵀ, ::Val{:momentum})
    denominator_D = max(α - Ψᴰ, α / 10)
    return (α / denominator_D)^2
end

@inline function stability_correction_factor(α, β, Ψᴰ, Ψᵀ, ::Val{:scalar})
    βh = α + β
    denominator_D = max(α - Ψᴰ, α / 10)
    denominator_T = max(βh - Ψᵀ, βh / 10)
    return (α / denominator_D) * (βh / denominator_T)
end

# Default to momentum when transfer_type is not set
@inline stability_correction_factor(α, β, Ψᴰ, Ψᵀ, ::Nothing) =
    stability_correction_factor(α, β, Ψᴰ, Ψᵀ, Val(:momentum))

#####
##### PolynomialCoefficient struct
#####

"""
$(TYPEDSIGNATURES)

The virtual potential temperature a stability-dependent bulk boundary condition compares against
its surface value, evaluated from the model field tuple the boundary-condition kernel is handed
rather than from fields captured at construction.

Boundary conditions are materialized before the dynamics is, so there are no model fields to
capture at that point; deferring the read is what lets a compressible model's stability correction
follow its prognostic pressure and density. The `T` entry comes from
`AtmosphereModels.auxiliary_model_fields` and the `p` and `ρ` entries from
`AtmosphereModels.dynamics_thermodynamic_fields`, which the caller has merged into one tuple by
this point, so this reads the same thermodynamic pressure the rest of the model does: prognostic
under `CompressibleDynamics`, the hydrostatic reference profile under `AnelasticDynamics`.
"""
struct NearWallVirtualPotentialTemperature{M, N, FT, TC}
    microphysics :: M
    specific_moisture_name :: N
    standard_pressure :: FT
    thermodynamic_constants :: TC
end

Adapt.adapt_structure(to, θᵥ::NearWallVirtualPotentialTemperature) =
    NearWallVirtualPotentialTemperature(Adapt.adapt(to, θᵥ.microphysics),
                                        Adapt.adapt(to, θᵥ.specific_moisture_name),
                                        Adapt.adapt(to, θᵥ.standard_pressure),
                                        Adapt.adapt(to, θᵥ.thermodynamic_constants))

@inline function near_wall_specific_moisture(i, j, k, fields, ::Val{name}) where name
    moisture = getproperty(fields, name)
    return @inbounds moisture[i, j, k]
end

@inline function (θᵥ::NearWallVirtualPotentialTemperature)(i, j, k, grid, fields)
    @inbounds begin
        p = fields.p[i, j, k]
        ρ = fields.ρ[i, j, k]
        T = fields.T[i, j, k]
    end
    qᵛᵉ = near_wall_specific_moisture(i, j, k, fields, θᵥ.specific_moisture_name)
    q = grid_moisture_fractions(i, j, k, grid, θᵥ.microphysics, ρ, qᵛᵉ, fields)
    return virtual_potential_temperature(T, p, θᵥ.standard_pressure, q,
                                         θᵥ.thermodynamic_constants)
end

@inline near_wall_virtual_potential_temperature(i, j, k, grid,
                                                θᵥ::NearWallVirtualPotentialTemperature,
                                                fields) = θᵥ(i, j, k, grid, fields)

@inline near_wall_virtual_potential_temperature(i, j, k, grid, θᵥ, fields) =
    @inbounds θᵥ[i, j, k]

struct PolynomialCoefficient{FT, C, SF, S, θᵛ, SP, TC, TT}
    polynomial :: C
    roughness_length :: FT
    minimum_wind_speed :: FT
    stability_function :: SF
    surface :: S
    moisture_availability :: FT      # the fraction β of the surface that is saturated
    virtual_potential_temperature :: θᵛ
    standard_pressure :: SP
    thermodynamic_constants :: TC
    transfer_type :: TT
end

"""
$(TYPEDSIGNATURES)

A bulk transfer coefficient that depends on wind speed and atmospheric stability,
following [Large and Yeager (2009)](@cite LargeYeager2009).

The neutral transfer coefficient at 10 m follows the Large and Yeager (2009) form:
```math
C^N_{10}(U_h) = a_0 + a_1 U_h + a_2 / U_h
```
where ``U_h`` is the wind speed at measurement height ``h``. The polynomial evaluates to the
coefficient itself; Large and Yeager publish their coefficients in units of ``10^{-3}``, a
scaling the default polynomials carry explicitly.

The coefficient is adjusted for measurement height using logarithmic profile theory,
and stability correction is applied based on the bulk Richardson number.

When `polynomial` is `nothing`, the appropriate [Large and Yeager (2009)](@cite LargeYeager2009) polynomial
will be automatically selected based on the boundary condition type:
- `BulkDrag`: `default_neutral_drag_polynomial` = `(0.142, 0.076, 2.7) .* 1e-3` for momentum
- `BulkSensibleHeatFlux`: `default_neutral_sensible_heat_polynomial` = `(0.128, 0.068, 2.43) .* 1e-3` for sensible heat
- `BulkVaporFlux`: `default_neutral_latent_heat_polynomial` = `(0.120, 0.070, 2.55) .* 1e-3` for latent heat

# Keyword Arguments
- `polynomial`: Tuple `(a₀, a₁, a₂)` for the polynomial. If `nothing`, the polynomial
  is automatically selected by the boundary condition constructor.
- `roughness_length`: Surface roughness `ℓʳ` in meters (default: 1.5e-4, typical for ocean)
- `minimum_wind_speed`: Minimum wind speed to avoid singularity in a₂/U term (default: 0.1 m/s)
- `stability_function`: Stability correction strategy.
  Default is [`FittedStabilityFunction`](@ref) using [Li et al. (2010)](@cite Li2010) ``Riᴮ → ζ`` mapping
  with [Hogström (1996)](@cite hogstrom1996review) / [Beljaars & Holtslag (1991)](@cite beljaars1991flux)
  MOST stability functions. The scalar roughness length defaults to `roughness_length / 7.3`
  (typical ocean value). Use `nothing` to disable stability correction.
- `surface`: The phase of the surface water, which selects the saturation specific humidity at the
  surface in the stability correction: `PlanarLiquidSurface()` (default), `PlanarIceSurface()` or
  `PlanarMixedPhaseSurface(liquid_fraction)`.
- `moisture_availability`: The fraction ``β ∈ [0, 1]`` of the surface that is saturated (default: 1,
  an ocean). The surface specific humidity entering the stability correction is
  ``qˢ = β qᵛ⁺(Tˢ) + (1 - β) qᵛ``, with ``qᵛ`` the specific humidity of the air in the first cell,
  so that ``β = 0`` describes a dry surface whose virtual potential temperature carries no moisture
  contribution of its own. See [`wall_virtual_potential_temperature`](@ref).

The measurement height is automatically determined from the grid as half the first-cell
thickness, the height of its center above the local surface.

# Examples

```jldoctest
using Breeze.BoundaryConditions: PolynomialCoefficient

# Polynomial coefficient with default settings
coef = PolynomialCoefficient()

# output
PolynomialCoefficient{Float64}
├── polynomial: nothing
├── roughness_length: 0.00015 m
├── minimum_wind_speed: 0.1 m/s
├── surface: PlanarLiquidSurface
├── moisture_availability: 1.0
└── stability_function: FittedStabilityFunction (Li et al. 2010)
```

```jldoctest
using Breeze.BoundaryConditions: PolynomialCoefficient

# With explicit polynomial
coef = PolynomialCoefficient(polynomial = (0.000142, 7.6e-5, 0.0027))

# output
PolynomialCoefficient{Float64}
├── polynomial: (0.000142, 7.6e-5, 0.0027)
├── roughness_length: 0.00015 m
├── minimum_wind_speed: 0.1 m/s
├── surface: PlanarLiquidSurface
├── moisture_availability: 1.0
└── stability_function: FittedStabilityFunction (Li et al. 2010)
```

```jldoctest
using Breeze.BoundaryConditions: PolynomialCoefficient

# No stability correction
coef = PolynomialCoefficient(stability_function = nothing)

# output
PolynomialCoefficient{Float64}
├── polynomial: nothing
├── roughness_length: 0.00015 m
├── minimum_wind_speed: 0.1 m/s
├── surface: PlanarLiquidSurface
├── moisture_availability: 1.0
└── stability_function: Nothing
```

# References

* Beljaars, A. C. M., & Holtslag, A. A. M. (1991). Flux parameterization over land surfaces
  for atmospheric models. Journal of Applied Meteorology, 30, 327-341.
* Hogström, U. L. F. (1996). Review of some basic characteristics of the atmospheric surface layer.
  Boundary-Layer Meteorology, 78, 215-246.
* Large, W., & Yeager, S. G. (2009). The global climatology of an interannually varying air–sea flux data set. Climate dynamics, 33(2), 341-364.
* Li, Y., Gao, Z., Lenschow, D. H., & Chen, F. (2010). An improved approach for parameterizing surface-layer turbulent transfer coefficients in numerical models. Boundary-Layer Meteorology, 137, 153-165.
"""
function PolynomialCoefficient(FT = Oceananigans.defaults.FloatType;
                               polynomial = nothing,
                               roughness_length = 1.5e-4,
                               minimum_wind_speed = 0.1,
                               stability_function = FittedStabilityFunction(FT(roughness_length / 7.3)),
                               surface = PlanarLiquidSurface(),
                               moisture_availability = 1,
                               transfer_type = nothing)

    0 ≤ moisture_availability ≤ 1 ||
        throw(ArgumentError("moisture_availability must lie between 0 and 1, got $moisture_availability"))

    return PolynomialCoefficient(polynomial,
                                 FT(roughness_length),
                                 FT(minimum_wind_speed),
                                 stability_function,
                                 surface,
                                 FT(moisture_availability),
                                 nothing, nothing, nothing,
                                 transfer_type)
end

Adapt.adapt_structure(to, coef::PolynomialCoefficient) =
    PolynomialCoefficient(Adapt.adapt(to, coef.polynomial),
                          Adapt.adapt(to, coef.roughness_length),
                          Adapt.adapt(to, coef.minimum_wind_speed),
                          coef.stability_function,
                          coef.surface,
                          coef.moisture_availability,
                          Adapt.adapt(to, coef.virtual_potential_temperature),
                          Adapt.adapt(to, coef.standard_pressure),
                          Adapt.adapt(to, coef.thermodynamic_constants),
                          coef.transfer_type)

function Base.show(io::IO, coef::PolynomialCoefficient{FT}) where FT
    println(io, "PolynomialCoefficient{$FT}")
    println(io, "├── polynomial: ", coef.polynomial)
    println(io, "├── roughness_length: ", coef.roughness_length, " m")
    println(io, "├── minimum_wind_speed: ", coef.minimum_wind_speed, " m/s")
    println(io, "├── surface: ", summary(coef.surface))
    println(io, "├── moisture_availability: ", coef.moisture_availability)
    print(io,   "└── stability_function: ", summary(coef.stability_function))
end

Base.summary(coef::PolynomialCoefficient) =
    string("PolynomialCoefficient(", coef.polynomial, ")")

#####
##### Neutral coefficient computation (Large & Yeager 2009 form)
#####

"""
$(TYPEDSIGNATURES)

Compute neutral transfer coefficient at 10 m using the
[Large and Yeager (2009)](@cite LargeYeager2009) form:
```math
C^N_{10}(U) = a_0 + a_1 U + a_2 / U
```

Wind speed is clamped to `U_min` to avoid singularity in the ``a_2/U`` term.

# References

* Large, W., & Yeager, S. G. (2009). The global climatology of an interannually varying
    air–sea flux data set. Climate dynamics, 33(2), 341-364.
"""
@inline function neutral_coefficient_10m(polynomial, U₁₀, U_min)
    a₀, a₁, a₂ = polynomial
    # Avoid division by zero
    U_safe = max(U₁₀, U_min)
    return a₀ + a₁ * U_safe + a₂ / U_safe
end

#####
##### Bulk Richardson number
#####

"""
$(TYPEDSIGNATURES)

Compute bulk Richardson number:
```math
Riᴮ = (g / θ̄ᵥ) h (θᵥ - θᵥˢ) / U²
```

Wind speed is clamped to `U_min` to avoid singularity.

# Arguments
- `h`: Measurement height (m)
- `θᵥ`: Virtual potential temperature at measurement height (K)
- `θᵥˢ`: Virtual potential temperature at surface (K)
- `U`: Wind speed (m/s)
- `U_min`: Minimum wind speed (m/s)
- `g`: Gravitational acceleration (m/s²)
"""
@inline function bulk_richardson_number(h, θᵥ, θᵥˢ, U, U_min, g)
    # Avoid division by zero
    U_safe = max(U, U_min)
    θᵥ_mean = (θᵥ + θᵥˢ) / 2
    return (g / θᵥ_mean) * h * (θᵥ - θᵥˢ) / U_safe^2
end

#####
##### Helper functions for surface thermodynamic quantities
#####

"""
$(TYPEDSIGNATURES)

Compute the virtual potential temperature of a planar `surface` with surface temperature `Tˢ`,
surface pressure `pˢ`, standard pressure `pˢᵗ`, moisture availability `β` and first-cell specific
humidity `qᵛ`,

```math
θᵥˢ = \\frac{Tˢ}{Πᵈˢ} (1 + δᵛᵈ qˢ), \\qquad qˢ = β qᵛ⁺ + (1 - β) qᵛ,
\\qquad Πᵈˢ = (pˢ / pˢᵗ)^{Rᵈ/cᵖᵈ}
```

where ``qᵛ⁺`` is the saturation specific humidity at the surface and ``δᵛᵈ = Rᵛ/Rᵈ - 1``
(≈ 0.608 for water vapor in Earth's atmosphere; the actual value depends on the gas constants in
`constants`). A saturated surface (``β = 1``, the default) carries its saturation humidity; a dry
surface (``β = 0``) carries the humidity of the air above it, and so contributes no moisture of its
own to the surface buoyancy. The dry Exner factor is required because the stability difference
compares two virtual *potential* temperatures, not virtual temperature at the surface against
potential temperature aloft.
"""
@inline function wall_virtual_potential_temperature(Tˢ, pˢ, pˢᵗ, constants, surface, β = 1, qᵛ = 0)
    qᵛ⁺ = saturation_total_specific_moisture(Tˢ, pˢ, constants, surface)
    qˢ = β * qᵛ⁺ + (1 - β) * qᵛ
    # The same θᵥ the air-side of the stability difference goes through, with no condensate at the
    # surface. Sharing it is what keeps the two sides of that subtraction defined identically.
    return virtual_potential_temperature(Tˢ, pˢ, pˢᵗ, MoistureMassFractions(qˢ), constants)
end

#####
##### Main callable interface
#####

"""
$(TYPEDSIGNATURES)

Evaluate the bulk transfer coefficient for given conditions.

The surface pressure `pˢ` that the stability correction needs is an argument rather than
stored state: a bulk boundary condition diagnoses it from the live model fields at the column
being evaluated, so it follows both terrain and the evolving state.

# Arguments
- `i`, `j`: Grid indices
- `grid`: The grid
- `U`: Wind speed (m/s): the effective wind ``Ũ = \\sqrt{u² + v² + Uᵍ²}`` of the flux the
  coefficient multiplies, gustiness ``Uᵍ`` included
- `Tˢ`: Surface temperature (K) at location `(i, j)`
- `h`: Measurement height (m) above the local surface; the short form uses half the first-cell
  thickness
- `Δθᵥ_source`: Field of the filtered surface-layer virtual potential temperature difference, or
  `nothing` to form it from the instantaneous state
- `fields`: The surface-layer field tuple the instantaneous diagnostic reads. Required, because a
  materialized `coef.virtual_potential_temperature` is a `NearWallVirtualPotentialTemperature` that
  has no fields of its own; pass `nothing` only when `Δθᵥ_source` or
  `coef.virtual_potential_temperature` is an ordinary field, which is then read directly.
- `pˢ`: Air pressure (Pa) at the surface below `(i, j)`

Returns the transfer coefficient (dimensionless).

There are deliberately only these two methods. Earlier `fields`-less forms were separated from
these by arity alone and silently forwarded `fields = nothing`, which crashes for every coefficient
`materialize_coefficient` builds — the instantaneous diagnostic would dereference `nothing.p`. A
kernel cannot raise a useful error, so the argument is mandatory instead.
"""
# Short form: the near-wall cell of `side`, at the wall distance of its centre, with the
# instantaneous Δθᵥ.
@inline function (coef::PolynomialCoefficient)(i, j, k, grid, side, U, Tˢ, fields, pˢ)
    h = wall_distance(i, j, k, grid, side)
    return coef(i, j, k, grid, side, U, Tˢ, h, nothing, fields, pˢ)
end

# General form: on the wall `side`, next to the near-wall cell (i, j, k), at wall distance h
@inline function (coef::PolynomialCoefficient)(i, j, k, grid, side, U, Tˢ, h, Δθᵥ_source, fields, pˢ)
    C¹⁰ = neutral_coefficient_10m(coef.polynomial, U, coef.minimum_wind_speed)

    # Adjust for measurement height using logarithmic profile:
    # C(h) = C₁₀ × [ln(10/ℓʳ) / ln(h/ℓʳ)]²
    ℓʳ = coef.roughness_length
    α = log(h / ℓʳ)
    Cʰ = C¹⁰ * (log(10 / ℓʳ) / α)^2

    # Apply stability correction (reads the filtered Δθᵥ when `Δθᵥ_source` is provided)
    return stability_corrected_coefficient(i, j, k, grid, side, coef, Cʰ, h, α, U, Tˢ,
                                           Δθᵥ_source, fields, pˢ)
end

# No stability correction (stability_function = nothing) — `Δθᵥ_source` is ignored
@inline stability_corrected_coefficient(i, j, k, grid, side,
    ::PolynomialCoefficient{<:Any, <:Any, Nothing}, Cʰ, h, α, U, Tˢ,
    Δθᵥ_source, fields, pˢ) = Cʰ

# Vertical walls: buoyancy acts along the wall, so the surface layer has no
# Monin–Obukhov stability correction
@inline stability_corrected_coefficient(i, j, k, grid, ::VerticalWall,
    ::PolynomialCoefficient{<:Any, <:Any, <:FittedStabilityFunction}, Cʰ, h, α, U, Tˢ,
    Δθᵥ_source, fields, pˢ) = Cʰ

# FittedStabilityFunction correction (Li et al. 2010 mapping + MOST Ψ functions) on
# horizontal walls. The `Δθᵥ_source` argument selects the surface-layer virtual potential
# temperature difference:
#   - `nothing` → formed from the instantaneous near-wall state and `Tˢ`
#   - a filtered 2D field → read `Δθᵥ_source[i, j, 1]`
# The wall value θᵥˢ is formed from the instantaneous state either way: it only sets the
# mean temperature in the Richardson number, where its fluctuations are negligible.
@inline function stability_corrected_coefficient(i, j, k, grid, side::HorizontalWall,
    coef::PolynomialCoefficient{<:Any, <:Any, <:FittedStabilityFunction}, Cʰ, h, α, U, Tˢ,
    Δθᵥ_source, fields, pˢ)

    sf = coef.stability_function
    ℓʳ = coef.roughness_length
    ℓʳʰ = sf.scalar_roughness_length
    β = log(ℓʳ / ℓʳʰ)

    Δθᵥ = surface_layer_Δθᵥ(i, j, k, grid, coef, Tˢ, Δθᵥ_source, fields, pˢ)
    θᵥˢ = wall_virtual_potential_temperature(i, j, k, coef, Tˢ, fields, pˢ)
    g = coef.thermodynamic_constants.gravitational_acceleration
    Riᴮ = stability_sign(side) * bulk_richardson_number(h, θᵥˢ + Δθᵥ, θᵥˢ, U, coef.minimum_wind_speed, g)

    return Cʰ * sf(Riᴮ, α, β, coef.transfer_type)
end

"""
$(TYPEDSIGNATURES)

The virtual potential temperature of the wall next to the cell `(i, j, k)`, from the wall
temperature `Tˢ`, the air pressure `pˢ` at the wall, and the coefficient's standard pressure,
constants, surface phase and moisture availability, together with the specific humidity of the air
in the near-wall cell.
"""
@inline function wall_virtual_potential_temperature(i, j, k, coef::PolynomialCoefficient, Tˢ, fields, pˢ)
    qᵛ = @inbounds fields.qᵛ[i, j, k]
    return wall_virtual_potential_temperature(Tˢ, pˢ, coef.standard_pressure,
                                                 coef.thermodynamic_constants, coef.surface,
                                                 coef.moisture_availability, qᵛ)
end

"""
$(TYPEDSIGNATURES)

The surface-layer virtual potential temperature difference ``Δθᵥ = θᵥ(z₁) - θᵥˢ`` between the
near-wall cell `(i, j, k)` and the wall at temperature `Tˢ`, from the instantaneous state: the
stability input of the bulk coefficient, and the result that
[`FilteredSurfaceVelocities`](@ref) filters on the bottom wall.
"""
@inline function surface_layer_Δθᵥ(i, j, k, grid, coef::PolynomialCoefficient, Tˢ, fields, pˢ)
    θᵥ = near_wall_virtual_potential_temperature(i, j, k, grid, coef.virtual_potential_temperature, fields)
    return θᵥ - wall_virtual_potential_temperature(i, j, k, coef, Tˢ, fields, pˢ)
end

# Dispatch on whether a filtered difference is supplied
@inline surface_layer_Δθᵥ(i, j, k, grid, coef, Tˢ, ::Nothing, fields, pˢ) =
    surface_layer_Δθᵥ(i, j, k, grid, coef, Tˢ, fields, pˢ)

@inline surface_layer_Δθᵥ(i, j, k, grid, coef, Tˢ, Δθᵥ_filtered, fields, pˢ) =
    @inbounds Δθᵥ_filtered[i, j, 1]

#####
##### Bulk coefficient evaluation
#####
#####
##### Unified interface for evaluating bulk transfer coefficients. Dispatches
##### on the coefficient type: constant Number returns directly, callable
##### PolynomialCoefficient computes wind speed and evaluates with stability correction.
#####

#####
##### Evaluation height helper
#####

@inline evaluation_height(i, j, grid, ::Nothing) = Δzᶜᶜᶜ(i, j, 1, grid) / 2
@inline evaluation_height(i, j, grid, h) = h

#####
##### Bulk coefficient evaluation — no filtering
#####
##### On the wall `side`, next to the near-wall cell (i, j, k). The transfer coefficient is
##### evaluated with the tangential wind at the cell centre and the wall distance of the
##### cell centre.
#####
##### The coefficient sees the same effective wind as the flux it multiplies,
##### Ũ = √(u² + v² + Uᵍ²), with `Uᵍ²` the squared gustiness: both in the neutral polynomial
##### and in the bulk Richardson number Riᴮ = g h Δθᵥ / (θᵥ Ũ²) that sets the stability
##### correction. With the bare wind instead, calm air over a warm surface would see an
##### unbounded Riᴮ and a coefficient for a wind far lighter than the one the flux uses.
#####

@inline bulk_coefficient(i, j, k, grid, side, C::Number, fields, Tˢ, fv, pˢ, Uᵍ²) = C

@inline function bulk_coefficient(i, j, k, grid, side, C::PolynomialCoefficient, fields, Tˢ, ::Nothing, pˢ, Uᵍ²)
    U² = tangential_speed²(i, j, k, grid, side, nothing, fields)
    Ũ = sqrt(U² + Uᵍ²)
    return C(i, j, k, grid, side, Ũ, Tˢ, fields, pˢ)
end

#####
##### Bulk coefficient evaluation — with filtered velocities (bottom wall only)
#####
##### When a `FilteredSurfaceVelocities` is provided, both the wind speed and
##### the stability input `Δθᵥ` are read from the filtered fields. This keeps the
##### bulk coefficient consistent with the rest of the bulk formula in which
##### every term is computed from filtered state.
#####

@inline function bulk_coefficient(i, j, k, grid, side::Bottom, C::PolynomialCoefficient, fields, Tˢ,
                                  fv::FilteredSurfaceVelocities, pˢ, Uᵍ²)
    U² = wind_speed²ᶜᶜᶜ(i, j, grid, fields, fv)
    Ũ = sqrt(U² + Uᵍ²)
    h = evaluation_height(i, j, grid, fv.height)
    return C(i, j, k, grid, side, Ũ, Tˢ, h, fv.Δθᵥ, fields, pˢ)
end

#####
##### Default polynomial filling
#####

# Helper: fill in a default polynomial and transfer type for a PolynomialCoefficient
fill_polynomial(coef::PolynomialCoefficient, polynomial, transfer_type) =
    PolynomialCoefficient(polynomial,
                          coef.roughness_length,
                          coef.minimum_wind_speed,
                          coef.stability_function,
                          coef.surface,
                          coef.moisture_availability,
                          nothing, nothing, nothing,
                          transfer_type)

# Type alias for PolynomialCoefficient with no polynomial set
const NothingPolynomialCoefficient = PolynomialCoefficient{<:Any, Nothing}
