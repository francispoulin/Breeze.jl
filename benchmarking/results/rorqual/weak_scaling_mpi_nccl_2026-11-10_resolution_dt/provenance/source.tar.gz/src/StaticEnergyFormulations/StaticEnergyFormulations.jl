"""
    StaticEnergyFormulations

Submodule defining the static energy thermodynamic formulation for atmosphere models.

`StaticEnergyFormulation` uses moist static energy density `ρs` as the prognostic thermodynamic variable.
Moist static energy is a conserved quantity in adiabatic, frictionless flow that combines
sensible heat, gravitational potential energy, and latent heat.
"""
module StaticEnergyFormulations

export StaticEnergyFormulation

using DocStringExtensions: TYPEDSIGNATURES, TYPEDEF
using Adapt: Adapt, adapt
using KernelAbstractions: @kernel, @index

using Oceananigans: Oceananigans, CenterField, Center, znode
using Oceananigans.BoundaryConditions: BoundaryConditions, fill_halo_regions!
using Oceananigans.Operators: ℑzᵃᵃᶜ
using Oceananigans.Utils: prettysummary, launch!

using Breeze.AtmosphereModels: AtmosphereModels,
    continuity_density, total_density, dynamics_pressure, standard_pressure, dynamics_prognostic_fields,
    pressure_from_density_temperature,
    grid_moisture_fractions, maybe_adjust_thermodynamic_state, div_ρUc,
    c_div_ρU, ∇_dot_Jᶜ, w_buoyancy_forceᶜᶜᶠ,
    add_sedimentation_tendency!, sedimentation_composition_increment, enthalpy_increment,
    AtmosphereModelBuoyancy,
    radiation_flux_divergence

using Breeze.Thermodynamics: StaticEnergyState, LiquidIcePotentialTemperatureState, with_temperature

# The lowercase c is a singleton instance of Center
const c = Center()

include("static_energy_formulation.jl")
include("static_energy_tendency.jl")

# Kernel wrapper for launching static_energy_tendency
# (needs to be defined after static_energy_tendency is defined)
@kernel function compute_static_energy_tendency!(Gρs, grid, args)
    i, j, k = @index(Global, NTuple)
    @inbounds Gρs[i, j, k] = static_energy_tendency(i, j, k, grid, args...)
end

end # module
