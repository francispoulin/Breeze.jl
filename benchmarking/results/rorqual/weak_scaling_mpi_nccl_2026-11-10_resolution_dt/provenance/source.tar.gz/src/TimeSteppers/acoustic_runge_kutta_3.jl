using KernelAbstractions: @kernel, @index

using Oceananigans: TendencyCallsite
using Oceananigans.Utils: time_difference_seconds

using Oceananigans.TimeSteppers:
    AbstractTimeStepper,
    tick_stage!,
    update_state!,
    compute_flux_bc_tendencies!,
    step_lagrangian_particles!

using Oceananigans.TurbulenceClosures: step_closure_prognostics!

using Breeze.AtmosphereModels: AtmosphereModels, AtmosphereModel, SlowDynamics, microphysics_model_update!,
                                compute_closure_tendencies!, refreshes_state_after_update, invalid_time_step

using Breeze.CompressibleEquations:
    CompressibleDynamics,
    TerrainCompressibleDynamics,
    AcousticSubstepper,
    WickerSkamarock3,
    stage_fractions,
    acoustic_rk3_substep_loop!,
    prepare_acoustic_cache!,
    freeze_linearization_state!,
    seed_time_averaged_velocities!

"""
$(TYPEDEF)

Wicker–Skamarock third-order Runge–Kutta time stepper with linearized
acoustic substepping for fully compressible dynamics. Stage fractions
``β = (1/3, 1/2, 1)``. Each stage:

  1. Re-evaluates slow tendencies (advection + Coriolis + closure +
     forcing only — PGF and buoyancy are handled inside the substep
     loop in linearized form).
  2. Runs an inner substep loop that evolves linearized acoustic
     perturbations from the RK stage-entry state, initialized with a
     rewind term so every stage still advances from the outer-step-start
     prognostic state.

The acoustic substep loop is in
[`acoustic_rk3_substep_loop!`](@ref); see
[`AcousticSubstepper`](@ref) for the substepper's storage and
parameters.

Fields
======

- `β₁, β₂, β₃`: Stage fractions (1/3, 1/2, 1).
- `U⁰`: Storage for state at the beginning of the outer time-step.
- `Gⁿ`: Slow-tendency fields, recomputed each stage.
- `implicit_solver`: Optional solver for the vertically-implicit pieces — closure diffusion
  and the adaptive-implicit vertical-advection remainder.
- `substepper`: [`AcousticSubstepper`](@ref) for the linearized acoustic
  substep loop.
- `rounding`: Round-off treatment of the final stage's update, [`RoundToNearest`](@ref)
  or [`StochasticRounding`](@ref Breeze.RoundingTreatments.StochasticRounding).

References
==========

Wicker, L. J. & Skamarock, W. C. (2002). *Time-splitting methods for
elastic models using forward time schemes.* MWR 130, 2088–2097.
"""
struct AcousticRungeKutta3{FT, U0, TG, TI, AS, R} <: AbstractTimeStepper
    β₁ :: FT
    β₂ :: FT
    β₃ :: FT
    U⁰ :: U0
    Gⁿ :: TG
    implicit_solver :: TI
    substepper :: AS
    rounding :: R
end

"""
$(TYPEDSIGNATURES)

Construct an `AcousticRungeKutta3` time stepper for fully compressible dynamics.

`Gⁿ` and `U⁰` may be supplied to alias another stepper's tendency storage instead of
allocating fresh fields (used by the native-stepper adiabatic-balance twin).

`rounding` sets the round-off treatment of the step's final update (default:
[`RoundToNearest`](@ref)). Every Wicker–Skamarock stage restarts from ``Uⁿ``, so only the third
stage's rounding reaches ``Uⁿ⁺¹``: with [`StochasticRounding`](@ref Breeze.RoundingTreatments.StochasticRounding), the recovery of the acoustic
prognostics from their stage-entry values plus the accumulated perturbations, and the update
``u⁰ + Δt G`` of the other scalars, are rounded stochastically in the third stage. The
perturbations themselves, the first two stages, and the vertically-implicit solves stay
round-to-nearest.
"""
function AcousticRungeKutta3(grid, prognostic_fields;
                             dynamics,
                             implicit_solver::TI = nothing,
                             cache_advecting_state = false,
                             Gⁿ::TG = map(similar, prognostic_fields),
                             U⁰::U0 = map(similar, prognostic_fields),
                             rounding = RoundToNearest()) where {TI, TG, U0}

    FT = eltype(grid)
    rounding = materialize_rounding(rounding, grid.architecture)
    R = typeof(rounding)

    # Stage fractions come from the outer-scheme interface. Today the only
    # supported subtype is WickerSkamarock3 with canonical (1/3, 1/2, 1);
    # a future MIS outer scheme would extend AcousticOuterScheme and provide
    # its own stage_fractions method.
    β = stage_fractions(WickerSkamarock3())
    β₁ = FT(β[1])
    β₂ = FT(β[2])
    β₃ = FT(β[3])

    substepper = AcousticSubstepper(grid, dynamics.time_discretization;
                                    cache_advecting_state,
                                    prognostic_momentum = (ρu = prognostic_fields.ρu,
                                                           ρv = prognostic_fields.ρv,
                                                           ρw = prognostic_fields.ρw))
    AS = typeof(substepper)

    return AcousticRungeKutta3{FT, U0, TG, TI, AS, R}(β₁, β₂, β₃, U⁰, Gⁿ,
                                                      implicit_solver, substepper, rounding)
end

#####
##### Adaptive-implicit vertical advection split time step
#####

# An `AtmosphereModel` stepped by `AcousticRungeKutta3`; the free parameter is the
# architecture, so `BreezeReactantExt` can specialize on `{<:ReactantState}`.
const CompressibleAcousticModel{Arc} = AtmosphereModel{<:CompressibleDynamics, <:Any, Arc, <:AcousticRungeKutta3}

# Stage fractions, and the increment each stage adds to the clock. `ifelse` rather than
# branching: `clock.stage` is traced under Reactant.
@inline stage_fraction(ts, stage) = ifelse(stage == 1, ts.β₁, ifelse(stage == 2, ts.β₂, ts.β₃))
@inline stage_increment(ts, stage) = ifelse(stage == 1, ts.β₁, ifelse(stage == 2, ts.β₂ - ts.β₁, 1 - ts.β₂))

"""
$(TYPEDSIGNATURES)

The adaptive-implicit split time step for the *next* Wicker–Skamarock stage, so the explicit
velocity fraction frozen into `Gⁿ` pairs with the implicit fraction the next stage applies.
Stage 1 of step ``n`` is evaluated before ``Δtₙ`` is known and deliberately uses ``β₁ Δtₙ₋₁``;
the cost is confined to CFL targeting on one stage when ``Δt`` changes (see
`maybe_prepare_first_time_step!` for the cold-start seeding).
"""
@inline function Oceananigans.Advection.adaptive_advection_timestep(timestepper::AcousticRungeKutta3, clock)
    stage = clock.stage
    completed = ifelse(stage == 1, 3, stage - 1)
    Δt = clock.last_stage_Δt / stage_increment(timestepper, completed)
    Δt_stage = stage_fraction(timestepper, stage) * Δt
    Δt_last = stage_fraction(timestepper, stage) * clock.last_Δt
    return ifelse(isfinite(Δt_stage), Δt_stage, Δt_last)
end

#####
##### Per-stage substep wrapper
#####

"""
$(TYPEDSIGNATURES)

Run one Wicker–Skamarock RK3 stage: complete the slow tendencies built by
`update_state!`, then execute the linearized-acoustic substep loop, then
update remaining scalars. The stage's updates are rounded with the round-off treatment `rounding`.
"""
function acoustic_rk3_substep!(model::AtmosphereModel, Δt, β, rounding = RoundToNearest())
    ts = model.timestepper
    substepper = ts.substepper
    U⁰ = ts.U⁰

    # Per-stage cache prep. The linearization coefficients are refreshed
    # to the current RK stage-entry state; the substep perturbations are
    # initialized with a rewind term inside the substep loop so the
    # WS-RK3 invariant still starts from Uⁿ.
    prepare_acoustic_cache!(substepper, model)
    cache_advecting_state!(model)

    # `update_state!` built the slow tendencies (advection + Coriolis + diffusion; PGF and
    # buoyancy are excluded — those are handled inside the substep loop in linearized form
    # about the RK stage-entry state). Add the boundary flux and closure tendencies to them.
    compute_flux_bc_tendencies!(model)
    compute_closure_tendencies!(model)

    # Base-state part of the IMEX vertical-advection split's implicit half (a no-op unless
    # the thermodynamic scheme is adaptive-implicit); the perturbation part is solved per
    # substep inside the loop, dispatched on the scheme type.
    add_implicit_advection_tendency!(model)

    # Linearized acoustic substep loop: Nτ substeps of size Δτ = Δt/N.
    θ_advection = field_advection_scheme(model.advection, thermodynamic_density_name(model.formulation))
    acoustic_rk3_substep_loop!(model, substepper, Δt, β, U⁰, θ_advection; rounding)

    # Update remaining scalars (tracers) using WS-RK3, their implicit solves included. It runs
    # before the post-loop solves because it ends by moving the condensate content of the mass
    # the tracers' solves sedimented, which then takes the thermodynamic variable's post-loop
    # closure diffusion; that variable's implicit vertical transport was already applied inside
    # the substep loop (see `implicit_sedimentation_step!`).
    scalar_rk3_substep!(model, β * Δt, rounding)

    # Vertically-implicit solve for the acoustic prognostics (momentum and the thermodynamic
    # variable) over the stage interval β Δt: the implicit remainder of adaptive implicit
    # vertical advection combined with vertically-implicit closure diffusion. A no-op when
    # the timestepper has no implicit solver.
    implicit_substep!(model, β * Δt)

    return nothing
end

#####
##### Scalar update with time-averaged velocities
#####

function scalar_rk3_substep!(model::AtmosphereModel, Δt_stage, rounding = RoundToNearest())
    grid = model.grid
    kernel_Δt = kernel_time_step(grid.architecture, grid, Δt_stage)
    return scalar_substep!(model, Δt_stage, kernel_Δt, rounding)
end

# Round-to-nearest keeps the original kernel, so the default is bitwise unchanged.
launch_rk3_substep!(::RoundToNearest, arch, grid, u, u⁰, G, Δt_stage, key) =
    launch!(arch, grid, :xyz, _rk3_substep!, u, u⁰, G, Δt_stage)

launch_rk3_substep!(rounding, arch, grid, u, u⁰, G, Δt_stage, key) =
    launch!(arch, grid, :xyz, _rounded_rk3_substep!, u, u⁰, G, Δt_stage, rounding, key)

@kernel function _rk3_substep!(u, u⁰, G, Δt_stage)
    i, j, k = @index(Global, NTuple)
    @inbounds u[i, j, k] = u⁰[i, j, k] + Δt_stage * G[i, j, k]
end

@kernel function _rounded_rk3_substep!(u, u⁰, G, Δt_stage, rounding, key)
    i, j, k = @index(Global, NTuple)
    @inbounds u[i, j, k] = rounded_add(rounding, u⁰[i, j, k], Δt_stage * G[i, j, k], i, j, k, key)
end

#####
##### Time stepping (main entry point)
#####

"""
$(TYPEDSIGNATURES)

Seed `clock.last_stage_Δt` before the first step (or for a clock carrying a non-finite value)
with the increment a completed third stage leaves, ``(1 - β₂) Δt`` — what
`adaptive_advection_timestep` inverts at stage 1. `PerturbationAdvection` open boundaries read
the same field.

Also seed the substepper's time-averaged transport velocity before the first tendencies are
built, then freeze the copy that the first stage's implicit remainder splits.
"""
function OceananigansTimeSteppers.maybe_prepare_first_time_step!(model::CompressibleAcousticModel, Δt, callbacks)
    clock = model.clock
    if clock.iteration == 0 || !isfinite(clock.last_stage_Δt)
        clock.last_Δt = Δt
        clock.last_stage_Δt = stage_increment(model.timestepper, 3) * Δt
        reconcile_state!(model)

        # Seed the transport velocity *before* the tendencies below: `set!` has already
        # diagnosed `model.velocities` from the initial momentum, and no acoustic loop has run
        # to average over. Without this, stage 1 of step 1 would build its scalar tendencies
        # from the constructor's zeros and transport no tracers vertically.
        seed_time_averaged_velocities!(model.timestepper.substepper, model)
        update_state!(model, callbacks)
        cache_transport_velocity!(model)
    end
    return nothing
end

"""
$(TYPEDSIGNATURES)

Step forward `model` one time step `Δt` with Wicker–Skamarock RK3 and
linearized acoustic substepping.
"""
function OceananigansTimeSteppers.time_step!(model::CompressibleAcousticModel, Δt; callbacks=[])

    maybe_prepare_first_time_step!(model, Δt, callbacks)

    ts = model.timestepper
    β₁ = ts.β₁
    β₂ = ts.β₂
    β₃ = ts.β₃

    tⁿ⁺¹ = model.clock.time + Δt

    # Snapshot outer-step-start state into U⁰ for use by all stages.
    # The substepper also seeds its stage-1 cache and time-averaged
    # transport velocity from this state.
    store_initial_state!(model)
    freeze_linearization_state!(ts.substepper, model)

    # Stage 1: U* = Uⁿ + (Δt/3) R(Uⁿ)
    acoustic_rk3_substep!(model, Δt, β₁)

    tick_stage!(model.clock, β₁ * Δt)
    update_state!(model, callbacks; compute_tendencies = true)
    # Freeze the transport velocity the scalar tendencies were just built with; the next
    # stage's acoustic loop overwrites the live field before `scalar_substep!` reads it.
    cache_transport_velocity!(model)

    # Stage 2: U** = Uⁿ + (Δt/2) R(U*)
    acoustic_rk3_substep!(model, Δt, β₂)

    tick_stage!(model.clock, (β₂ - β₁) * Δt)
    update_state!(model, callbacks; compute_tendencies = true)
    cache_transport_velocity!(model)

    # Stage 3: Uⁿ⁺¹ = Uⁿ + Δt R(U**). Every stage restarts from Uⁿ, so only this stage's
    # rounding reaches Uⁿ⁺¹, and only this stage takes the time stepper's round-off treatment.
    acoustic_rk3_substep!(model, Δt, β₃, ts.rounding)

    corrected_Δt = time_difference_seconds(tⁿ⁺¹, model.clock.time)
    tick_stage!(model.clock, corrected_Δt, Δt)

    step_closure_prognostics!(model.closure_fields, model.closure, model, Δt)

    # Kessler reads diagnostics, then rebuilds tendencies after updating its prognostics.
    # Keep the preceding pass when Kessler will return early (the same `invalid_time_step`
    # test it applies), or when a tendency callback is present, so that the callback still runs
    # once per stage.
    # TODO: Kessler's internal update_state! does not forward the time stepper's callbacks, so
    # whatever a tendency callback adds to Gⁿ here is overwritten before stage 1 of the next step.
    # Forwarding the callbacks through microphysics_model_update! would fix this and let the pass
    # always be skipped.
    skip_tendencies = skip_pre_microphysics_tendencies(model.microphysics, Δt, callbacks)
    update_state!(model, callbacks; compute_tendencies = !skip_tendencies)
    # These tendencies are consumed by stage 1 of the next step, after
    # `freeze_linearization_state!` has reseeded the live field.
    cache_transport_velocity!(model)

    # Apply the operator-split microphysics update exactly once per step, on the post-RK
    # state just refreshed by `update_state!`. A no-op for tendency-interface schemes.
    microphysics_model_update!(model.microphysics, model)

    # Advect particles once per step, over the full Δt, with the velocity of the state
    # just refreshed to tⁿ⁺¹: Xⁿ⁺¹ = Xⁿ + Δt u(Xⁿ, tⁿ⁺¹) — consistent, but first order,
    # and so lower order than the dycore. A stage-wise update is possible in principle
    # (X obeys dX/dt = u like any prognostic), but would need Xⁿ stored alongside the
    # current position, since every Wicker–Skamarock stage restarts from Uⁿ. Pushing
    # with the stage fractions alone would be wrong: β₁ + β₂ + β₃ = 11/6, not 1.
    step_lagrangian_particles!(model, Δt)

    return nothing
end

skip_pre_microphysics_tendencies(microphysics, Δt, callbacks) =
    refreshes_state_after_update(microphysics) && !invalid_time_step(Δt) &&
    !any(callback -> callback.callsite isa TendencyCallsite, callbacks)

#####
##### Time-averaged velocity for scalar transport (WRF/MPAS dynamics-transport split)
#####
##### Override `transport_velocities` to return the velocity averaged over
##### the previous stage's substep loop. The MAIN consumer is
##### `update_state!`'s `compute_tendencies!` between RK stages, which
##### computes Gⁿ for **moisture, tracers, chemistry, TKE** using
##### `transport_velocities(model)` — those tendencies are then applied by
##### the next stage's `scalar_rk3_substep!` (or the next outer step's stage
##### 1). Like WRF's `rk_scalar_tend` (called with `grid%ru_m, grid%rv_m,
##### grid%ww_m`) and MPAS's `ruAvg`-driven tracer transport, scalars are
##### advected by the acoustic-mean velocity rather than the RK predictor.
##### The stage alignment differs, though: WRF builds these tendencies inside
##### the stage, after its own substep loop, while Breeze builds them between
##### stages and so advects with the *preceding* loop's average.
#####
##### Theta's slow tendency does NOT consume this — `thermodynamic_transport_velocities`
##### routes it to `model.velocities` (matching WRF's `rk_tendency`; see
##### `slow_thermodynamic_velocities`). Mixing the two paths creates a feedback
##### loop that destabilizes a rest atmosphere at production Δt. Its condensate
##### sedimentation term alone reads the tracers' transport velocity, pairing its
##### content fluxes with the mass fluxes the tracer tendencies apply.
#####
##### The implicit remainder of a scalar update must split the SAME velocity
##### its explicit fraction was scaled by, so `scalar_substep!` reads a frozen
##### copy (`cache_transport_velocity!`) instead of this live field — by then
##### the stage's own acoustic loop has already rebuilt it. At outer-step start
##### `freeze_linearization_state!` seeds the live field with `model.velocities`
##### for whatever reads it before the first loop finalizes, and
##### `maybe_prepare_first_time_step!` seeds it before the very first tendency
##### computation so stage 1 of step 1 splits a physical velocity.
#####

function AtmosphereModels.transport_velocities(model::AtmosphereModel{<:CompressibleDynamics{<:Any, <:Any, <:Any, <:Any, <:Any, <:Any, Nothing},
                                                                      <:Any, <:Any, <:AcousticRungeKutta3})
    sub = model.timestepper.substepper
    return (u = sub.time_averaged_velocities.u,
            v = sub.time_averaged_velocities.v,
            w = sub.time_averaged_velocities.w)
end

function AtmosphereModels.transport_velocities(model::AtmosphereModel{<:TerrainCompressibleDynamics,
                                                                      <:Any, <:Any, <:AcousticRungeKutta3})
    sub = model.timestepper.substepper
    return (u = sub.time_averaged_velocities.u,
            v = sub.time_averaged_velocities.v,
            w = sub.time_averaged_velocities.w)
end

# `update_state!` builds the slow tendencies the stages apply: momentum without the pressure-gradient
# force and buoyancy, which the substep loop integrates, and the thermodynamic variable advected by
# the RK predictor velocity rather than the time-averaged transport velocity.
AtmosphereModels.slow_dynamics(::AcousticRungeKutta3, dynamics) = SlowDynamics(dynamics)
AtmosphereModels.thermodynamic_transport_velocities(model::CompressibleAcousticModel) = slow_thermodynamic_velocities(model)

Oceananigans.prognostic_state(timestepper::AcousticRungeKutta3) =
    (substepper = Oceananigans.prognostic_state(timestepper.substepper),)

function Oceananigans.restore_prognostic_state!(restored::AcousticRungeKutta3, from)
    Oceananigans.restore_prognostic_state!(restored.substepper, from.substepper)
    return restored
end

Oceananigans.restore_prognostic_state!(timestepper::AcousticRungeKutta3, ::Nothing) = timestepper
