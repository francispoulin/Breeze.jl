using KernelAbstractions: @kernel, @index

using Oceananigans: prognostic_fields, fields
using Oceananigans.TimeSteppers:
    AbstractTimeStepper,
    tick_stage!,
    update_state!,
    compute_flux_bc_tendencies!,
    step_lagrangian_particles!,
    implicit_step!

using Breeze.AtmosphereModels: AtmosphereModel, compute_pressure_correction!, make_pressure_correction!,
                                microphysics_model_update!, field_advection_scheme,
                                compute_closure_tendencies!,
                                closure_scalar_index, skip_vertical_diffusion,
                                implicit_advection_density, implicit_advection_velocities,
                                implicit_step_scheme, implicit_sedimentation_step!,
                                thermodynamic_density_name
using Oceananigans.Utils: launch!, time_difference_seconds
using Oceananigans.TurbulenceClosures: step_closure_prognostics!

"""
$(TYPEDEF)

A strong stability preserving (SSP) third-order Runge-Kutta time stepper.

This time stepper uses the classic SSP RK3 scheme ([Shu-Osher 2006](@cite Shu1988Efficient) form):

```math
\\begin{align*}
u^{(1)} &= u^{(0)} + Δt \\, G(u^{(0)}) \\\\
u^{(2)} &= \\frac{3}{4} u^{(0)} + \\frac{1}{4} u^{(1)} + \\frac{1}{4} Δt \\, G(u^{(1)}) \\\\
u^{(3)} &= \\frac{1}{3} u^{(0)} + \\frac{2}{3} u^{(2)} + \\frac{2}{3} Δt \\, G(u^{(2)})
\\end{align*}
```

where ``G`` above is the right-hand-side, e.g., ``\\partial_t u = G(u)``.

Each stage can be written in the form:
```math
u^{(m)} = (1 - α) u^{(0)} + α \\left[u^{(m-1)} + Δt \\, G(u^{(m-1)}) \\right]
```
with ``α = 1, 1/4, 2/3`` for stages 1, 2, 3 respectively.

This scheme has CFL coefficient equal to 1 and it is TVD (total variation diminishing).

Fields
======

- `α¹, α², α³`: Stage coefficients (1, 1/4, 2/3)
- `U⁰`: Storage for state at beginning of time step
- `Gⁿ`: Tendency fields at current stage
- `implicit_solver`: Optional implicit solver for diffusion
- `rounding`: Round-off treatment of the stage updates, [`RoundToNearest`](@ref) or
  [`StochasticRounding`](@ref Breeze.RoundingTreatments.StochasticRounding)
"""
struct SSPRungeKutta3{FT, U0, TG, TI, R} <: AbstractTimeStepper
    α¹ :: FT
    α² :: FT
    α³ :: FT
    U⁰ :: U0
    Gⁿ :: TG
    implicit_solver :: TI
    rounding :: R
end

"""
$(TYPEDSIGNATURES)

Construct an `SSPRungeKutta3` on `grid` with `prognostic_fields` as described
by [Shu and Osher (1988)](@cite Shu1988Efficient).

Keyword Arguments
=================

- `implicit_solver`: Optional implicit solver for diffusion. Default: `nothing`
- `Gⁿ`: Tendency fields at current stage. Default: similar to `prognostic_fields`
- `U⁰`: Storage for the state at the beginning of the step. Default: similar to
  `prognostic_fields`. Accepting it as a keyword lets callers (e.g. the adiabatic-balance
  twin) alias another stepper's tendency storage instead of allocating fresh fields.
- `rounding`: Round-off treatment of the stage updates. Default: [`RoundToNearest`](@ref).
  With [`StochasticRounding`](@ref Breeze.RoundingTreatments.StochasticRounding), each stage is evaluated in increment form,
  ``u^{(m)} = u^{(0)} + α \\left[ (u^{(m-1)} - u^{(0)}) + Δt \\, G \\right]``, and the sum is
  rounded stochastically, so increments below the resolution of ``u`` are not lost on average.
  The vertically-implicit solves and the pressure correction stay round-to-nearest.

```jldoctest
using Oceananigans, Breeze

grid = RectilinearGrid(Float32; size=(4, 4, 4), extent=(1, 1, 1))
model = AtmosphereModel(grid; timestepper_kwargs = (; rounding = StochasticRounding(seed = 42)))
model.timestepper.rounding

# output
StochasticRounding(seed=42, summation=WidenedSum())
```

References
==========

Shu, C.-W., & Osher, S. (1988). Efficient implementation of essentially non-oscillatory
    shock-capturing schemes. Journal of Computational Physics, 77(2), 439-471.
"""
function SSPRungeKutta3(grid, prognostic_fields;
                        dynamics = nothing,
                        implicit_solver::TI = nothing,
                        cache_advecting_state = false,   # accepted for TimeStepper-call uniformity; unused
                        Gⁿ::TG = map(similar, prognostic_fields),
                        U⁰::U0 = map(similar, prognostic_fields),
                        rounding = RoundToNearest()) where {TI, TG, U0}

    FT = eltype(grid)
    rounding = materialize_rounding(rounding, grid.architecture)
    R = typeof(rounding)

    # SSP RK3 stage coefficients
    α¹ = FT(1)
    α² = FT(1//4)
    α³ = FT(2//3)

    return SSPRungeKutta3{FT, U0, TG, TI, R}(α¹, α², α³, U⁰, Gⁿ, implicit_solver, rounding)
end

#####
##### Stage update kernel
#####

"""
$(TYPEDSIGNATURES)

Apply an SSP RK3 substep with coefficient ``α``:
```math
u^{(m)} = (1 - α) u^{(0)} + α \\left[ u^{(m-1)} + Δt \\, G \\right]
```
where ``u^{(0)}`` is stored in the time stepper, ``u^{(m-1)}`` is the current field value,
and ``G`` is the current tendency. The sum is rounded by the time stepper's round-off treatment
(see [`StochasticRounding`](@ref Breeze.RoundingTreatments.StochasticRounding)).
"""
function ssp_rk3_substep!(model, Δt, α)
    grid = model.grid
    arch = grid.architecture
    U⁰ = model.timestepper.U⁰
    Gⁿ = model.timestepper.Gⁿ
    kernel_Δt = kernel_time_step(arch, grid, Δt)

    prognostic = prognostic_fields(model)
    names = keys(prognostic)
    thermodynamic_name = thermodynamic_density_name(model.formulation)
    rounding = model.timestepper.rounding

    for (field_number, (name, u, u⁰, G)) in enumerate(zip(names, prognostic, U⁰, Gⁿ))
        key = rounding_key(rounding, model.clock.iteration, model.clock.stage, field_number)
        launch_ssp_rk3_substep!(rounding, arch, grid, u, u⁰, G, kernel_Δt, α, key)

        # Dynamics-specific prognostics (the compressible dry density, the kinematic driver's
        # density) are advanced explicitly and have no diffusivity to apply; momentum and every
        # scalar take the solve, momentum with `field_index = nothing` (viscosity) and the
        # scalars with their position in the closure's scalar names (see `closure_scalar_index`).
        skip_vertical_diffusion(model, name) && continue

        # The thermodynamic variable's solve waits for the tracers' solves (see below).
        name === thermodynamic_name && continue

        implicit_stage_step!(model, name, u, α * Δt)
    end

    # The tracers' solves have just moved sedimenting condensate implicitly. Move its content
    # with it, from the state the solves produced, and only then solve the thermodynamic
    # variable, so the moved content takes the same transport and diffusion as the rest of the
    # field (see `implicit_sedimentation_step!`).
    isnothing(model.timestepper.implicit_solver) || implicit_sedimentation_step!(model, α * Δt, model.velocities)
    implicit_stage_step!(model, thermodynamic_name, prognostic[thermodynamic_name], α * Δt)

    return nothing
end

"""
$(TYPEDSIGNATURES)

Apply the vertically-implicit solve of the prognostic `u` named `name` over `Δt`: the
first-order upwind remainder of adaptive implicit vertical advection and the vertically-implicit
closure diffusion, in one tridiagonal system. A no-op when the time stepper has no implicit solver.
"""
function implicit_stage_step!(model, name, u, Δt)
    # The implicit solve must carry the reference density whenever it runs at all: the
    # diffusion half is mass-flux weighted for the z-Center prognostics, and adaptive implicit
    # vertical advection adds a density-weighted advection contribution on top.
    #
    # The guard is on the *solver*, not on `needs_implicit_solver(advection)`: that predicate
    # is false for `advection = nothing` and for ordinary WENO, so keying on it would drop the
    # density, and hence the mass-flux weighting, for every vertically-implicit closure
    # without adaptive-implicit advection, the single-column configuration included.
    isnothing(model.timestepper.implicit_solver) && return nothing

    field_index = closure_scalar_index(model, name)
    advection = field_advection_scheme(model.advection, name)

    implicit_step!(u,
                   model.timestepper.implicit_solver,
                   model.closure,
                   model.closure_fields,
                   field_index,
                   model.clock,
                   fields(model),
                   Δt,
                   implicit_step_scheme(advection),
                   implicit_advection_velocities(model.dynamics, model.velocities, name,
                                                 model.microphysics, model.microphysical_fields),
                   implicit_advection_density(model.dynamics, model.formulation, name))

    return nothing
end

# Round-to-nearest keeps the original Shu-Osher kernel, so the default is bitwise unchanged.
launch_ssp_rk3_substep!(::RoundToNearest, arch, grid, u, u⁰, G, Δt, α, key) =
    launch!(arch, grid, :xyz, _ssp_rk3_substep!, u, u⁰, G, Δt, α)

launch_ssp_rk3_substep!(rounding, arch, grid, u, u⁰, G, Δt, α, key) =
    launch!(arch, grid, :xyz, _rounded_ssp_rk3_substep!, u, u⁰, G, Δt, α, rounding, key)

@kernel function _ssp_rk3_substep!(u, u⁰, G, Δt, α)
    i, j, k = @index(Global, NTuple)
    @inbounds begin
        # u^(m) = (1 - α) * u^(0) + α * (u^(m-1) + Δt * G)
        u[i, j, k] = (1 - α) * u⁰[i, j, k] + α * (u[i, j, k] + Δt * G[i, j, k])
    end
end

# The same stage in increment form, u^(m) = u^(0) + δ with δ = α [(u^(m-1) - u^(0)) + Δt G],
# so the only rounding that matters, that of u^(0) + δ, is done by `rounded_add`. The difference
# u^(m-1) - u^(0) is exact (Sterbenz) whenever the two are within a factor of two.
@kernel function _rounded_ssp_rk3_substep!(u, u⁰, G, Δt, α, rounding, key)
    i, j, k = @index(Global, NTuple)
    @inbounds begin
        u⁰ᵢ = u⁰[i, j, k]
        δ = α * ((u[i, j, k] - u⁰ᵢ) + Δt * G[i, j, k])
        u[i, j, k] = rounded_add(rounding, u⁰ᵢ, δ, i, j, k, key)
    end
end

"""
$(TYPEDSIGNATURES)

Copy prognostic fields to `U⁰` storage for use in later RK3 stages.
"""
function store_initial_state!(model)
    U⁰ = model.timestepper.U⁰
    for (u⁰, u) in zip(U⁰, prognostic_fields(model))
        parent(u⁰) .= parent(u)
    end
    return nothing
end

#####
##### Time stepping
#####

"""
$(TYPEDSIGNATURES)

Step forward `model` one time step ``Δt`` with the SSP RK3 method.

The algorithm is:

```math
\\begin{align*}
u^{(1)} &= u^{(0)} + Δt \\, G(u^{(0)}) \\\\
u^{(2)} &= \\frac{3}{4} u^{(0)} + \\frac{1}{4} u^{(1)} + \\frac{1}{4} Δt \\, G(u^{(1)}) \\\\
u^{(3)} &= \\frac{1}{3} u^{(0)} + \\frac{2}{3} u^{(2)} + \\frac{2}{3} Δt \\, G(u^{(2)})
\\end{align*}
```

where ``G`` above is the right-hand-side, e.g., ``∂u/∂t = G(u)``.

The tendencies are evaluated at the Butcher abscissae ``c = (0, 1, 1/2)``: ``u^{(2)}``
approximates the solution at the *midpoint* of the step, so the clock steps back by ``Δt/2``
after the second stage. This keeps third-order accuracy for a time-dependent right-hand side.
"""
function OceananigansTimeSteppers.time_step!(model::AtmosphereModel{<:Any, <:Any, <:Any, <:SSPRungeKutta3}, Δt; callbacks=[])

    # Be paranoid and prepare at iteration 0, in case run! is not used:
    maybe_prepare_first_time_step!(model, Δt, callbacks)

    ts = model.timestepper
    α¹ = ts.α¹
    α² = ts.α²
    α³ = ts.α³

    # Stage abscissae: a Shu-Osher stage u^(m) = (1 - α) u^(0) + α (u^(m-1) + Δt G) has
    # Butcher row sum cₘ = αₘ (cₘ₋₁ + 1), so u^(1) sits at tⁿ + Δt but u^(2) sits at
    # tⁿ + Δt/2. Evaluating G(u^(2)) at tⁿ + Δt instead breaks the order conditions
    # (Σbᵢcᵢ = 5/6 ≠ 1/2) and leaves `clock.stage` stuck at 2, so per-stage work keyed on
    # `(iteration, stage)`, such as the filtered surface state, skips the third stage.
    c¹ = α¹              # = 1
    c² = α² * (c¹ + 1)   # = 1/2

    # Compute the next time step a priori to reduce floating point error accumulation
    tⁿ⁺¹ = model.clock.time + Δt

    # Store u^(0) for use in stages 2 and 3
    store_initial_state!(model)

    #
    # First stage: u^(1) = u^(0) + Δt * G(u^(0))
    #

    compute_flux_bc_tendencies!(model)
    compute_closure_tendencies!(model)
    ssp_rk3_substep!(model, Δt, α¹)

    compute_pressure_correction!(model, Δt)
    make_pressure_correction!(model, Δt)

    tick_stage!(model.clock, c¹ * Δt)
    update_state!(model, callbacks; compute_tendencies = true)

    #
    # Second stage: u^(2) = 3/4 u^(0) + 1/4 (u^(1) + Δt * G(u^(1)))
    #

    compute_flux_bc_tendencies!(model)
    compute_closure_tendencies!(model)
    ssp_rk3_substep!(model, Δt, α²)

    compute_pressure_correction!(model, α² * Δt)
    make_pressure_correction!(model, α² * Δt)

    # Back to tⁿ + Δt/2, the abscissa of u^(2); `corrected_Δt` below restores the Δt/2.
    tick_stage!(model.clock, (c² - c¹) * Δt)
    update_state!(model, callbacks; compute_tendencies = true)

    #
    # Third stage: u^(3) = 1/3 u^(0) + 2/3 (u^(2) + Δt * G(u^(2)))
    #

    compute_flux_bc_tendencies!(model)
    compute_closure_tendencies!(model)
    ssp_rk3_substep!(model, Δt, α³)

    compute_pressure_correction!(model, α³ * Δt)
    make_pressure_correction!(model, α³ * Δt)

    # Adjust final time-step to reduce floating point error accumulation
    corrected_Δt = time_difference_seconds(tⁿ⁺¹, model.clock.time)
    tick_stage!(model.clock, corrected_Δt, Δt)

    step_closure_prognostics!(model.closure_fields, model.closure, model, Δt)

    update_state!(model, callbacks; compute_tendencies = true)

    # Apply the operator-split microphysics update exactly once per step, on the post-RK
    # state just refreshed by `update_state!`. A no-op for tendency-interface schemes.
    microphysics_model_update!(model.microphysics, model)

    # Advect particles once per step, over the full Δt, with the velocity of the state
    # just refreshed to tⁿ⁺¹: Xⁿ⁺¹ = Xⁿ + Δt u(Xⁿ, tⁿ⁺¹) — consistent, but first order,
    # and so lower order than the dycore. A stage-wise update is possible in principle
    # (X obeys dX/dt = u like any prognostic, so the SSP combination applies to it too),
    # but would need Xⁿ stored alongside the current position, since every SSP stage
    # recombines with u⁰. Oceananigans' low-storage RK3 needs no such storage only
    # because its per-stage increments sum to Δt; the SSP stage coefficients do not
    # (α¹ + α² + α³ = 23/12), so pushing with them stage by stage would be wrong.
    step_lagrangian_particles!(model, Δt)

    return nothing
end

Oceananigans.prognostic_state(::SSPRungeKutta3) = nothing
Oceananigans.restore_prognostic_state!(timestepper::SSPRungeKutta3, ::Nothing) = timestepper
