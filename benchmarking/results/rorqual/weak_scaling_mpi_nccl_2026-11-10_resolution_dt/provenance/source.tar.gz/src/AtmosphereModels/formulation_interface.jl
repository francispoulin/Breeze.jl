#####
##### Thermodynamic Formulation Interface
#####
##### This file defines the interface that all thermodynamic formulation implementations must provide.
##### These functions are called by the AtmosphereModel constructor and update_state! pipeline.
#####

#####
##### Construction interface
#####

"""
    materialize_formulation(formulation, dynamics, grid, boundary_conditions)

Materialize a thermodynamic formulation from a `Symbol` (or formulation struct) into a
complete formulation with all required fields.

Valid symbols:
- `:LiquidIcePotentialTemperature`, `:θ`, `:ρθ`, `:PotentialTemperature` → `LiquidIcePotentialTemperatureFormulation`
- `:StaticEnergy`, `:s`, `:ρs` → `StaticEnergyFormulation`
"""
function materialize_formulation end

materialize_formulation(formulation_name::Symbol, args...) =
    materialize_formulation(Val(formulation_name), args...)

#####
##### Temperature solver interface
#####

"""
$(TYPEDEF)

Sentinel indicating that a formulation's temperature solver should be chosen by the
dynamics: `materialize_formulation` replaces it with
[`default_temperature_solver(dynamics)`](@ref default_temperature_solver).
"""
struct DefaultTemperatureSolver end

Base.summary(::DefaultTemperatureSolver) = "DefaultTemperatureSolver"

"""
$(TYPEDSIGNATURES)

Return the default solver for a formulation's temperature inversion given `dynamics`.

The need for an iterative inversion is dictated by the intersection of the dynamics and
the thermodynamic formulation: the fallback returns `nothing` (closed-form, no iteration),
and dynamics whose prognostic closure makes the inversion implicit (e.g.
`CompressibleDynamics` with `LiquidIcePotentialTemperatureFormulation`, where temperature
solves `cᵖᵐ T = ĉᵖ (ρ Rᵐ T / pˢᵗ)^κ θ + ℒˡ₀ qˡ + ℒⁱ₀ qⁱ`) extend this function to return an iterative solver.
"""
default_temperature_solver(dynamics) = nothing

#####
##### Exner exponent interface
#####

"""
$(TYPEDSIGNATURES)

Return the Exner exponent ([`VaporEquivalentExponent`](@ref Breeze.Thermodynamics.VaporEquivalentExponent)
or [`DryExponent`](@ref Breeze.Thermodynamics.DryExponent)) that defines the liquid-ice potential
temperature ``θˡⁱ`` of `formulation`. A formulation that does not evolve ``θˡⁱ``, and the symbol
`:LiquidIcePotentialTemperature`, return the default `VaporEquivalentExponent()`, so diagnostics
and boundary-flux conversions of ``θˡⁱ`` agree with the definition the formulation evolves.
"""
liquid_ice_exner_exponent(formulation) = VaporEquivalentExponent()

#####
##### Field naming interface
#####

"""
    prognostic_thermodynamic_field_names(formulation)

Return a tuple of prognostic field names for the given thermodynamic formulation.
Accepts a `Symbol`, `Val(Symbol)`, or formulation struct.
"""
function prognostic_thermodynamic_field_names end

prognostic_thermodynamic_field_names(formulation_name::Symbol) =
    prognostic_thermodynamic_field_names(Val(formulation_name))

"""
    additional_thermodynamic_field_names(formulation)

Return a tuple of additional (diagnostic) field names for the given thermodynamic formulation.
Accepts a `Symbol`, `Val(Symbol)`, or formulation struct.
"""
function additional_thermodynamic_field_names end

additional_thermodynamic_field_names(formulation_name::Symbol) =
    additional_thermodynamic_field_names(Val(formulation_name))

"""
    thermodynamic_density_name(formulation)

Return the name of the thermodynamic density field (e.g., `:ρθ`, `:ρs`, `:ρE`).
Accepts a `Symbol`, `Val(Symbol)`, or formulation struct.
"""
function thermodynamic_density_name end

"""
    specific_thermodynamic_field(formulation)

Return the specific (per unit mass) thermodynamic field the `formulation` evolves — what its
advection operator reconstructs, as opposed to the density-weighted prognostic named by
[`thermodynamic_density_name`](@ref).
"""
function specific_thermodynamic_field end

thermodynamic_density_name(formulation::Symbol) = thermodynamic_density_name(Val(formulation))

"""
    total_energy_density_name

The key under which an *energy* input — a surface heat flux, a diabatic heating rate — is
supplied to `AtmosphereModel`, `:ρE`, along with its specific alias `:E` for forcings.

``E`` denotes total energy (`total_energy`), so the key names the physical input without
committing to the variable that carries it: a `boundary_conditions` or `forcing` entry keyed
`ρE` is routed onto whichever thermodynamic density the formulation evolves (see
[`thermodynamic_density_name`](@ref)), converted as that variable requires — divided by
``ĉᵖ Π`` for ``ρθ``, whether it arrives as a flux or as a forcing, and passed through
unconverted for ``ρs``, which is itself an energy per unit mass.

``s`` names static energy specifically and ``e`` is reserved for turbulent kinetic energy, so
neither doubles as the energy key: `ρs` is a valid key only when static energy *is* the
prognostic thermodynamic variable.
"""
const total_energy_density_name = :ρE

"""
    thermodynamic_density(formulation)

Return the thermodynamic density field for the given formulation — the prognostic
thermodynamic variable in continuity-density-weighted ("flux") form (`ρθ`, `ρs`, `ρE`).

The weighting density is the dynamics' continuity density (see [`continuity_density`](@ref)):
the reference density `ρᵣ` on the anelastic core and the prognostic dry-air density `ρᵈ` on the
compressible core. The generic name (`ρθ`) is therefore `ρᵈθ` on `CompressibleDynamics`; the
intensive variable is recovered as `θ = ρθ / continuity_density(dynamics)`.
"""
function thermodynamic_density end

"""
    with_thermodynamic_density(formulation, ρᵡ)

Return a copy of `formulation` whose thermodynamic density field (see [`thermodynamic_density`](@ref))
is replaced by `ρᵡ`, leaving the diagnostic fields and solvers untouched. Used to swap in a
thermodynamic field carrying different boundary conditions without reallocating the diagnostics.
"""
function with_thermodynamic_density end

#####
##### Prognostic field collection
#####

"""
    collect_prognostic_fields(formulation, dynamics, momentum, moisture_density, microphysical_fields, tracers)

Collect all prognostic fields into a single NamedTuple.
"""
function collect_prognostic_fields end

#####
##### State computation interface
#####

"""
    compute_auxiliary_thermodynamic_variables!(formulation, dynamics, i, j, k, grid)

Compute auxiliary thermodynamic variables from prognostic fields at grid point `(i, j, k)`.
"""
function compute_auxiliary_thermodynamic_variables! end

"""
    diagnose_thermodynamic_state(i, j, k, grid, formulation, dynamics, q)

Diagnose the thermodynamic state at grid point `(i, j, k)` from the given `formulation`,
`dynamics`, and pre-computed moisture mass fractions `q`.

!!! warning "Moisture mass fractions computation"
    This function does _not_ compute moisture fractions internally to avoid circular dependencies.
    The caller is responsible for computing [`q = grid_moisture_fractions(...)`](@ref grid_moisture_fractions)
    before passing `q` to this function.
"""
function diagnose_thermodynamic_state end

#####
##### Tendency computation interface
#####

"""
    compute_thermodynamic_tendency!(model, common_args, tracer_transport_velocity)

Compute the thermodynamic tendency. Dispatches on the thermodynamic formulation type.
`common_args` are the arguments the scalar tendencies share, and `tracer_transport_velocity` the
vertical velocity the moisture and tracer tendencies were built with, which the condensate
sedimentation term pairs its content fluxes with (see
[`sedimentation_tendency`](@ref)). The two need not agree: a time stepper may advect
the thermodynamic variable with a velocity its tracers do not share.
"""
function compute_thermodynamic_tendency! end

#####
##### Set thermodynamic variable interface
#####

"""
    set_thermodynamic_variable!(model, variable_name, value)

Set a thermodynamic variable (e.g., `:θ`, `:T`, `:s`, `:ρθ`, `:ρs`) from the given value.
Dispatches on the thermodynamic formulation type and variable name.
"""
function set_thermodynamic_variable! end

#####
##### Helper accessor functions
#####

"""
    static_energy(model)

Return the specific static energy field for the given model.
"""
function static_energy end

"""
    static_energy_density(model)

Return the static energy density field for the given model.

For `LiquidIcePotentialTemperatureFormulation`, returns a `Field` with boundary conditions
that convert potential temperature fluxes to energy fluxes. This allows users to use
`BoundaryConditionOperation` to extract energy flux values from the model.

For `StaticEnergyFormulation`, returns the prognostic energy density field directly.
"""
function static_energy_density end

"""
    liquid_ice_potential_temperature(model)

Return the liquid-ice potential temperature field for the given model.
"""
function liquid_ice_potential_temperature end

"""
    liquid_ice_potential_temperature_density(model)

Return the liquid-ice potential temperature density field for the given model.
"""
function liquid_ice_potential_temperature_density end
