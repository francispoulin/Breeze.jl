using Breeze.Thermodynamics: MoistureMassFractions, dry_air_gas_constant, vapor_gas_constant, absolute_zero_latent_heat,
                             VaporEquivalentExponent, density

#####
##### Dynamics Interface
#####
##### This file defines the interface that all dynamics implementations must provide.
##### These functions are called by the AtmosphereModel constructor and
##### must be extended by specific dynamics implementations (AnelasticEquations, CompressibleEquations).
#####

#####
##### Construction interface
#####

"""
    default_dynamics(grid, constants)

Return the default dynamics for the given grid and thermodynamic constants.
"""
function default_dynamics end

"""
    materialize_dynamics(dynamics_stub, grid, boundary_conditions, thermodynamic_constants, microphysics, formulation)

Materialize a dynamics stub into a complete dynamics object with all required fields.

The `microphysics` and `formulation` arguments select the parcel's prognostic state.
"""
function materialize_dynamics end

# Default: ignore microphysics argument (for backward compatibility)
materialize_dynamics(d, grid, bcs, constants, microphysics) = materialize_dynamics(d, grid, bcs, constants)
materialize_dynamics(d, grid, bcs, constants, microphysics, formulation) = materialize_dynamics(d, grid, bcs, constants, microphysics)

"""
    materialize_momentum_and_velocities(dynamics, grid, boundary_conditions)

Create momentum and velocity fields for the given dynamics.
"""
function materialize_momentum_and_velocities end

"""
    materialize_velocities(velocities, grid)

Create velocity fields from a velocity specification (e.g., `PrescribedVelocityFields`).
"""
function materialize_velocities end

"""
    update_dynamics_with_velocities(dynamics, velocities)

Update dynamics with velocity specification. Default is a no-op.
For `PrescribedDynamics`, stores the `PrescribedVelocityFields` for dispatch.
"""
update_dynamics_with_velocities(dynamics, velocities) = dynamics

"""
    dynamics_pressure_solver(dynamics, grid)

Create the pressure solver for the given dynamics.
Returns `nothing` for dynamics that do not require a pressure solver (e.g., compressible).
"""
function dynamics_pressure_solver end

"""
    update_pressure_solver!(solver, dynamics)

Recompute the parts of `solver` that depend on the state of `dynamics`, such as its reference density.
Default is a no-op.
"""
update_pressure_solver!(solver, dynamics) = nothing

"""
$(TYPEDSIGNATURES)

Return the default timestepper symbol for the given dynamics.

For anelastic dynamics or compressible dynamics with explicit timestepping, returns `:SSPRungeKutta3`.
For compressible dynamics with acoustic substepping, returns `:AcousticRungeKutta3`.
"""
default_timestepper(dynamics) = :SSPRungeKutta3

#####
##### Pressure correction interface
#####

"""
$(TYPEDSIGNATURES)

Compute the pressure correction for the given model. Default: no-op.
For anelastic dynamics, solves the pressure Poisson equation.
"""
compute_pressure_correction!(model, Δt) = nothing

"""
$(TYPEDSIGNATURES)

Apply the pressure correction to the momentum fields. Default: no-op.
For anelastic dynamics, projects momentum to enforce the divergence constraint.
"""
make_pressure_correction!(model, Δt) = nothing

#####
##### Pressure interface
#####

"""
    dynamics_pressure(dynamics)

Return the pressure field appropriate to the dynamical formulation, in Pa — the pressure
entering the equation of state, buoyancy, and the thermodynamic tendencies.

For anelastic dynamics, this is the time-independent hydrostatic reference pressure ``pᵣ(z)``,
excluding the non-hydrostatic pressure anomaly that enforces the divergence constraint but does
not perturb the thermodynamic state. For compressible dynamics, this is the diagnosed
equation-of-state pressure. The anomaly and total-pressure counterparts are
[`pressure_anomaly`](@ref) and [`total_pressure`](@ref).

This is the pressure every physics parameterization should read, including radiation. Call the
accessor rather than reaching into `dynamics.reference_state` directly: which of the two the
reference state *is* varies by formulation. On the anelastic core it is the thermodynamic
pressure, and `dynamics_pressure` returns it. On the compressible core (flat or terrain) it is a
pressure-gradient device built once from a fixed profile, it does not track the thermodynamic
state, and several dynamics types carry none at all. [`total_density`](@ref) is the density
counterpart.
"""
function dynamics_pressure end

"""
    pressure_anomaly(dynamics)

Return the pressure anomaly (deviation from mean) in Pa.
"""
function pressure_anomaly end

"""
    total_pressure(dynamics)

Return the total pressure (mean + anomaly) in Pa.
"""
function total_pressure end

"""
$(TYPEDSIGNATURES)

Return pressure consistent with a prescribed temperature during thermodynamic initialization.

The default retains [`dynamics_pressure`](@ref) (appropriate for anelastic/reference-pressure
models, where pressure is not a function of the state being set). Compressible dynamics overrides
this with the equation of state `p = ρ Rᵐ T`, avoiding a fixed-point error when density or
composition was changed immediately before setting temperature.
"""
@inline function pressure_from_density_temperature(i, j, k, grid, dynamics, ρ, T, q, constants)
    return @inbounds dynamics_pressure(dynamics)[i, j, k]
end

#####
##### Density and pressure access interface
#####

"""
    continuity_density(dynamics)

Return the *continuity density*: the density whose continuity equation the model solves,
``∇·(ρᵣ u) = 0`` on the anelastic core and ``∂ₜρᵈ + ∇·(ρᵈ u) = 0`` on the compressible core.
Momentum and the thermodynamic variable are stored per unit of it (`ρu = ρᵈ u`, `ρθ = ρᵈ θ`), so it
is also the divisor for diagnosing velocity (`u = ρu/ρᵈ`) and potential temperature (`θ = ρθ/ρᵈ`).

- `AnelasticDynamics`: the time-independent reference density `ρᵣ`.
- `CompressibleDynamics`: the prognostic dry-air density `ρᵈ`.

The *total* air density `ρ = ρᵈ + Σ ρˣ` (dry air plus every water species) is a separate quantity,
[`total_density`](@ref): it recovers the moisture mass fractions (`qˣ = ρˣ/ρ`) and weights scalar and
water advection. The water densities (`ρqᵛ`, `ρqˡ`, …) are stored as partial densities (mass per
volume), not per unit of the continuity density. On the anelastic core the two densities coincide
(`total_density === continuity_density`).
"""
function continuity_density end

"""
    total_density(dynamics)

Return the model's total air density ρ = ρᵈ + Σρˣ: the density of the model's mass, which
converts the stored partial densities to mass fractions (``qˣ = ρqˣ / ρ``) and weights scalar
advection, hydrostatics and radiation. `CompressibleDynamics` diagnoses it from the prognostic
dry density and the partial densities. Defaults to [`continuity_density`](@ref), so on
`AnelasticDynamics` it is the reference density ``ρᵣ(z)``: the anelastic approximation replaces
the total density by ``ρᵣ``, consistent with the reference pressure ``pᵣ``.

Thermodynamic relations of the local state, such as the saturation specific humidity, use
[`thermodynamic_state_density`](@ref) instead.
"""
total_density(dynamics) = continuity_density(dynamics)

"""
$(TYPEDSIGNATURES)

Return the change of the moisture mass fractions per unit mass of condensate `phase` that
sediments out of a cell whose mass fractions are `q`, as a `MoistureMassFractions` difference
vector (the dry-air change is implied by `Σq = 1`). Continuity advances the continuity density
([`continuity_density`](@ref)) without a sedimentation source on every core, so the increment
depends on what the total density does:

- fixed (the default; `AnelasticDynamics`): the total density the mass fractions are referenced
  to does not respond, so the dry mass fraction `qᵈ = 1 − qᵛ − qˡ − qⁱ` makes up the departed mass
  and the increment is `q̂ˣ − q̂ᵈ`, with `q̂ˣ` the composition with all mass in `x`;
- diagnosed and falling with the condensate (`CompressibleDynamics`: prognostic dry density
  `ρᵈ`, `ρ = ρᵈ + Σρˣ`): every mass fraction renormalizes and the increment is `q̂ˣ − q`.

[`condensate_content`](@ref) differentiates the thermodynamic variable along this increment,
`∂φ/∂qˣ = ∇_q φ · Δq`: the content per unit falling mass at which the cell the condensate leaves
keeps its temperature.
"""
@inline sedimentation_composition_increment(dynamics, q, phase) = unit_composition(phase, q)

# The composition with all mass in one phase, q̂ˣ, typed like `q`
@inline unit_composition(::Val{:liquid}, q) = MoistureMassFractions(zero(q.vapor), one(q.vapor), zero(q.vapor))
@inline unit_composition(::Val{:ice}, q) = MoistureMassFractions(zero(q.vapor), zero(q.vapor), one(q.vapor))

# Changes of the mixture properties along a composition increment Δq, whose dry-air entry is
# Δqᵈ = −(Δqᵛ + Δqˡ + Δqⁱ)
@inline dry_air_increment(Δq) = -(Δq.vapor + Δq.liquid + Δq.ice)

@inline heat_capacity_increment(Δq, constants) =
    dry_air_increment(Δq) * constants.dry_air.heat_capacity + Δq.vapor * constants.vapor.heat_capacity +
    Δq.liquid * constants.liquid.heat_capacity + Δq.ice * constants.ice.heat_capacity

# The enthalpy of the mixture per unit mass changes along Δq at fixed temperature by
# Δcᵖ T − ΔHᶜ, using zero-kelvin latent offsets: the enthalpy of the condensate
# relative to what its mass gives way to
@inline enthalpy_increment(Δq, constants, T) =
    heat_capacity_increment(Δq, constants) * T -
    Δq.liquid * absolute_zero_latent_heat(constants, constants.liquid) -
    Δq.ice * absolute_zero_latent_heat(constants, constants.ice)

"""
$(TYPEDSIGNATURES)

Return the density of the local thermodynamic state at `(i, j, k)`, with temperature `T` and
moisture mass fractions `q`. This is the density in the equation of state, ``p = ρ Rᵐ T``, and the
one the saturation specific humidity ``qᵛ⁺ = pᵛ⁺ / (ρ Rᵛ T)`` is referenced to, so microphysics
schemes and saturation diagnostics evaluate saturation with it.

It is the *total* density, condensate loading included: ``Rᵐ(q) = qᵈ Rᵈ + qᵛ Rᵛ`` uses
``qᵈ = 1 - qᵛ - qˡ - qⁱ``, so ``p / (Rᵐ(q) T)`` is the total, not the gas-phase density
``ρᵈ + ρᵛ``.

The default returns [`total_density`](@ref), which is the state density on `CompressibleDynamics`.
Dynamics closed on a reference or prescribed pressure (`AnelasticDynamics`, `PrescribedDynamics`)
override it with [`fixed_pressure_state_density`](@ref), ``p / (Rᵐ T)``. On the anelastic core
this differs from ``total_density = ρᵣ`` wherever ``T`` or ``q`` depart from the reference state,
and it is the density whose departure from ``ρᵣ`` is the anelastic buoyancy.
"""
@inline function thermodynamic_state_density(i, j, k, dynamics, T, q, constants)
    return @inbounds total_density(dynamics)[i, j, k]
end

"""
$(TYPEDSIGNATURES)

Return the equation-of-state density ``p / (Rᵐ(q) T)`` at the pressure
[`dynamics_pressure`](@ref) of `dynamics` at `(i, j, k)`, with temperature `T` and moisture mass
fractions `q`. Dynamics closed on a reference or prescribed pressure extend
[`thermodynamic_state_density`](@ref) with it, since their total density is not the local state's.
"""
@inline function fixed_pressure_state_density(i, j, k, dynamics, T, q, constants)
    p = @inbounds dynamics_pressure(dynamics)[i, j, k]
    return density(T, p, q, constants)
end

"""
    advecting_vertical_velocity(dynamics, velocities)

Return the vertical velocity that advects momentum through the grid's coordinate surfaces:
the Cartesian `velocities.w` on height-coordinate grids, and the contravariant vertical
velocity `w̃` on terrain-following grids (mirroring [`advecting_momentum`](@ref), whose
vertical component is the contravariant momentum). The adaptive-implicit vertical-advection
split must partition this velocity on both the explicit (flux-scaling) and implicit
(tridiagonal) sides, so it stays consistent with the momentum flux divergence.
"""
@inline advecting_vertical_velocity(dynamics, velocities) = velocities.w

#####
##### Buoyancy interface
#####

"""
    buoyancy_forceᶜᶜᶜ(i, j, k, grid, dynamics, temperature,
                      specific_prognostic_moisture, microphysics, microphysical_fields, constants)

Compute the buoyancy force density ``ρ b`` at cell center `(i, j, k)`.

This function is used in the vertical momentum equation to compute the gravitational
forcing term.

"""
function buoyancy_forceᶜᶜᶜ end

#####
##### Boundary condition interface
#####

"""
    validate_velocity_boundary_conditions(dynamics, user_boundary_conditions)

Validate that velocity boundary conditions are only provided for dynamics that support them.

By default, throws an error if the user provides boundary conditions for `:u`, `:v`, or `:w`,
since velocity is a diagnostic field for most dynamics (e.g., anelastic, compressible).

For `PrescribedDynamics`, velocity boundary conditions are allowed since velocities are
regular fields that can be set directly.
"""
function validate_velocity_boundary_conditions(dynamics, user_boundary_conditions)
    velocity_names = (:u, :v, :w)
    user_bc_names = keys(user_boundary_conditions)
    provided_velocity_bcs = filter(name -> name ∈ user_bc_names, velocity_names)

    if !isempty(provided_velocity_bcs)
        throw(ArgumentError(
            "Boundary conditions for velocity components $(provided_velocity_bcs) are not supported " *
            "for $(summary(dynamics)). Velocity boundary conditions are only valid for PrescribedDynamics " *
            "(kinematic models) where velocities are regular fields. For prognostic dynamics, " *
            "set boundary conditions on momentum fields (:ρu, :ρv, :ρw) instead."
        ))
    end
    return nothing
end

"""
    base_pressure(dynamics)

Return the pressure of the reference atmosphere at ``z = 0``: the datum its hydrostatic profiles
are anchored to, and a property of that atmosphere rather than of the grid. Always a scalar.

This is not the pressure at the ground. On a domain whose bottom does not sit at ``z = 0`` — a
raised height-coordinate domain, or any terrain-following grid — the two differ by ``O(ρgh)``.
For the pressure at the ground, which is what a column integration is anchored at, use
[`surface_pressure`](@ref).
"""
function base_pressure end

"""
    surface_pressure(dynamics)

Return the pressure of the reference atmosphere at the bottom face of each column — the ground —
obtained by reducing the [`base_pressure`](@ref) datum to that height along the reference profile,
as a 2D ``(Center, Center, Nothing)`` field. Horizontally uniform for a single-column reference on
a height-coordinate grid; genuinely column-dependent when the reference thermodynamics varies
horizontally or on a terrain-following grid, where the bottom face is the terrain surface.

This is the anchor for a hydrostatic column integration, and what every consumer of "the pressure
at the surface" over terrain wants. Reading it keeps a consumer consistent with the reference
state; reading the datum instead disagrees with it by ``O(ρgh)`` per column.

Equal to the datum, exactly, for the usual domain whose bottom sits at ``z = 0``. Extended by each
dynamics that carries a materialized reference state; dynamics without one have no reference
surface pressure to report. When the pressure should follow the live model state instead,
extrapolate it from the first cell center with `Thermodynamics.surface_pressure_from_cell_center`,
as the surface fluxes and the diagnostic hydrostatic pressure do.
"""
function surface_pressure end

"""
    dynamics_reference_state(dynamics)

Return the dynamics' reference state (an anelastic `ReferenceState` or a split-explicit
`ExnerReferenceState`), or `nothing` if the dynamics carries none. Dispatched so that
`reset_reference_state!` needn't reach into fields by name.
"""
dynamics_reference_state(dynamics) = nothing

"""
    standard_pressure(dynamics)

Return the standard pressure used for potential temperature calculations.
Default is 100000 Pa (1000 hPa).
"""
function standard_pressure end

"""
    default_drag_surface_temperature(dynamics, grid, thermodynamic_constants)

Return a default surface temperature for `BulkDrag` when the user has not supplied
one. Dispatched on the dynamics type because the notion of a "default" surface
temperature depends on what reference structure the dynamics carries: anelastic
has a full reference profile whose surface value is well-defined; compressible
has no equivalent up-front surface temperature and therefore requires the user
to provide one explicitly.

The default (no method) throws an informative error. Each dynamics type extends
this hook.
"""
default_drag_surface_temperature(dynamics, grid, thermodynamic_constants) =
    throw(ArgumentError(
        "BulkDrag was constructed without `surface_temperature`, and no default is " *
        "defined for dynamics of type `$(typeof(dynamics))`. Please pass " *
        "`surface_temperature` explicitly when constructing `BulkDrag`."))

"""
    initialize_model_thermodynamics!(model)

Initialize the thermodynamic state for a newly constructed model.
For anelastic dynamics, sets initial θ to the reference potential temperature.
For compressible dynamics, no default initialization is performed.
"""
initialize_model_thermodynamics!(model) = nothing  # default: do nothing

#####
##### Prognostic fields interface
#####

"""
    prognostic_momentum_field_names(dynamics)

Return a tuple of prognostic momentum field names.

For prognostic dynamics (anelastic, compressible), returns `(:ρu, :ρv, :ρw)`.
For kinematic dynamics (prescribed velocities), returns an empty tuple.
"""
prognostic_momentum_field_names(::Any) = (:ρu, :ρv, :ρw)

"""
    prognostic_dynamics_field_names(dynamics)

Return a tuple of prognostic field names specific to the dynamics formulation.

For anelastic dynamics, returns an empty tuple (no prognostic density).
For compressible dynamics, returns `(:ρᵈ,)` for prognostic density.
"""
prognostic_dynamics_field_names(::Any) = ()

"""
    additional_dynamics_field_names(dynamics)

Return a tuple of additional (diagnostic) field names for the dynamics.
"""
additional_dynamics_field_names(::Any) = ()

"""
    velocity_boundary_condition_names(dynamics)

Return a tuple of velocity field names that need default boundary conditions.

For most dynamics (anelastic, compressible), velocities are diagnostic and their boundary
conditions are created internally. Returns an empty tuple.

For `PrescribedDynamics`, velocities are regular fields that can have user-provided
boundary conditions, so this returns `(:u, :v, :w)`.
"""
velocity_boundary_condition_names(::Any) = ()

"""
    dynamics_prognostic_fields(dynamics)

Return a NamedTuple of prognostic fields specific to the dynamics formulation.

For anelastic dynamics, returns an empty NamedTuple.
For compressible dynamics, returns `(ρ=density_field,)`.
"""
dynamics_prognostic_fields(dynamics) = NamedTuple()

#####
##### Pressure gradient interface
#####

"""
    x_pressure_gradient(i, j, k, grid, dynamics)

Return the x-component of the pressure gradient force at (Face, Center, Center).

For anelastic dynamics, returns zero (pressure is handled via projection).
For compressible dynamics, returns `-∂p/∂x`.
"""
@inline x_pressure_gradient(i, j, k, grid, dynamics) = zero(grid)

"""
    y_pressure_gradient(i, j, k, grid, dynamics)

Return the y-component of the pressure gradient force at (Center, Face, Center).

For anelastic dynamics, returns zero (pressure is handled via projection).
For compressible dynamics, returns `-∂p/∂y`.
"""
@inline y_pressure_gradient(i, j, k, grid, dynamics) = zero(grid)

"""
    z_pressure_gradient(i, j, k, grid, dynamics)

Return the z-component of the pressure gradient force at (Center, Center, Face).

For anelastic dynamics, returns zero (pressure is handled via projection).
For compressible dynamics, returns `-∂p/∂z`.
"""
@inline z_pressure_gradient(i, j, k, grid, dynamics) = zero(grid)

#####
##### Slow dynamics for split-explicit time-stepping
#####

"""
$(TYPEDEF)

Wrapper type indicating that only "slow" tendencies should be computed.

When computing momentum tendencies with a `SlowDynamics`-wrapped dynamics,
the "fast" terms (pressure gradient and buoyancy) return zero. This is used
for split-explicit time-stepping where fast terms are handled separately
in an acoustic substep loop.

See also [`SplitExplicitTimeDiscretization`](@ref Breeze.CompressibleEquations.SplitExplicitTimeDiscretization).
"""
struct SlowDynamics{D}
    dynamics :: D
end

Adapt.adapt_structure(to, s::SlowDynamics) = SlowDynamics(adapt(to, s.dynamics))

# Forward continuity_density to the wrapped dynamics
@inline continuity_density(s::SlowDynamics) = continuity_density(s.dynamics)

# Fast terms return zero for slow dynamics
@inline x_pressure_gradient(i, j, k, grid, ::SlowDynamics) = zero(grid)
@inline y_pressure_gradient(i, j, k, grid, ::SlowDynamics) = zero(grid)
@inline z_pressure_gradient(i, j, k, grid, ::SlowDynamics) = zero(grid)

@inline buoyancy_forceᶜᶜᶜ(i, j, k, grid, ::SlowDynamics, args...) = zero(grid)

#####
##### Tendency computation interface
#####

"""
$(TYPEDSIGNATURES)

Compute tendencies for dynamics-specific prognostic fields.

For anelastic dynamics, this is a no-op (no prognostic density).
For compressible dynamics, this computes the density tendency from the continuity equation:

```math
\\partial_t \\rho = -\\boldsymbol{\\nabla \\cdot \\,} (\\rho \\boldsymbol{u})
```
"""
compute_dynamics_tendency!(model) = nothing  # default: no dynamics-specific tendencies

#####
##### Transport velocity/momentum interface (for terrain-following coordinates)
#####

"""
$(TYPEDSIGNATURES)

Return the velocity tuple used for scalar advection transport.

For standard (non-terrain) models, this is `model.velocities`.
For terrain-following coordinates, the vertical component is replaced
by the contravariant vertical velocity ``\\tilde{w}``.
"""
transport_velocities(model) = model.velocities

"""
$(TYPEDSIGNATURES)

Return the momentum tuple used for momentum advection transport
and the continuity equation divergence.

For standard (non-terrain) models, this is `model.momentum`.
For terrain-following coordinates, the vertical component `ρw` is
replaced by the contravariant vertical momentum ``\\rho \\tilde{w}``.
"""
advecting_momentum(model) = model.momentum

"""
$(TYPEDSIGNATURES)

Return the part of `dynamics` that `timestepper` integrates through its tendencies: all of it,
unless the time stepper integrates the pressure-gradient force and buoyancy separately, in which
case it returns `SlowDynamics(dynamics)`.
"""
slow_dynamics(timestepper, dynamics) = dynamics

"""
$(TYPEDSIGNATURES)

Return the velocity tuple used for thermodynamic-variable advection: `transport_velocities(model)`,
unless the time stepper advects the thermodynamic variable with a different velocity than
moisture and tracers.
"""
thermodynamic_transport_velocities(model) = transport_velocities(model)

#####
##### Auxiliary dynamics variables interface
#####

"""
$(TYPEDSIGNATURES)

Compute auxiliary (diagnostic) variables specific to the dynamics formulation.

For anelastic dynamics, this is a no-op (pressure is computed during time-stepping
via the pressure Poisson equation).

For compressible dynamics, this computes the pressure field from the equation of state:

```math
p = ρ R^m T
```

where ``R^m`` is the mixture gas constant.
"""
compute_auxiliary_dynamics_variables!(model) = nothing  # default: no-op
