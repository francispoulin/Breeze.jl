module BreezeRRTMGPExt

using Breeze
using Breeze.AtmosphereModels: GrayOptics, ClearSkyOptics, AllSkyOptics, ConstantRadiusParticles, materialize_surface_property,
                               dynamics_pressure, total_density, resolve_column_batch_rows,
                               column_index, compute_radiation_flux_divergence!,
                               validate_surface_fractions, constant_field_property, resolve_surface_albedos,
                               assert_bound_surface_temperature, maybe_infer_solar_position,
                               initialize_cos_zenith!, update_cos_zenith!, fill_columns!
using Breeze.Thermodynamics: ThermodynamicConstants
using Breeze.Utils: TYPEDSIGNATURES_WITH_DEFAULTS

using Oceananigans.Architectures: architecture, CPU, GPU, ReactantState
using Oceananigans.DistributedComputations: Distributed, child_architecture
using Oceananigans.Fields: ZFaceField, CenterField

# RRTMGP imports (external types - cannot modify)
#   GrayAtmosphericState: atmospheric state arrays (t_lay, p_lay, t_lev, p_lev, z_lev, t_sfc)
#   NoScatLWRTE, NoScatSWRTE: longwave/shortwave RTE solvers
#   FluxLW, FluxSW: flux storage (flux_up, flux_dn, flux_net, flux_dn_dir)
#   RRTMGPParameters: physical constants for RRTMGP

using RRTMGP: RRTMGP, RRTMGPGridParams
using RRTMGP.Parameters: Parameters, RRTMGPParameters
using RRTMGP.RTE: NoScatLWRTE, NoScatSWRTE
using RRTMGP.RTESolver: solve_lw!, solve_sw!

using ClimaComms: ClimaComms

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct `RRTMGPParameters` from Breeze's `ThermodynamicConstants`.
"""
function Parameters.RRTMGPParameters(constants::ThermodynamicConstants{FT};
                                     stefan_bolzmann_constant = 5.670374419e-8,  # W m⁻² K⁻⁴
                                     avogadro_number = 6.02214076e23) where FT  # mol⁻¹

    ϰᵈ = constants.dry_air.heat_capacity / constants.dry_air.molar_mass

    return Parameters.RRTMGPParameters(
        grav           = convert(FT, constants.gravitational_acceleration),
        molmass_dryair = convert(FT, constants.dry_air.molar_mass),
        molmass_water  = convert(FT, constants.vapor.molar_mass),
        gas_constant   = convert(FT, constants.molar_gas_constant),
        kappa_d        = convert(FT, ϰᵈ),
        Stefan         = convert(FT, stefan_bolzmann_constant),  # W m⁻² K⁻⁴
        avogad         = convert(FT, avogadro_number),   # mol⁻¹
    )
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Create an RRTMGP-compatible ClimaComms context from an Oceananigans architecture.
"""
function rrtmgp_context(arch::CPU)
    device = Threads.nthreads() > 1 ? ClimaComms.CPUMultiThreaded() : ClimaComms.CPUSingleThreaded()
    return ClimaComms.context(device)
end

function rrtmgp_context(arch::GPU)
    return ClimaComms.context(ClimaComms.CUDADevice())
end

# Radiation is column-local: each rank solves its own columns on its child architecture
rrtmgp_context(arch::Distributed) = rrtmgp_context(child_architecture(arch))

# RRTMGP allocates its lookup tables and workspace through ClimaComms, which has no device for Reactant's arrays
rrtmgp_context(::ReactantState) =
    throw(ArgumentError("RRTMGP radiation does not support ReactantState yet: RRTMGP allocates its lookup tables " *
                        "and workspace through ClimaComms, which has no device for Reactant's arrays."))

using Oceananigans.Utils: IterationInterval

include("gray_radiative_transfer_model.jl")
include("rrtmgp_shared_utilities.jl")
include("rrtmgp_column_batching.jl")
include("full_spectrum_radiative_transfer_model.jl")
include("clear_sky_radiative_transfer_model.jl")
include("all_sky_radiative_transfer_model.jl")

end # module
