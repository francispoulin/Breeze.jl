using Adapt: Adapt, adapt

using Oceananigans: Oceananigans, CenterField
using Oceananigans.Architectures: on_architecture
using Oceananigans.BoundaryConditions: fill_halo_regions!
using Oceananigans.Fields: ZeroField, set!, interpolate
using Oceananigans.TimeSteppers: TimeSteppers, tick_stage!
using Oceananigans.Utils: launch!, time_difference_seconds

using KernelAbstractions: @kernel, @index

using Breeze.Thermodynamics: MoistureMassFractions,
    LiquidIcePotentialTemperatureState, StaticEnergyState,
    PlanarLiquidSurface,
    with_moisture, with_temperature, density,
    reject_renamed_surface_pressure,
    temperature_from_potential_temperature, saturation_specific_humidity

using Breeze.AtmosphereModels: AtmosphereModels, AtmosphereModel,
    specific_prognostic_moisture, thermodynamic_density_name
using Breeze.TimeSteppers: SSPRungeKutta3
using Breeze.Solvers: SecantSolver, secant_solve

#####
##### Vertical velocity formulations
#####

"""
    PrescribedVerticalVelocity

Singleton type for prescribed vertical velocity dynamics. The parcel moves
following the prescribed environmental vertical velocity field `w(z)`.

This is the default vertical velocity formulation: `dz/dt = w_env(z)`.
"""
struct PrescribedVerticalVelocity end

"""
    PrognosticVerticalVelocity

Singleton type for prognostic vertical velocity dynamics. The parcel
has a prognostic vertical velocity driven by buoyancy, i.e.,
dz/dt = w and dw/dt = b, where b = -g (ρᵖ - ρᵉ) / ρᵉ is the net buoyancy
from the density difference, including both the virtual temperature effect
and condensate loading.
"""
struct PrognosticVerticalVelocity end

Base.summary(::PrescribedVerticalVelocity) = "PrescribedVerticalVelocity"
Base.summary(::PrognosticVerticalVelocity) = "PrognosticVerticalVelocity"

#####
##### ParcelState: state of a rising parcel
#####

"""
$(TYPEDEF)
$(TYPEDFIELDS)

State of a Lagrangian air parcel with position, thermodynamic state, and microphysics.

The parcel model evolves **specific quantities** (qᵗ, ℰ) directly for exact conservation.
Density-weighted forms (ρqᵗ, ρℰ) are also stored for consistency with the microphysics interface.

- `w`: parcel vertical velocity [m/s], prognostic for `PrognosticVerticalVelocity`,
  zero for `PrescribedVerticalVelocity`
- `ρ`: **environmental** density at parcel height [kg/m³], interpolated from background
  profile, used as the weight for stored prognostics. Microphysical rates use
  the parcel's own density, computed from
  `density(𝒰, constants)` using the ideal gas law applied to the parcel's thermodynamic state.
"""
mutable struct ParcelState{FT, TH, MP}
    x :: FT
    y :: FT
    z :: FT
    w :: FT
    ρ :: FT
    qᵗ :: FT
    ρqᵗ :: FT
    ℰ :: FT
    ρℰ :: FT
    𝒰 :: TH
    μ :: MP
end

# Accessors
@inline position(state::ParcelState) = (state.x, state.y, state.z)
@inline height(state::ParcelState) = state.z
@inline parcel_density(state::ParcelState) = state.ρ
@inline total_moisture(state::ParcelState) = state.qᵗ

Base.eltype(::ParcelState{FT}) where FT = FT

function Base.show(io::IO, state::ParcelState{FT}) where FT
    print(io, "ParcelState{$FT}(z=", state.z, ", w=", round(state.w, digits=4),
          ", ρ=", round(state.ρ, digits=4),
          ", qᵗ=", round(state.qᵗ * 1000, digits=2), " g/kg)")
end

#####
##### ParcelTendencies: time derivatives of parcel state
#####

"""
$(TYPEDEF)
$(TYPEDFIELDS)

Tendencies (time derivatives) for parcel prognostic variables.
"""
mutable struct ParcelTendencies{FT, GM}
    Gx :: FT
    Gy :: FT
    Gz :: FT
    Gw :: FT
    Gℰ :: FT
    Gqᵗ :: FT
    Gμ :: GM
end

ParcelTendencies(FT::DataType, Gμ::GM) where GM =
    ParcelTendencies{FT, GM}(zero(FT), zero(FT), zero(FT), zero(FT), zero(FT), zero(FT), Gμ)

#####
##### ParcelDynamics: Lagrangian parcel dynamics for AtmosphereModel
#####

"""
$(TYPEDEF)

Lagrangian parcel dynamics for [`AtmosphereModel`](@ref).

# Fields
- `state`: parcel state (position, thermodynamics, microphysics)
- `timestepper`: SSP RK3 timestepper with tendencies
- `density`: environmental density field [kg/m³]
- `pressure`: environmental pressure field [Pa]
- `base_pressure`: pressure of the reference atmosphere at ``z = 0`` [Pa]
- `standard_pressure`: standard pressure for potential temperature [Pa]
"""
struct ParcelDynamics{S, TS, D, P, U, FT}
    state :: S
    timestepper :: TS
    density :: D
    pressure :: P
    vertical_velocity_formulation :: U
    base_pressure :: FT
    standard_pressure :: FT
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct `ParcelDynamics` with default (uninitialized) state.

The environmental profiles and parcel state are set using `set!` after
constructing the `AtmosphereModel`.
The model's `formulation` selects liquid–ice potential temperature (the default)
or static energy as the parcel's conserved thermodynamic variable.
"""
function ParcelDynamics(FT::DataType=Oceananigans.defaults.FloatType;
                        vertical_velocity_formulation = PrescribedVerticalVelocity(),
                        base_pressure = 101325,
                        standard_pressure = 1e5,
                        surface_pressure = nothing)
    reject_renamed_surface_pressure(surface_pressure)
    U = typeof(vertical_velocity_formulation)
    return ParcelDynamics{Nothing, Nothing, Nothing, Nothing, U, FT}(
        nothing,
        nothing,
        nothing,
        nothing,
        vertical_velocity_formulation,
        convert(FT, base_pressure),
        convert(FT, standard_pressure)
    )
end

Base.summary(::ParcelDynamics) = "ParcelDynamics"

function Base.show(io::IO, d::ParcelDynamics)
    println(io, "ParcelDynamics")
    state_str = d.state isa ParcelState ? d.state : "uninitialized"
    println(io, "├── state: ", state_str)
    println(io, "├── timestepper: ", isnothing(d.timestepper) ? "uninitialized" : "ParcelTimestepper (SSP RK3)")
    println(io, "├── vertical_velocity_formulation: ", summary(d.vertical_velocity_formulation))
    println(io, "├── density: ", isnothing(d.density) ? "unset" : summary(d.density))
    println(io, "├── pressure: ", isnothing(d.pressure) ? "unset" : summary(d.pressure))
    println(io, "├── base_pressure: ", d.base_pressure)
    print(io, "└── standard_pressure: ", d.standard_pressure)
end

"""
    ParcelModel

Type alias for `AtmosphereModel{<:ParcelDynamics}`.

A `ParcelModel` represents a Lagrangian adiabatic parcel that rises through a
prescribed environmental atmosphere. The parcel is characterized by its position
`(x, y, z)`, thermodynamic state, and moisture content. The environmental profiles
(temperature, pressure, density, velocities) are defined on a 1D vertical grid.

The parcel's motion is determined by interpolating environmental velocities to the
parcel position, and its thermodynamic evolution follows adiabatic processes with
optional microphysical interactions.

See also [`ParcelDynamics`](@ref), [`AtmosphereModel`](@ref).
"""
const ParcelModel = AtmosphereModel{<:ParcelDynamics}

#####
##### Dynamics interface implementation
#####

AtmosphereModels.continuity_density(d::ParcelDynamics) = d.density

AtmosphereModels.prognostic_momentum_field_names(::ParcelDynamics) = ()
AtmosphereModels.prognostic_dynamics_field_names(::ParcelDynamics) = ()
AtmosphereModels.additional_dynamics_field_names(::ParcelDynamics) = ()
AtmosphereModels.validate_velocity_boundary_conditions(::ParcelDynamics, bcs) = nothing
AtmosphereModels.velocity_boundary_condition_names(::ParcelDynamics) = (:u, :v, :w)

AtmosphereModels.dynamics_pressure_solver(::ParcelDynamics, grid) = nothing
AtmosphereModels.dynamics_pressure(d::ParcelDynamics) = d.pressure
AtmosphereModels.pressure_anomaly(::ParcelDynamics) = ZeroField()
AtmosphereModels.total_pressure(d::ParcelDynamics) = d.pressure
AtmosphereModels.base_pressure(d::ParcelDynamics) = d.base_pressure
AtmosphereModels.standard_pressure(d::ParcelDynamics) = d.standard_pressure

#####
##### Materialization
#####

# Sedimentation is spatial transport in Eulerian models. Parcel microphysics represents
# precipitation loss through state tendencies instead of grid-based fall-velocity fields.
AtmosphereModels.materialize_sedimentation(::ParcelDynamics, microphysics, microphysical_fields, advection) = (;)

function AtmosphereModels.materialize_dynamics(d::ParcelDynamics, grid, bcs, constants, microphysics,
                                               formulation=:LiquidIcePotentialTemperature)
    FT = eltype(grid)
    p₀ = convert(FT, d.base_pressure)
    pˢᵗ = convert(FT, d.standard_pressure)

    # Create density and pressure fields
    ρ = CenterField(grid)
    p = CenterField(grid)

    # Create default parcel state (will be overwritten by set!)
    q = MoistureMassFractions(zero(FT))
    T_default = FT(288.15)
    z_default = zero(FT)
    if thermodynamic_density_name(formulation) === :ρθ
        𝒰 = with_temperature(LiquidIcePotentialTemperatureState(zero(FT), q, pˢᵗ, p₀), T_default, constants)
        ℰ_default = 𝒰.potential_temperature
    else
        𝒰 = with_temperature(StaticEnergyState(zero(FT), q, z_default, p₀), T_default, constants)
        ℰ_default = 𝒰.static_energy
    end

    # Microphysics prognostic variables based on the microphysics scheme
    μ = materialize_parcel_microphysics_prognostics(FT, microphysics)

    # Initialize state with default values
    ρ_default = FT(1.2)
    w_default = zero(FT)
    qᵗ_default = zero(FT)
    ρqᵗ_default = ρ_default * qᵗ_default
    ρℰ_default = ρ_default * ℰ_default
    state = ParcelState(zero(FT), zero(FT), z_default, w_default, ρ_default,
                        qᵗ_default, ρqᵗ_default, ℰ_default, ρℰ_default, 𝒰, μ)

    # SSP RK3 timestepper with tendencies
    Gμ = zero_microphysics_prognostic_tendencies(μ)
    timestepper = ParcelTimestepper(state, Gμ)

    return ParcelDynamics(state, timestepper, ρ, p, d.vertical_velocity_formulation, p₀, pˢᵗ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Create the parcel microphysics prognostic variables for the given microphysics scheme.

Returns `nothing` for microphysics schemes without explicit prognostic variables
(e.g., `Nothing`, `SaturationAdjustment`), or a `NamedTuple` containing the prognostic
density-weighted scalars for schemes with prognostic microphysics.

The prognostic variables use the same ρ-weighted names as the grid-based model
(e.g., `:ρqᶜˡ`, `:ρqʳ`) from `prognostic_field_names(microphysics)`.

All values start at zero. A scheme that carries a prognostic aerosol reservoir `ρnᵃ` holds a
ρ-weighted count there, so its default is only meaningful once the parcel has an
environmental density, which `set!` supplies through [`set_parcel_aerosol_number`](@ref).
"""
function materialize_parcel_microphysics_prognostics(FT, microphysics)
    names = AtmosphereModels.prognostic_field_names(microphysics)
    length(names) == 0 && return nothing
    return NamedTuple{names}(ntuple(_ -> zero(FT), length(names)))
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return `μ` with its aerosol reservoir `ρnᵃ` [m⁻³] set from the parcel's environmental
density `ρ`: to `ρ * nᵃ` if `nᵃ` [kg⁻¹] is given, to `ρnᵃ` if that is given, and otherwise
to the scheme default [`AtmosphereModels.initial_aerosol_number_density`](@ref).

Schemes without a prognostic reservoir have no `ρnᵃ` to set, so `μ` is returned unchanged;
supplying `nᵃ` or `ρnᵃ` for one of those is an `ArgumentError` rather than a silent no-op.

Because `set!` calls this on every invocation, a later `set!` also resets the reservoir to
the distribution default. Pass `nᵃ` or `ρnᵃ` explicitly to carry a depleted reservoir
across a `set!`.
"""
function set_parcel_aerosol_number(μ, microphysics, ρ, nᵃ, ρnᵃ)
    if isnothing(μ) || !haskey(μ, :ρnᵃ)
        (isnothing(nᵃ) && isnothing(ρnᵃ)) ||
            throw(ArgumentError("the parcel's microphysics scheme has no prognostic ρnᵃ"))
        return μ
    end

    FT = typeof(ρ)
    aerosol_number_density = if !isnothing(ρnᵃ)
        FT(ρnᵃ)
    elseif !isnothing(nᵃ)
        ρ * FT(nᵃ)
    else
        FT(AtmosphereModels.initial_aerosol_number_density(microphysics, ρ))
    end

    return merge(μ, (; ρnᵃ = aerosol_number_density))
end

rescale_parcel_microphysics(::Nothing, ratio) = nothing

function rescale_parcel_microphysics(μ::NamedTuple, ratio)
    names = keys(μ)
    return NamedTuple{names}(map(name -> ratio * μ[name], names))
end

function AtmosphereModels.materialize_momentum_and_velocities(::ParcelDynamics, grid, bcs)
    # Parcel models use CenterFields for environmental velocity profiles.
    # This avoids boundary issues when interpolating at arbitrary parcel positions,
    # since cell centers are always in the domain interior.
    u = CenterField(grid)
    v = CenterField(grid)
    w = CenterField(grid)
    return NamedTuple(), (; u, v, w)
end

#####
##### Adapt and architecture transfer
#####

Adapt.adapt_structure(to, d::ParcelDynamics) =
    ParcelDynamics(adapt(to, d.state),
                   adapt(to, d.timestepper),
                   adapt(to, d.density),
                   adapt(to, d.pressure),
                   d.vertical_velocity_formulation,
                   d.base_pressure,
                   d.standard_pressure)

Oceananigans.Architectures.on_architecture(to, d::ParcelDynamics) =
    ParcelDynamics(on_architecture(to, d.state),
                   on_architecture(to, d.timestepper),
                   on_architecture(to, d.density),
                   on_architecture(to, d.pressure),
                   d.vertical_velocity_formulation,
                   d.base_pressure,
                   d.standard_pressure)

#####
##### set! for ParcelModel
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Set the environmental profiles and initial parcel state for a [`ParcelModel`](@ref).

Environmental profiles are set on the model's fields (temperature, density, pressure,
velocities). The parcel is initialized at the specified position with environmental
conditions interpolated at that height.

# Keyword Arguments

**Thermodynamic profiles** (provide one of `T` or `θ`):
- `T`: Temperature profile T(z) [K] - function, array, Field, or constant
- `θ`: Potential temperature profile θ(z) [K] - function, array, or constant.
       If provided, `T` is computed from `θ` and `p` using thermodynamic relations.
- `ρ`: Density profile ρ(z) [kg/m³] - function, array, Field, or constant
- `p`: Pressure profile p(z) [Pa] - function, array, Field, or constant

**Moisture** (provide one of `qᵗ` or `ℋ`):
- `qᵗ`: Specific humidity profile qᵗ(z) [kg/kg] - function, array, or constant (default: 0)
- `ℋ`: Relative humidity profile ℋ(z) [0-1] - function, array, or constant.
       If provided, `qᵗ` is computed as `qᵗ = ℋ * qᵛ⁺(T, ρ)`.

The parcel's thermodynamic variable is initialized at the environmental temperature
with the condensate carried by its microphysical prognostics. Saturation adjustment
then equilibrates the state at fixed static energy or liquid–ice potential temperature.

**Velocities**:
- `u`: Zonal velocity u(z) [m/s] - function, array, or constant (default: 0)
- `v`: Meridional velocity v(z) [m/s] - function, array, or constant (default: 0)
- `w`: Vertical velocity w(z) [m/s] - function, array, or constant (default: 0)

**Parcel state**:
- `x`: Initial parcel x-position [m], default: 0
- `y`: Initial parcel y-position [m], default: 0
- `z`: Initial parcel height [m], required to initialize parcel state
- `w_parcel`: Initial parcel vertical velocity [m/s], for `PrognosticVerticalVelocity`
- `nᵃ`: Initial aerosol number per unit mass [kg⁻¹], for a scheme that carries a prognostic
  reservoir. Defaults to the value implied by the scheme's aerosol distribution, so a
  depleted reservoir must be passed explicitly to survive a `set!` (see
  [`set_parcel_aerosol_number`](@ref))
- `ρnᵃ`: Initial aerosol number density [m⁻³], the ρ-weighted alternative to `nᵃ`
"""
function Oceananigans.set!(model::ParcelModel; T = nothing, θ = nothing,
                           ρ = nothing, p = nothing,
                           qᵗ = nothing, ℋ = nothing,
                           u = 0, v = 0, w = 0,
                           w_parcel = nothing,
                           x = 0, y = 0, z = nothing,
                           nᵃ = nothing, ρnᵃ = nothing)

    !isnothing(nᵃ) && !isnothing(ρnᵃ) &&
        throw(ArgumentError("set! cannot set both nᵃ and ρnᵃ"))

    dynamics = model.dynamics
    constants = model.thermodynamic_constants
    pˢᵗ = dynamics.standard_pressure

    # Set pressure and density first (needed for T from θ and qᵗ from ℋ)
    !isnothing(ρ) && set!(dynamics.density, ρ)
    !isnothing(p) && set!(dynamics.pressure, p)
    fill_halo_regions!(dynamics.density)
    fill_halo_regions!(dynamics.pressure)

    qᵛᵉ = specific_prognostic_moisture(model)
    setting_θ = !isnothing(θ) && isnothing(T)
    setting_θ && isnothing(p) &&
        error("Pressure `p` must be provided when setting potential temperature `θ`")

    set!(qᵛᵉ, isnothing(qᵗ) ? 0 : qᵗ)
    if setting_θ && !isnothing(ℋ) && isnothing(qᵗ)
        potential_temperature = CenterField(model.grid)
        relative_humidity = CenterField(model.grid)
        set!(potential_temperature, θ)
        set!(relative_humidity, ℋ)
        FT = eltype(model.grid)
        solver = SecantSolver(FT; abstol=0, reltol=4eps(FT), maxiter=20)
        launch!(model.grid.architecture, model.grid, :xyz, _set_temperature_and_relative_humidity!,
                model.temperature, qᵛᵉ, potential_temperature, relative_humidity, dynamics.pressure, dynamics.density,
                pˢᵗ, constants, solver)
    else
        if setting_θ
            set_temperature_from_potential_temperature!(model.temperature, θ, dynamics.pressure,
                                                       qᵛᵉ, pˢᵗ, constants)
        elseif !isnothing(T)
            set!(model.temperature, T)
        end
        if !isnothing(ℋ) && isnothing(qᵗ)
            set_moisture_from_relative_humidity!(qᵛᵉ, ℋ, model.temperature, dynamics.density, constants)
        end
    end
    fill_halo_regions!(qᵛᵉ)
    fill_halo_regions!(model.temperature)

    # Set velocities
    set!(model.velocities.u, u)
    set!(model.velocities.v, v)
    set!(model.velocities.w, w)
    fill_halo_regions!(model.velocities.u)
    fill_halo_regions!(model.velocities.v)
    fill_halo_regions!(model.velocities.w)

    # Initialize parcel state if z is provided
    if !isnothing(z)
        initialize_parcel_state!(dynamics.state, z, x, y, model)
    end

    # Weight the aerosol reservoir by the parcel's environmental density, which
    # `initialize_parcel_state!` has just interpolated at the parcel position.
    dynamics.state.μ = set_parcel_aerosol_number(dynamics.state.μ, model.microphysics,
                                                 dynamics.state.ρ, nᵃ, ρnᵃ)

    # Set parcel vertical velocity (for PrognosticVerticalVelocity)
    if !isnothing(w_parcel)
        dynamics.state.w = convert(eltype(model.grid), w_parcel)
    end

    # Bring the thermodynamic state to what the first substep sees: water partitioned with the
    # final prognostics and, for saturation adjustment, equilibrated at fixed thermodynamic variable.
    isnothing(z) || update_parcel_moisture!(model)

    return nothing
end

#####
##### Helper functions for set!
#####

@kernel function _set_temperature_and_relative_humidity!(temperature_field, moisture_field,
                                                         potential_temperature, relative_humidity,
                                                         pressure, density, pˢᵗ, constants, solver)
    i, j, k = @index(Global, NTuple)
    @inbounds begin
        θ = potential_temperature[i, j, k]
        ℋ = relative_humidity[i, j, k]
        p = pressure[i, j, k]
        ρ = density[i, j, k]
    end
    @inline vapor(T) = ℋ * saturation_specific_humidity(T, ρ, constants, PlanarLiquidSurface())
    @inline residual(T) = T - temperature_from_potential_temperature(θ, p, pˢᵗ, constants, vapor(T))
    T₁ = temperature_from_potential_temperature(θ, p, pˢᵗ, constants)
    T = secant_solve(residual, solver, T₁, T₁ + 1, T₁)
    @inbounds temperature_field[i, j, k] = T
    @inbounds moisture_field[i, j, k] = vapor(T)
end

@kernel function _set_temperature_from_potential_temperature!(T_field, θ_field, p_field, qᵛ_field, pˢᵗ, constants)
    i, j, k = @index(Global, NTuple)
    @inbounds begin
        θₖ = θ_field[i, j, k]
        pₖ = p_field[i, j, k]
        qᵛₖ = qᵛ_field[i, j, k]
    end
    @inbounds T_field[i, j, k] = @inline temperature_from_potential_temperature(θₖ, pₖ, pˢᵗ, constants, qᵛₖ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Set temperature field from potential temperature, using proper thermodynamic relations.

The moisture field `qᵛ_field` supplies the mixture gas constant and heat capacity that define
the Exner function, so a moist column converts ``θ → T`` with ``Rᵐ / cᵖᵐ`` rather than the dry
exponent. Moisture is taken to be all vapor, the same no-condensate assumption the rest of
`set!` makes before microphysics repartitions the water.
"""
function set_temperature_from_potential_temperature!(T_field, θ, p_field, qᵛ_field, pˢᵗ, constants)
    grid = T_field.grid
    arch = grid.architecture
    θ_field = CenterField(grid)
    set!(θ_field, θ)
    launch!(arch, grid, :xyz, _set_temperature_from_potential_temperature!,
            T_field, θ_field, p_field, qᵛ_field, pˢᵗ, constants)
    return nothing
end

@kernel function _set_moisture_from_relative_humidity!(qᵗ_field, ℋ_field, T_field, ρ_field, constants)
    i, j, k = @index(Global, NTuple)
    @inbounds begin
        ℋₖ = ℋ_field[i, j, k]
        Tₖ = T_field[i, j, k]
        ρₖ = ρ_field[i, j, k]
    end
    qᵛ⁺ = @inline saturation_specific_humidity(Tₖ, ρₖ, constants, PlanarLiquidSurface())
    @inbounds qᵗ_field[i, j, k] = ℋₖ * qᵛ⁺
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Set specific humidity field from relative humidity, computing

```math
qᵗ = ℋ qᵛ⁺(T, ρ).
```

where ``qᵗ`` is the total specific moisture, ``ℋ`` is the relative humidity,
and ``qᵛ⁺`` is the saturation specific humidity at temperature ``T`` and density ``ρ``.
"""
function set_moisture_from_relative_humidity!(qᵗ_field, ℋ, T_field, ρ_field, constants)
    grid = qᵗ_field.grid
    arch = grid.architecture
    ℋ_field = CenterField(grid)
    set!(ℋ_field, ℋ)
    launch!(arch, grid, :xyz, _set_moisture_from_relative_humidity!,
            qᵗ_field, ℋ_field, T_field, ρ_field, constants)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Initialize the parcel state by interpolating environmental conditions at the given position.
The thermodynamic variable is initialized at the environmental temperature with
the condensate carried by the microphysical prognostics.
"""
function initialize_parcel_state!(state, z₀, x₀, y₀, model)
    grid = model.grid
    dynamics = model.dynamics
    constants = model.thermodynamic_constants
    FT = eltype(grid)

    x₀ = convert(FT, x₀)
    y₀ = convert(FT, y₀)
    z₀ = convert(FT, z₀)

    # Interpolate environmental conditions at parcel height
    T₀ = interpolate(z₀, model.temperature)
    ρ₀ = interpolate(z₀, dynamics.density)
    p₀ = interpolate(z₀, dynamics.pressure)
    qᵗ₀ = interpolate(z₀, specific_prognostic_moisture(model))
    ρ_previous = state.ρ

    # Set position and zero vertical velocity (can be overridden by set! w_parcel keyword)
    state.x = x₀
    state.y = y₀
    state.z = z₀
    state.w = zero(FT)

    # Preserve specific microphysical quantities when the parcel density changes. The
    # aerosol reservoir is rewritten from `ρ₀` by `set!` immediately after this, unless the
    # caller supplied it.
    state.μ = rescale_parcel_microphysics(state.μ, ρ₀ / ρ_previous)

    # Set density and moisture
    state.ρ = ρ₀
    state.qᵗ = qᵗ₀
    state.ρqᵗ = ρ₀ * qᵗ₀

    # Keep the carried condensate within the new total water before partitioning it.
    AtmosphereModels.fix_negative_moisture!(model)

    # Initialize the conserved thermodynamic variable with the carried condensate at T₀.
    𝒰ᵛ = reconstruct_thermodynamic_state(state.𝒰, zero(FT), z₀, p₀)
    𝒰ᵛ = with_moisture(𝒰ᵛ, MoistureMassFractions(qᵗ₀))
    _, q = parcel_moisture_partition(model.microphysics, ρ₀, state.μ, qᵗ₀, 𝒰ᵛ)
    𝒰 = with_temperature(with_moisture(𝒰ᵛ, q), T₀, constants)
    state.ℰ = thermodynamic_variable(𝒰)
    state.ρℰ = ρ₀ * state.ℰ
    state.𝒰 = 𝒰

    return nothing
end

#####
##### Update state
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Update the parcel model state, computing tendencies and auxiliary variables.

This function is called at the beginning of each time step and after each
substep in multi-stage time steppers. It mirrors the role of `update_state!`
for [`AtmosphereModel`](@ref) and consolidates all state-dependent computations:

1. Compute position tendencies (Gx, Gy, Gz) from environmental velocity profiles
2. Any other auxiliary state computations (currently none)

# Keyword Arguments
- `compute_tendencies`: If `true` (default), compute tendencies for prognostic variables.
"""
function TimeSteppers.update_state!(model::ParcelModel, callbacks=[]; compute_tendencies=true)
    compute_tendencies && compute_parcel_tendencies!(model)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute tendencies for the parcel prognostic variables.

Position tendencies are interpolated from environmental velocity fields.
Thermodynamic and moisture tendencies come from microphysical sources/sinks.

The parcel model evolves specific static energy or liquid–ice potential temperature
and total water directly. These quantities are conserved when their tendencies vanish.
"""
function compute_parcel_tendencies!(model::ParcelModel)
    dynamics = model.dynamics
    state = dynamics.state
    tendencies = dynamics.timestepper.G
    microphysics = model.microphysics
    constants = model.thermodynamic_constants

    z = state.z
    𝒰 = state.𝒰
    # Prognostics are stored using the environmental density as a weight, but
    # collision and saturation rates require the parcel's thermodynamic density.
    ρ = density(𝒰, constants)
    μ = rescale_parcel_microphysics(state.μ, ρ / state.ρ)

    # Horizontal position tendencies = environmental velocity at current height
    tendencies.Gx = interpolate(z, model.velocities.u)
    tendencies.Gy = interpolate(z, model.velocities.v)

    # Vertical position and velocity tendencies dispatched on vertical velocity formulation
    compute_vertical_velocity_tendencies!(tendencies, state, dynamics, model, dynamics.vertical_velocity_formulation)

    # Build diagnostic microphysical state from prognostic variables
    # Pass velocities for microphysics (e.g., aerosol activation uses vertical velocity)
    velocities = (; u = tendencies.Gx, v = tendencies.Gy, w = tendencies.Gz)

    # Dispatch handles the Nothing case: microphysical_tendency(::Nothing, ...) returns zero,
    # compute_microphysics_prognostic_tendencies(::Nothing, ...) returns nothing/zero NamedTuple
    ℳ = microphysical_state(microphysics, ρ, μ, 𝒰, velocities)
    tendencies.Gℰ = microphysical_tendency(microphysics, thermodynamic_variable_name(𝒰), ρ, ℳ, 𝒰, constants)
    tendencies.Gqᵗ = microphysical_tendency(microphysics, Val(:qᵗ), ρ, ℳ, 𝒰, constants)
    Gμ = compute_microphysics_prognostic_tendencies(microphysics, ρ, μ, ℳ, 𝒰, constants)
    tendencies.Gμ = rescale_parcel_microphysics(Gμ, state.ρ / ρ)

    return nothing
end

#####
##### Buoyancy computation and vertical velocity tendency dispatch
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the net buoyancy acceleration for a parcel.

The buoyancy is computed from the density difference between the parcel and
environment:

```math
B = -g (ρ_{parcel} - ρ_{env}) / ρ_{env}
```

Here, ``ρ_{env}`` is the environmental density interpolated at the parcel height
and ``ρ_{parcel} = p / (Rᵐ T)`` is the total parcel density from the ideal gas law,
where ``Rᵐ = qᵈ Rᵈ + qᵛ Rᵛ`` with ``qᵈ = 1 - qᵛ - qˡ - qⁱ``. This formulation
captures both the virtual temperature effect (from vapor content) and the
condensate loading effect (condensate reduces ``qᵈ``, reducing ``Rᵐ``, increasing
``ρ_{parcel}``) in a single term without double-counting.
"""
@inline function parcel_buoyancy(state, dynamics, constants)
    g = constants.gravitational_acceleration
    ρ_env = state.ρ
    ρ_parcel = density(state.𝒰, constants)

    # Full buoyancy from density difference.
    # density(𝒰, constants) computes p / (R_m T) where R_m = q_d R_d + q_v R_v
    # and q_d = 1 - q_v - q_l - q_i. The condensate loading effect is already
    # captured through the reduced R_m (condensate reduces q_d, reducing R_m,
    # increasing ρ_parcel). No separate water loading term is needed.
    return -g * (ρ_parcel - ρ_env) / ρ_env
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute vertical velocity tendencies for [`PrescribedVerticalVelocity`](@ref).

The parcel follows the environmental vertical velocity: `dz/dt = w_env(z)`.
The parcel velocity tendency `Gw` is zero (unused prognostic).
"""
@inline function compute_vertical_velocity_tendencies!(tendencies, state, dynamics, model, ::PrescribedVerticalVelocity)
    tendencies.Gz = interpolate(state.z, model.velocities.w)
    tendencies.Gw = zero(state.z)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute vertical velocity tendencies for [`PrognosticVerticalVelocity`](@ref).

The parcel has a prognostic vertical velocity driven by buoyancy, i.e.,
dz/dt = w and dw/dt = B.
"""
@inline function compute_vertical_velocity_tendencies!(tendencies, state, dynamics, model, ::PrognosticVerticalVelocity)
    B = parcel_buoyancy(state, dynamics, model.thermodynamic_constants)
    tendencies.Gz = state.w
    tendencies.Gw = B
    return nothing
end

#####
##### Parcel microphysics interface
#####
# These functions implement the parcel-specific microphysics interface.
# The default fallbacks work for schemes with no explicit prognostic microphysics.

# Compute tendencies for microphysics prognostic variables
# Fallback: return nothing for schemes without prognostic microphysics
compute_microphysics_prognostic_tendencies(microphysics, ρ, μ::Nothing, ℳ, 𝒰, constants) = nothing
compute_microphysics_prognostic_tendencies(::Nothing, ρ, μ, ℳ, 𝒰, constants) = μ
compute_microphysics_prognostic_tendencies(::Nothing, ρ, μ::Nothing, ℳ, 𝒰, constants) = nothing
# Disambiguation for Nothing microphysics + NamedTuple
compute_microphysics_prognostic_tendencies(::Nothing, ρ, μ::NamedTuple, ℳ, 𝒰, constants) = μ

# For NamedTuple prognostics, every prognostic tendency in one call. Schemes with coupled
# process rates override `microphysical_tendencies` to evaluate their bundle once.
function compute_microphysics_prognostic_tendencies(microphysics, ρ, μ::NamedTuple, ℳ, 𝒰, constants)
    prog_names = AtmosphereModels.prognostic_field_names(microphysics)
    tendencies = microphysical_tendencies(microphysics, prog_names, ρ, ℳ, 𝒰, constants)
    return NamedTuple{keys(μ)}(tendencies)
end

# Zero tendencies for microphysics prognostics
zero_microphysics_prognostic_tendencies(::Nothing) = nothing
zero_microphysics_prognostic_tendencies(μ::NamedTuple{names, T}) where {names, T} =
    NamedTuple{names}(ntuple(_ -> zero(eltype(T)), length(names)))

# Apply tendencies to update microphysics prognostic variables
apply_microphysical_tendencies(μ::Nothing, Gμ, Δt) = nothing
function apply_microphysical_tendencies(μ::NamedTuple, Gμ::NamedTuple, Δt)
    # Both μ and Gμ are ρ-weighted, step directly
    new_values = map(keys(μ)) do name
        μ[name] + Δt * Gμ[name]
    end
    return NamedTuple{keys(μ)}(new_values)
end

apply_microphysical_tendencies(μ::Nothing, Gμ, Δt, ρ⁻, ρ⁺) = nothing
function apply_microphysical_tendencies(μ::NamedTuple, Gμ::NamedTuple, Δt, ρ⁻, ρ⁺)
    return rescale_parcel_microphysics(apply_microphysical_tendencies(μ, Gμ, Δt), ρ⁺ / ρ⁻)
end

#####
##### ParcelTimestepper: SSP RK3 time-stepping for parcel models
#####

"""
$(TYPEDEF)

SSP RK3 time-stepper for [`ParcelModel`](@ref).

Stores tendencies, the initial state at the beginning of a time step,
and the SSP RK3 stage coefficients.

# Fields
- `G`: tendencies for prognostic variables
- `U⁰`: initial state storage (position, moisture, thermodynamics, microphysics)
- `α¹`, `α²`, `α³`: SSP RK3 stage coefficients (1, 1/4, 2/3)
"""
struct ParcelTimestepper{GT, U0, FT}
    G :: GT
    U⁰ :: U0
    α¹ :: FT
    α² :: FT
    α³ :: FT
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct a `ParcelTimestepper` for SSP RK3 time-stepping.
"""
function ParcelTimestepper(state::ParcelState{FT}, Gμ) where FT
    α¹ = FT(1)
    α² = FT(1//4)
    α³ = FT(2//3)
    G = ParcelTendencies(FT, Gμ)
    U⁰ = ParcelInitialState(state)
    return ParcelTimestepper(G, U⁰, α¹, α², α³)
end

"""
$(TYPEDEF)
$(TYPEDFIELDS)

Storage for the initial parcel prognostic state at the beginning of a time step.
Used by SSP RK3 to combine the initial state with intermediate states.
"""
mutable struct ParcelInitialState{FT, MP}
    x :: FT
    y :: FT
    z :: FT
    w :: FT
    qᵗ :: FT
    ℰ :: FT
    μ :: MP
end

function ParcelInitialState(state::ParcelState{FT, TH, MP}) where {FT, TH, MP}
    return ParcelInitialState{FT, MP}(
        state.x, state.y, state.z, state.w, state.qᵗ, state.ℰ, state.μ
    )
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Copy current prognostic state values to the initial state storage.
"""
function store_initial_parcel_state!(U⁰::ParcelInitialState, state::ParcelState)
    U⁰.x = state.x
    U⁰.y = state.y
    U⁰.z = state.z
    U⁰.w = state.w
    U⁰.qᵗ = state.qᵗ
    U⁰.ℰ = state.ℰ
    U⁰.μ = copy_microphysics_prognostics(state.μ)
    return nothing
end

copy_microphysics_prognostics(::Nothing) = nothing
copy_microphysics_prognostics(μ::NamedTuple) = μ  # NamedTuples of scalars are immutable value types

#####
##### Domain boundary clamping
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Check that the parcel remains within the vertical grid domain `[0, Lz]`.

Throws an error if the parcel escapes the domain, since extrapolation of
environmental profiles (pressure, density) beyond the grid is unphysical.
"""
function check_domain_bounds!(state, grid)
    z_max = grid.Lz
    if state.z ≥ z_max
        error("Parcel reached the model top (z = $(state.z) m ≥ Lz = $(z_max) m). " *
              "Increase the domain height or reduce the simulation stop_time.")
    elseif state.z < 0
        error("Parcel fell below the model bottom (z = $(state.z) m < 0). " *
              "Check initial conditions and forcing.")
    end
    return nothing
end

#####
##### SSP RK3 substep
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Apply an SSP RK3 substep with coefficient ``α``:

```math
u^{(m)} = (1 - α) u^{(0)} + α \\left[u^{(m-1)} + Δt \\, G^{(m-1)}\\right]
```

where ``u^{(0)}`` is the initial state, ``u^{(m-1)}`` is the current state,
and ``G^{(m-1)}`` is the tendency at the current state.

The parcel model steps specific quantities (ℰ, qᵗ), where ℰ is static energy or
liquid–ice potential temperature. Both are conserved when their tendencies vanish.
"""
function ssp_rk3_parcel_substep!(model::ParcelModel, U⁰::ParcelInitialState, Δt, α)
    # Compute tendencies at current state
    compute_parcel_tendencies!(model)

    dynamics = model.dynamics
    state = dynamics.state
    tendencies = dynamics.timestepper.G
    ρᵐ = state.ρ
    # `ParcelInitialState` retains its public constructor shape; its initial environmental density
    # is recovered from the stored height instead of adding another public field.
    ρ⁰ = interpolate(U⁰.z, dynamics.density)

    # Step position and vertical velocity
    state.x = (1 - α) * U⁰.x + α * (state.x + Δt * tendencies.Gx)
    state.y = (1 - α) * U⁰.y + α * (state.y + Δt * tendencies.Gy)
    state.z = (1 - α) * U⁰.z + α * (state.z + Δt * tendencies.Gz)
    state.w = (1 - α) * U⁰.w + α * (state.w + Δt * tendencies.Gw)

    check_domain_bounds!(state, model.grid)

    # Step specific quantities directly (exact conservation for adiabatic)
    state.qᵗ = (1 - α) * U⁰.qᵗ + α * (state.qᵗ + Δt * tendencies.Gqᵗ)
    state.ℰ = (1 - α) * U⁰.ℰ + α * (state.ℰ + Δt * tendencies.Gℰ)

    # Get environmental conditions at new height
    z⁺ = state.z
    p⁺ = interpolate(z⁺, dynamics.pressure)
    ρ⁺ = interpolate(z⁺, dynamics.density)

    # Update density from environmental profile
    state.ρ = ρ⁺

    # Update density-weighted quantities for consistency
    state.ρqᵗ = ρ⁺ * state.qᵗ
    state.ρℰ = ρ⁺ * state.ℰ

    # Reconstruct thermodynamic state with conserved specific energy and updated p, z
    state.𝒰 = reconstruct_thermodynamic_state(state.𝒰, state.ℰ, z⁺, p⁺)

    # Step microphysics prognostics with SSP RK3 formula (density-weighted)
    state.μ = ssp_rk3_microphysics_substep(U⁰.μ, ρ⁰, state.μ, ρᵐ,
                                           tendencies.Gμ, Δt, α, ρ⁺)

    update_parcel_moisture!(model)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Keep parcel condensates nonnegative and within the conserved total-water budget.
Excess condensate is reduced proportionally at fixed energy.
"""
function AtmosphereModels.fix_negative_moisture!(model::ParcelModel)
    state = model.dynamics.state
    μ = state.μ
    isnothing(μ) && return nothing
    microphysics = model.microphysics
    names = AtmosphereModels.condensate_field_names(microphysics)
    ρqᶜ = sum(name -> max(0, μ[name]), names; init=zero(state.ρ))
    ρqᵗ = state.ρ * state.qᵗ
    ratio = ifelse(ρqᶜ > ρqᵗ, ρqᵗ / ρqᶜ, one(ρqᵗ))
    condensates = NamedTuple{names}(map(name -> ratio * max(0, μ[name]), names))
    corrected = merge(μ, condensates)

    # Zero dependent moments when their water reservoir is empty.
    field_names = NamedTuple{keys(μ)}(keys(μ))
    for (number, mass) in AtmosphereModels.correction_number_mass_pairs(microphysics, field_names)
        value = ifelse(corrected[mass] > 0, corrected[number], zero(corrected[number]))
        corrected = merge(corrected, NamedTuple{(number,)}((value,)))
    end
    state.μ = AtmosphereModels.postprocess_microphysical_prognostics(microphysics, corrected, state.ρ)
    return nothing
end

# Partition the parcel's total water with the condensate carried by the microphysical
# prognostics `μ`, returning the scheme's prognostic moisture ``qᵛᵉ`` and the full partition.
# Saturation adjustment schemes read their cloud condensate from `𝒰`.
function parcel_moisture_partition(microphysics, ρ, μ, qᵗ, 𝒰)
    zero_velocities = (; u = zero(ρ), v = zero(ρ), w = zero(ρ))
    ℳ = microphysical_state(microphysics, ρ, μ, 𝒰, zero_velocities)
    qᵛᵉ = specific_prognostic_moisture(microphysics, qᵗ, μ, ρ)
    return qᵛᵉ, moisture_fractions(microphysics, ℳ, qᵛᵉ)
end

function update_parcel_moisture!(model)
    AtmosphereModels.fix_negative_moisture!(model)
    state = model.dynamics.state
    microphysics = model.microphysics
    qᵛᵉ, q = parcel_moisture_partition(microphysics, state.ρ, state.μ, state.qᵗ, state.𝒰)
    𝒰 = with_moisture(state.𝒰, q)
    state.𝒰 = AtmosphereModels.maybe_adjust_thermodynamic_state(𝒰, microphysics, qᵛᵉ, model.thermodynamic_constants, state.μ, state.ρ)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Reconstruct a thermodynamic state with a new conserved variable value and updated z, p.
"""
function reconstruct_thermodynamic_state end

@inline function reconstruct_thermodynamic_state(𝒰::StaticEnergyState{FT}, s⁺, z⁺, p⁺) where FT
    return StaticEnergyState{FT}(s⁺, 𝒰.moisture_mass_fractions, z⁺, p⁺)
end

@inline function reconstruct_thermodynamic_state(𝒰::LiquidIcePotentialTemperatureState{FT}, θ⁺, z⁺, p⁺) where FT
    return LiquidIcePotentialTemperatureState(convert(FT, θ⁺), 𝒰.moisture_mass_fractions, 𝒰.standard_pressure,
                                              convert(FT, p⁺), 𝒰.exner_exponent)
end

# The parcel's conserved thermodynamic variable ℰ, and its name for `microphysical_tendency`
@inline thermodynamic_variable(𝒰::StaticEnergyState) = 𝒰.static_energy
@inline thermodynamic_variable(𝒰::LiquidIcePotentialTemperatureState) = 𝒰.potential_temperature
@inline thermodynamic_variable_name(::StaticEnergyState) = Val(:s)
@inline thermodynamic_variable_name(::LiquidIcePotentialTemperatureState) = Val(:θ)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Apply SSP RK3 substep formula to microphysics prognostic variables.

The stored moments `μ` are density-weighted, while a parcel conserves their specific
counterparts `μ / ρ` in the absence of microphysical sources. Each RK branch is therefore
converted to its specific value before combining, then weighted by the new environmental
density `ρ⁺`.
"""
ssp_rk3_microphysics_substep(::Nothing, ρ⁰, ::Nothing, ρᵐ, ::Nothing, Δt, α, ρ⁺) = nothing

function ssp_rk3_microphysics_substep(μ⁰::NamedTuple, ρ⁰,
                                      μᵐ::NamedTuple, ρᵐ,
                                      Gμ::NamedTuple, Δt, α, ρ⁺)
    names = keys(μᵐ)
    μ⁺_values = map(names) do name
        (1 - α) * ρ⁺ / ρ⁰ * μ⁰[name] +
        α * ρ⁺ / ρᵐ * (μᵐ[name] + Δt * Gμ[name])
    end
    return NamedTuple{names}(μ⁺_values)
end

#####
##### State stepping (Forward Euler - used as fallback)
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Step the parcel state forward using Forward Euler:

```math
x^{n+1} = x^n + Δt \\, G^n
```

Compute tendencies at the current state, then advance all prognostic variables.
After updating position, the thermodynamic state is adjusted for the
new height (adiabatic adjustment) and environmental conditions are
updated from the profiles.
"""
function step_parcel_state!(model::ParcelModel, Δt)
    # Compute tendencies at current state
    compute_parcel_tendencies!(model)

    dynamics = model.dynamics
    state = dynamics.state
    tendencies = dynamics.timestepper.G
    ρ⁻ = state.ρ

    # Step position and vertical velocity forward (Forward Euler)
    state.x += Δt * tendencies.Gx
    state.y += Δt * tendencies.Gy
    state.z += Δt * tendencies.Gz
    state.w += Δt * tendencies.Gw

    check_domain_bounds!(state, model.grid)

    # Step specific quantities forward (exact conservation for adiabatic)
    state.qᵗ += Δt * tendencies.Gqᵗ
    state.ℰ += Δt * tendencies.Gℰ

    # Get environmental conditions at new height
    z⁺ = state.z
    p⁺ = interpolate(z⁺, dynamics.pressure)
    ρ⁺ = interpolate(z⁺, dynamics.density)

    # Update density from environmental profile
    state.ρ = ρ⁺

    # Update density-weighted quantities for consistency
    state.ρqᵗ = ρ⁺ * state.qᵗ
    state.ρℰ = ρ⁺ * state.ℰ

    # Reconstruct thermodynamic state with conserved specific energy and updated p, z
    state.𝒰 = reconstruct_thermodynamic_state(state.𝒰, state.ℰ, z⁺, p⁺)

    # Step microphysics prognostics forward using tendencies (density-weighted)
    state.μ = apply_microphysical_tendencies(state.μ, tendencies.Gμ, Δt, ρ⁻, ρ⁺)

    update_parcel_moisture!(model)
    return nothing
end


#####
##### Time stepping for ParcelModel
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Advance the parcel model by one time step ``Δt`` using SSP RK3.

The SSP RK3 scheme [Shu and Osher (1988)](@cite Shu1988Efficient) is:
```math
\\begin{align*}
u^{(1)} &= u^{(0)} + Δt \\, G(u^{(0)}) \\\\
u^{(2)} &= \\frac{3}{4} u^{(0)} + \\frac{1}{4} u^{(1)} + \\frac{1}{4} Δt \\, G(u^{(1)}) \\\\
u^{(3)} &= \\frac{1}{3} u^{(0)} + \\frac{2}{3} u^{(2)} + \\frac{2}{3} Δt \\, G(u^{(2)})
\\end{align}
```

This scheme has CFL coefficient = 1 and is TVD (total variation diminishing).
"""
function TimeSteppers.time_step!(model::AtmosphereModel{<:ParcelDynamics, <:Any, <:Any, <:SSPRungeKutta3}, Δt; callbacks=nothing)
    dynamics = model.dynamics
    ts = dynamics.timestepper
    state = dynamics.state
    U⁰ = ts.U⁰

    # Stage abscissae, as in the field-model stepper: cₘ = αₘ (cₘ₋₁ + 1) with c₀ = 0, so
    # u^(1) sits at tⁿ + Δt and u^(2) at tⁿ + Δt/2.
    c¹ = ts.α¹              # = 1
    c² = ts.α² * (c¹ + 1)   # = 1/2

    # Compute the next time step a priori to reduce floating point error accumulation
    tⁿ⁺¹ = model.clock.time + Δt

    # Store initial state for SSP RK3 stages
    store_initial_parcel_state!(U⁰, state)

    # Stage 1: u^(1) = u^(0) + Δt * G(u^(0))
    ssp_rk3_parcel_substep!(model, U⁰, Δt, ts.α¹)
    tick_stage!(model.clock, c¹ * Δt)

    # Stage 2: u^(2) = 3/4 u^(0) + 1/4 (u^(1) + Δt * G(u^(1)))
    ssp_rk3_parcel_substep!(model, U⁰, Δt, ts.α²)

    # Back to tⁿ + Δt/2, the abscissa of u^(2); `corrected_Δt` below restores the Δt/2.
    tick_stage!(model.clock, (c² - c¹) * Δt)

    # Stage 3: u^(3) = 1/3 u^(0) + 2/3 (u^(2) + Δt * G(u^(2)))
    ssp_rk3_parcel_substep!(model, U⁰, Δt, ts.α³)

    # Final clock update (adjust for floating point error)
    corrected_Δt = time_difference_seconds(tⁿ⁺¹, model.clock.time)
    tick_stage!(model.clock, corrected_Δt, Δt)

    # Apply microphysics model update AFTER all RK3 stages and clock update
    # (for schemes like DCMIP2016Kessler that operate via direct state modification)
    microphysics_model_update!(model.microphysics, model)

    return nothing
end



#####
##### Adiabatic adjustment
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Adjust the thermodynamic state for adiabatic ascent/descent to a new height.
Conserves the thermodynamic variable (static energy or potential temperature).
"""
function adjust_adiabatically end

@inline adjust_adiabatically(𝒰::StaticEnergyState, z⁺, p⁺, constants) =
    reconstruct_thermodynamic_state(𝒰, 𝒰.static_energy, z⁺, p⁺)

@inline adjust_adiabatically(𝒰::LiquidIcePotentialTemperatureState, z⁺, p⁺, constants) =
    reconstruct_thermodynamic_state(𝒰, 𝒰.potential_temperature, z⁺, p⁺)
