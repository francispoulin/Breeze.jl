module TurbulenceClosures

export TKEBasedTurbulenceClosure,
       AbstractMixingLength,
       LocalMinimumMixingLength,
       IntegralMixingLength,
       GradientLimitedMixingLength,
       ConstantStabilityFunctions,
       RationalStabilityFunction,
       DryStaticStability,
       MoistStaticStability

using Adapt: Adapt, adapt
using DocStringExtensions: TYPEDEF, TYPEDFIELDS
using KernelAbstractions: @kernel, @index

using Oceananigans: Oceananigans
using Oceananigans.BoundaryConditions: BoundaryConditions, FieldBoundaryConditions, fill_halo_regions!
using Oceananigans.BuoyancyFormulations: ∂z_b
using Oceananigans.Fields: CenterField, ZFaceField, ZeroField
using Oceananigans.Grids: Center, Face, inactive_cell

using Oceananigans.Operators:
    # Face-centered difference operators with area metrics
    δxᶠᵃᵃ, δxᶜᵃᵃ, δyᵃᶜᵃ, δyᵃᶠᵃ, δzᵃᵃᶜ, δzᵃᵃᶠ,
    # Cell volumes (inverse)
    V⁻¹ᶠᶜᶜ, V⁻¹ᶜᶠᶜ, V⁻¹ᶜᶜᶠ, V⁻¹ᶜᶜᶜ,
    # Face areas for q-located fields
    Ax_qᶜᶜᶜ, Ax_qᶠᶠᶜ, Ax_qᶠᶜᶠ,
    Ay_qᶠᶠᶜ, Ay_qᶜᶜᶜ, Ay_qᶜᶠᶠ,
    Az_qᶠᶜᶠ, Az_qᶜᶠᶠ, Az_qᶜᶜᶜ,
    Ax_qᶠᶜᶜ, Ay_qᶜᶠᶜ, Az_qᶜᶜᶠ,
    # Interpolator functions used for ρᵣ at faces
    ℑxᶠᵃᵃ, ℑyᵃᶠᵃ, ℑzᵃᵃᶠ,
    ℑxyᶠᶠᵃ, ℑxzᶠᵃᶠ, ℑyzᵃᶠᶠ, ℑxzᶠᵃᶠ,
    # Vertical derivative at faces, for the static stability
    ∂zᶜᶜᶠ,
    # Cell height, for the mixing-length sweeps
    Δzᶜᶜᶜ

using Oceananigans.TurbulenceClosures:
    AbstractTurbulenceClosure,
    AbstractScalarDiffusivity,
    VerticalFormulation,
    VerticallyImplicitTimeDiscretization,
    ExplicitTimeDiscretization,
    getclosure,
    _viscous_flux_ux, _viscous_flux_uy, _viscous_flux_uz,
    _viscous_flux_vx, _viscous_flux_vy, _viscous_flux_vz,
    _viscous_flux_wx, _viscous_flux_wy, _viscous_flux_wz,
    _diffusive_flux_x, _diffusive_flux_y, _diffusive_flux_z

using Oceananigans.TimeSteppers: time_discretization
using Oceananigans.Utils: Utils, launch!, prettysummary

using ..AtmosphereModels: AtmosphereModels
using ..BoundaryConditions: BoundaryConditions as AtmosphereBoundaryConditions, DefaultGustiness, TKEGustiness

using Breeze.AtmosphereModels: grid_moisture_fractions, dynamics_pressure, standard_pressure, total_density, thermodynamic_state_density,
                              precipitating_mass_fraction
using Breeze.AtmosphereModels.Diagnostics: microphysics_phase_equilibrium
using Breeze.Thermodynamics: dry_air_gas_constant, vapor_gas_constant, saturation_specific_humidity,
                             equilibrated_surface, absolute_zero_latent_heat, specific_heat_difference
using Breeze.Utils: TYPEDSIGNATURES_WITH_DEFAULTS

#####
##### Fallbacks for closure = nothing
#####

@inline AtmosphereModels.∂ⱼ_𝒯₁ⱼ(i, j, k, grid, ρ, ::Nothing, args...) = zero(grid)
@inline AtmosphereModels.∂ⱼ_𝒯₂ⱼ(i, j, k, grid, ρ, ::Nothing, args...) = zero(grid)
@inline AtmosphereModels.∂ⱼ_𝒯₃ⱼ(i, j, k, grid, ρ, ::Nothing, args...) = zero(grid)
@inline AtmosphereModels.∇_dot_Jᶜ(i, j, k, grid, ρ, ::Nothing, args...) = zero(grid)

#####
##### Density-weighted fluxes for tuples of closures
#####

@inline sum_closure_fluxes(i, j, k, grid, flux, ρ, ::Tuple{}, ::Tuple{}, args...) = zero(grid)

@inline function sum_closure_fluxes(flux, i, j, k, grid, ρ,
                                    closures::Tuple{C, Vararg}, closure_fields::Tuple{F, Vararg},
                                    args...) where {C, F}
    return flux(i, j, k, grid, ρ, first(closures), first(closure_fields), args...) +
           sum_closure_fluxes(flux, i, j, k, grid, ρ, Base.tail(closures), Base.tail(closure_fields), args...)
end

@inline AtmosphereModels.∇_dot_Jᶜ(i, j, k, grid, ρ, closures::Tuple, closure_fields::Tuple,
                                  id, c, clock, model_fields, buoyancy) =
    sum_closure_fluxes(AtmosphereModels.∇_dot_Jᶜ, i, j, k, grid, ρ, closures, closure_fields,
                       id, c, clock, model_fields, buoyancy)

@inline AtmosphereModels.∂ⱼ_𝒯₁ⱼ(i, j, k, grid, ρ, closures::Tuple, closure_fields::Tuple,
                                clock, model_fields, buoyancy) =
    sum_closure_fluxes(AtmosphereModels.∂ⱼ_𝒯₁ⱼ, i, j, k, grid, ρ, closures, closure_fields,
                       clock, model_fields, buoyancy)

@inline AtmosphereModels.∂ⱼ_𝒯₂ⱼ(i, j, k, grid, ρ, closures::Tuple, closure_fields::Tuple,
                                clock, model_fields, buoyancy) =
    sum_closure_fluxes(AtmosphereModels.∂ⱼ_𝒯₂ⱼ, i, j, k, grid, ρ, closures, closure_fields,
                       clock, model_fields, buoyancy)

@inline AtmosphereModels.∂ⱼ_𝒯₃ⱼ(i, j, k, grid, ρ, closures::Tuple, closure_fields::Tuple,
                                clock, model_fields, buoyancy) =
    sum_closure_fluxes(AtmosphereModels.∂ⱼ_𝒯₃ⱼ, i, j, k, grid, ρ, closures, closure_fields,
                       clock, model_fields, buoyancy)

#####
##### Scalar (tracer) dynamic fluxes: J = ρᵣ τ
#####

# Face flux wrappers that call Oceananigans' kinematic diffusive fluxes and
# multiply by ρᵣ at the appropriate face.
# Note: args must include (disc, closure, closure_fields, id, c, clock, model_fields, buoyancy)
# where id is the tracer index (Val(n)) and c is the tracer field.

@inline Jᶜx(i, j, k, grid, ρ, args...) = ℑxᶠᵃᵃ(i, j, k, grid, ρ) * _diffusive_flux_x(i, j, k, grid, args...)
@inline Jᶜy(i, j, k, grid, ρ, args...) = ℑyᵃᶠᵃ(i, j, k, grid, ρ) * _diffusive_flux_y(i, j, k, grid, args...)
@inline Jᶜz(i, j, k, grid, ρ, args...) = ℑzᵃᵃᶠ(i, j, k, grid, ρ) * _diffusive_flux_z(i, j, k, grid, args...)

@inline function AtmosphereModels.∇_dot_Jᶜ(i, j, k, grid, ρᵣ, closure::AbstractTurbulenceClosure, closure_fields, id, c, clock, model_fields, buoyancy)
    disc = time_discretization(closure)
    return V⁻¹ᶜᶜᶜ(i, j, k, grid) * (
          δxᶜᵃᵃ(i, j, k, grid, Ax_qᶠᶜᶜ, Jᶜx, ρᵣ, disc, closure, closure_fields, id, c, clock, model_fields, buoyancy)
        + δyᵃᶜᵃ(i, j, k, grid, Ay_qᶜᶠᶜ, Jᶜy, ρᵣ, disc, closure, closure_fields, id, c, clock, model_fields, buoyancy)
        + δzᵃᵃᶜ(i, j, k, grid, Az_qᶜᶜᶠ, Jᶜz, ρᵣ, disc, closure, closure_fields, id, c, clock, model_fields, buoyancy))
end

#####
##### Momentum dynamic stresses: 𝒯 = ρᵣ τ
#####

# Face stress wrappers for u-momentum
@inline 𝒯_ux(i, j, k, grid, ρ, args...) = @inbounds ρ[i, j, k]     * _viscous_flux_ux(i, j, k, grid, args...)
@inline 𝒯_uy(i, j, k, grid, ρ, args...) = ℑxyᶠᶠᵃ(i, j, k, grid, ρ) * _viscous_flux_uy(i, j, k, grid, args...)
@inline 𝒯_uz(i, j, k, grid, ρ, args...) = ℑxzᶠᵃᶠ(i, j, k, grid, ρ) * _viscous_flux_uz(i, j, k, grid, args...)

@inline 𝒯_vx(i, j, k, grid, ρ, args...) = ℑxyᶠᶠᵃ(i, j, k, grid, ρ) * _viscous_flux_vx(i, j, k, grid, args...)
@inline 𝒯_vy(i, j, k, grid, ρ, args...) = @inbounds ρ[i, j, k]     * _viscous_flux_vy(i, j, k, grid, args...)
@inline 𝒯_vz(i, j, k, grid, ρ, args...) = ℑyzᵃᶠᶠ(i, j, k, grid, ρ) * _viscous_flux_vz(i, j, k, grid, args...)

@inline 𝒯_wx(i, j, k, grid, ρ, args...) = ℑxzᶠᵃᶠ(i, j, k, grid, ρ) * _viscous_flux_wx(i, j, k, grid, args...)
@inline 𝒯_wy(i, j, k, grid, ρ, args...) = ℑyzᵃᶠᶠ(i, j, k, grid, ρ) * _viscous_flux_wy(i, j, k, grid, args...)
@inline 𝒯_wz(i, j, k, grid, ρ, args...) = @inbounds ρ[i, j, k]     * _viscous_flux_wz(i, j, k, grid, args...)

@inline function AtmosphereModels.∂ⱼ_𝒯₁ⱼ(i, j, k, grid, ρᵣ, closure::AbstractTurbulenceClosure, closure_fields, clock, model_fields, buoyancy)
    disc = time_discretization(closure)
    return V⁻¹ᶠᶜᶜ(i, j, k, grid) * (
          δxᶠᵃᵃ(i, j, k, grid, Ax_qᶜᶜᶜ, 𝒯_ux, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δyᵃᶜᵃ(i, j, k, grid, Ay_qᶠᶠᶜ, 𝒯_uy, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δzᵃᵃᶜ(i, j, k, grid, Az_qᶠᶜᶠ, 𝒯_uz, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy))
end

@inline function AtmosphereModels.∂ⱼ_𝒯₂ⱼ(i, j, k, grid, ρᵣ, closure::AbstractTurbulenceClosure, closure_fields, clock, model_fields, buoyancy)
    disc = time_discretization(closure)
    return V⁻¹ᶜᶠᶜ(i, j, k, grid) * (
          δxᶜᵃᵃ(i, j, k, grid, Ax_qᶠᶠᶜ, 𝒯_vx, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δyᵃᶠᵃ(i, j, k, grid, Ay_qᶜᶜᶜ, 𝒯_vy, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δzᵃᵃᶜ(i, j, k, grid, Az_qᶜᶠᶠ, 𝒯_vz, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy))
end

# Face stress wrappers for w-momentum

@inline function AtmosphereModels.∂ⱼ_𝒯₃ⱼ(i, j, k, grid, ρᵣ, closure::AbstractTurbulenceClosure, closure_fields, clock, model_fields, buoyancy)
    disc = time_discretization(closure)
    return V⁻¹ᶜᶜᶠ(i, j, k, grid) * (
          δxᶜᵃᵃ(i, j, k, grid, Ax_qᶠᶜᶠ, 𝒯_wx, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δyᵃᶜᵃ(i, j, k, grid, Ay_qᶜᶠᶠ, 𝒯_wy, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy)
        + δzᵃᵃᶠ(i, j, k, grid, Az_qᶜᶜᶜ, 𝒯_wz, ρᵣ, disc, closure, closure_fields, clock, model_fields, buoyancy))
end

include("static_stability.jl")
include("tke_based_turbulence_closure.jl")
include("richardson_number_stability_functions.jl")

end # module TurbulenceClosures
