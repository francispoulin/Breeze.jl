#####
##### AnelasticDynamics definition
#####

struct AnelasticDynamics{R, P, FT}
    reference_state :: R
    pressure_anomaly :: P
    pressure_solver_float_type :: FT
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return `AnelasticDynamics` representing incompressible fluid dynamics expanded about `reference_state`.

Keyword arguments
=================

- `pressure_solver_float_type`: floating-point type of the anelastic pressure solve. Default: `Float64`,
  also for a `Float32` model. The Fourier–tridiagonal solve is poorly conditioned for the longest
  horizontal waves under a tall, strongly stratified column, and can be unstable in `Float32` on
  large domains. When it differs from the grid's type, the solver is built on a copy of the grid in
  this type, and the pressure is returned in the model's precision.
"""
AnelasticDynamics(reference_state; pressure_solver_float_type=Float64) =
    AnelasticDynamics(reference_state, nothing, pressure_solver_float_type)

# Kernels never need the solver's float type, and a `DataType` is not a valid GPU kernel argument.
Adapt.adapt_structure(to, dynamics::AnelasticDynamics) =
    AnelasticDynamics(adapt(to, dynamics.reference_state),
                      adapt(to, dynamics.pressure_anomaly),
                      nothing)

#####
##### Default dynamics and materialization
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct a "stub" `AnelasticDynamics` with just the `reference_state`.
The pressure anomaly field is materialized later in the model constructor.
"""
function AtmosphereModels.default_dynamics(grid, constants)
    reference_state = ReferenceState(grid, constants)
    return AnelasticDynamics(reference_state)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Materialize a stub `AnelasticDynamics` into a full dynamics object with the pressure anomaly field.
"""
function AtmosphereModels.materialize_dynamics(dynamics::AnelasticDynamics, grid, boundary_conditions, thermodynamic_constants)
    pressure_anomaly = CenterField(grid)
    return AnelasticDynamics(dynamics.reference_state, pressure_anomaly, dynamics.pressure_solver_float_type)
end

#####
##### Pressure interface
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the dynamics pressure field for `AnelasticDynamics`, in Pa.

For anelastic models, this is the time-independent hydrostatic reference state
pressure ``pᵣ(z)``.
"""
AtmosphereModels.dynamics_pressure(dynamics::AnelasticDynamics) = dynamics.reference_state.pressure

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the non-hydrostatic pressure anomaly for `AnelasticDynamics`, in Pa.

!!! note "Kinematic pressure versus pressure"

    The internal field stores the kinematic pressure anomaly, i.e., ``p' / ρᵣ``
    (in m²/s²); this function returns ``p'`` in Pa.
"""
function AtmosphereModels.pressure_anomaly(dynamics::AnelasticDynamics)
    ρᵣ = dynamics.reference_state.density
    p′_over_ρᵣ = dynamics.pressure_anomaly
    return ρᵣ * p′_over_ρᵣ
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the total pressure for `AnelasticDynamics`, in Pa.
That is ``p = p̄ + p'``, where ``p̄`` is the hydrostatic reference pressure
and ``p'`` is the non-hydrostatic pressure anomaly.
"""
function AtmosphereModels.total_pressure(dynamics::AnelasticDynamics)
    p̄ = dynamics_pressure(dynamics)
    p′ = pressure_anomaly(dynamics)
    return p̄ + p′
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Default surface temperature for `BulkDrag` under `AnelasticDynamics`: the
reference-state temperature at the bottom face of the domain.

Used only when the user constructs `BulkDrag` without an explicit
`surface_temperature`. The result is a horizontally uniform scalar.
"""
AtmosphereModels.default_drag_surface_temperature(dynamics::AnelasticDynamics, grid, constants) =
    surface_temperature_value(dynamics.reference_state)

#####
##### Density and pressure access interface
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the reference density field for `AnelasticDynamics`.

For anelastic models, the continuity density is the time-independent
reference state density ``ρᵣ(z)``.
"""
AtmosphereModels.continuity_density(dynamics::AnelasticDynamics) = dynamics.reference_state.density

# The total density ρᵣ(z) is the reference state's, not the local state's, so evaluate the
# equation of state at the reference pressure with the local temperature and moisture:
# ρ = pᵣ(z) / (Rᵐ(q) T). This is also the density in the anelastic buoyancy.
@inline AtmosphereModels.thermodynamic_state_density(i, j, k, dynamics::AnelasticDynamics, T, q, constants) =
    fixed_pressure_state_density(i, j, k, dynamics, T, q, constants)

#####
##### Prognostic fields
#####

# Anelastic dynamics has no prognostic density - the density is the fixed reference state
AtmosphereModels.prognostic_dynamics_field_names(::AnelasticDynamics) = ()
AtmosphereModels.additional_dynamics_field_names(::AnelasticDynamics) = ()

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the surface pressure from the reference state for boundary condition regularization.
"""
AtmosphereModels.base_pressure(dynamics::AnelasticDynamics) = dynamics.reference_state.base_pressure

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the reference pressure at the bottom face of the domain, as a 2D field.
"""
AtmosphereModels.surface_pressure(dynamics::AnelasticDynamics) = dynamics.reference_state.surface_pressure

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the standard pressure from the reference state for potential temperature calculations.
"""
AtmosphereModels.standard_pressure(dynamics::AnelasticDynamics) = dynamics.reference_state.standard_pressure

AtmosphereModels.dynamics_reference_state(dynamics::AnelasticDynamics) = dynamics.reference_state

#####
##### Show methods
#####

function Base.summary(dynamics::AnelasticDynamics)
    p₀_str = prettysummary(dynamics.reference_state.base_pressure)
    θ₀_str = prettysummary(dynamics.reference_state.potential_temperature)
    return string("AnelasticDynamics(p₀=", p₀_str, ", θ₀=", θ₀_str, ")")
end

function Base.show(io::IO, dynamics::AnelasticDynamics)
    print(io, summary(dynamics), '\n')
    print(io, "├── pressure_solver_float_type: ", dynamics.pressure_solver_float_type, '\n')
    if dynamics.pressure_anomaly === nothing
        print(io, "└── pressure_anomaly: not materialized")
    else
        print(io, "└── pressure_anomaly: ", prettysummary(dynamics.pressure_anomaly))
    end
end

#####
##### Momentum and velocity materialization
#####

function AtmosphereModels.materialize_momentum_and_velocities(dynamics::AnelasticDynamics, grid, boundary_conditions)
    ρu = XFaceField(grid, boundary_conditions=boundary_conditions.ρu)
    ρv = YFaceField(grid, boundary_conditions=boundary_conditions.ρv)
    ρw = ZFaceField(grid, boundary_conditions=boundary_conditions.ρw)
    momentum = (; ρu, ρv, ρw)

    # Velocity is diagnostic (u = ρu/ρ via compute_velocities!). Use the auxiliary-field
    # default BCs (`nothing` on Bounded-Face sides, Periodic on Periodic sides), which
    # is what XFaceField gives us when constructed with no `boundary_conditions=` kwarg.
    # `nothing` on Bounded-Face prevents `fill_halo_regions!(velocities)` from clobbering
    # the kernel-computed boundary face — momentum carries the wall BC.
    u = XFaceField(grid)
    v = YFaceField(grid)
    w = ZFaceField(grid)
    velocities = (; u, v, w)

    return momentum, velocities
end
