"""
    KinematicDriver

Module implementing kinematic dynamics for atmosphere models.

Kinematic dynamics prescribes the velocity field rather than solving for it,
enabling isolated testing of microphysics, thermodynamics, and other physics
without the complexity of solving the momentum equations.

This is analogous to the `kin1d` driver in P3-microphysics.
"""
module KinematicDriver

export
    PrescribedDensity,
    PrescribedDynamics,
    KinematicModel

using Adapt: Adapt, adapt
using DocStringExtensions: TYPEDEF
using KernelAbstractions: @kernel, @index

using Oceananigans: Oceananigans, CenterField, XFaceField, YFaceField, ZFaceField, Field
using Oceananigans.BoundaryConditions: FieldBoundaryConditions, ValueBoundaryCondition, fill_halo_regions!
using Oceananigans.Architectures: on_architecture
using Oceananigans.Fields: AbstractField, FunctionField, ZeroField, field, set!
using Oceananigans.Grids: Face, Center, znode
using Oceananigans.Operators: Δzᶜᶜᶜ
using Oceananigans.TimeSteppers: Clock, TimeSteppers
using Oceananigans.Utils: launch!, prettysummary

# Import PrescribedVelocityFields from Oceananigans
using Oceananigans.Models.HydrostaticFreeSurfaceModels: PrescribedVelocityFields

using Breeze.AtmosphereModels: AtmosphereModels, AtmosphereModel, continuity_density,
                               fixed_pressure_state_density
using Breeze.Thermodynamics: ReferenceState, column_surface_pressure,
                             surface_boundary_value, surface_pressure_from_cell_center,
                             surface_state_field
using Breeze.Utils: TYPEDSIGNATURES_WITH_DEFAULTS

include("prescribed_dynamics.jl")

# Type alias for kinematic models
const KinematicModel = AtmosphereModel{<:PrescribedDynamics}

include("kinematic_driver_time_stepping.jl")

end # module
