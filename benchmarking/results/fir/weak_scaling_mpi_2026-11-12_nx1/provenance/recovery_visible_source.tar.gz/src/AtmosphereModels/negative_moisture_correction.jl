#####
##### Negative moisture correction
#####
#
# After advection, individual moisture species can become negative because
# the advection operator might not be positive-definite. This correction:
#
#   1. Species borrowing: fix negatives by borrowing from related species
#      in the same grid cell, following the chain:
#        rain <- cloud liquid <- vapor  (warm phase)
#   2. Vertical borrowing (optional): remaining negative vapor is fixed by
#      transferring mass from adjacent levels, sweeping top->bottom then
#      one upward step.
#
# Conservation:
#   - Species borrowing: total moisture at each level is preserved (sum unchanged).
#   - Vertical: column-integrated moisture is preserved (Δz-weighted).
#   - Energy: no explicit adjustment needed because Breeze's thermodynamic
#     prognostics (θ_li or moist static energy) are conserved under phase
#     changes. Temperature is correctly rediagnosed at the next auxiliary
#     variable update.
#####

#####
##### Correction scheme types
#####

"""
$(TYPEDEF)

Abstract supertype for negative moisture correction schemes.

See [`fix_negative_moisture!`](@ref) for details.
"""
abstract type AbstractNegativeMoistureCorrection end

"""
$(TYPEDEF)

Redistribute negative vapor vertically within each column via a top-to-bottom
sweep that pushes deficits downward, followed by one bottom-to-top borrowing
step if the bottom level is still negative.

This scheme can be used on its own to correct the moisture prognostic, or as the
second phase of [`SpeciesBorrowing`](@ref) to clean up any vapor deficit that
remains after same-level species borrowing.

Column-integrated moisture is conserved (``Δz``-weighted).
"""
struct VerticalBorrowing <: AbstractNegativeMoistureCorrection end

"""
$(TYPEDEF)

Correct negative moisture produced by advection via same-level species borrowing.

At each grid cell, negative hydrometeors borrow from lighter species in the chain
(e.g. rain <- cloud liquid <- vapor). Vertical redistribution of any remaining
negative vapor is performed when `vertical_borrowing` is set to [`VerticalBorrowing`](@ref).

For microphysics with number concentrations (categories that subtype
[`AbstractNumberConcentrationCategories`](@ref)), orphaned number concentrations
are zeroed and negative number concentrations are clamped after mass borrowing.

See [`fix_negative_moisture!`](@ref) for details.

# Fields
- `vertical_borrowing`: `nothing` (default) or `VerticalBorrowing()` to enable vertical redistribution
"""
struct SpeciesBorrowing{VB} <: AbstractNegativeMoistureCorrection
    vertical_borrowing :: VB
end

SpeciesBorrowing(; vertical_borrowing=nothing) = SpeciesBorrowing(vertical_borrowing)

Base.summary(::VerticalBorrowing) = "VerticalBorrowing"

Base.summary(correction::SpeciesBorrowing) =
    string("SpeciesBorrowing(vertical_borrowing = ",
           isnothing(correction.vertical_borrowing) ? "nothing" :
               summary(correction.vertical_borrowing), ")")

"""
$(TYPEDEF)

Abstract supertype for microphysics categories that track number concentrations
(e.g. two-moment schemes, aerosol-aware schemes).

Subtypes opt in to number concentration corrections (orphan zeroing and clamping)
in the negative moisture correction. Schemes should extend
[`correction_number_mass_pairs`](@ref) and [`correction_number_fields`](@ref)
for their specific prognostic number fields.
"""
abstract type AbstractNumberConcentrationCategories end

#####
##### Correction field interfaces
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return a tuple of `Field` objects for density-weighted prognostic moisture mass
fields that participate in the negative-moisture correction, ordered from heaviest
hydrometeor to lightest.

Each field borrows from the next in the chain. The lightest field borrows from
the moisture prognostic (vapor or equilibrium moisture, stored in
`model.moisture_density`). Remaining vapor deficits are fixed by vertical borrowing
when enabled.

Default: empty tuple (no correction).
"""
correction_moisture_fields(microphysics, microphysical_fields) = ()

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return a tuple of `(number_field, mass_field)` pairs for number concentration
consistency. After species borrowing, any number field whose corresponding
mass field is non-positive is zeroed to avoid unphysical states (e.g., finite
droplet number with zero mass).

Only called for microphysics whose categories subtype
[`AbstractNumberConcentrationCategories`](@ref Breeze.AtmosphereModels.AbstractNumberConcentrationCategories).

Default: empty tuple (no number fields to correct).
"""
correction_number_mass_pairs(microphysics, microphysical_fields) = ()

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return a tuple of `Field` objects for density-weighted number concentration
fields that should be clamped to non-negative after advection.

Number concentrations can become negative because the advection scheme
might not be positive-definite. Unlike mass fields (which use borrowing to
preserve conservation), number concentrations are simply zeroed since there
is no meaningful conservation constraint for droplet number.

Only called for microphysics whose categories subtype
[`AbstractNumberConcentrationCategories`](@ref Breeze.AtmosphereModels.AbstractNumberConcentrationCategories).

Default: empty tuple (no number fields to clamp).
"""
correction_number_fields(microphysics, microphysical_fields) = ()

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Fix negative moisture mixing ratios produced by the advection operator.

Operates in one or two phases depending on the correction scheme:
1. **Species borrowing** ([`SpeciesBorrowing`](@ref Breeze.AtmosphereModels.SpeciesBorrowing),
    optional): at each grid cell, negative hydrometeors borrow from lighter
    species (rain <- cloud <- vapor).
2. **Vertical borrowing** ([`VerticalBorrowing`](@ref Breeze.AtmosphereModels.VerticalBorrowing),
    optional): negative vapor is redistributed vertically within each column
    (top->bottom sweep, then one bottom->top step).

For microphysics with number concentrations (categories subtying
[`AbstractNumberConcentrationCategories`](@ref Breeze.AtmosphereModels.AbstractNumberConcentrationCategories)),
orphaned number concentrations are zeroed and negatives are clamped after mass borrowing.

The correction is mass-conserving at each level for species borrowing and
column-integrated for vertical borrowing. No energy adjustment is needed because Breeze's thermodynamic
prognostics are moist-conserved variables.

The borrowing chain is defined by [`correction_moisture_fields`](@ref), which
microphysics schemes extend to specify their prognostic mass fields.
"""
fix_negative_moisture!(model) = fix_negative_moisture!(model.microphysics, model)

fix_negative_moisture!(::Nothing, model) = nothing

negative_moisture_correction(microphysics) = nothing

function fix_negative_moisture!(microphysics, model)
    correction = negative_moisture_correction(microphysics)
    correction === nothing && return nothing

    # Ordered mass fields that participate in species borrowing
    # (heaviest to lightest: rain <- cloud <- vapor).
    moisture_fields = correction_moisture_fields(microphysics, model.microphysical_fields)

    grid = model.grid
    arch = grid.architecture
    ρqᵛᵉ = model.moisture_density
    number_mass_pairs = correction_number_mass_pairs(microphysics, model.microphysical_fields)
    number_fields = correction_number_fields(microphysics, model.microphysical_fields)

    launch!(arch, grid, :xy,
            _fix_negative_moisture_column!,
            correction,
            moisture_fields, number_mass_pairs, number_fields, ρqᵛᵉ, grid)

    return nothing
end

#####
##### Column-wise kernel
#####

@kernel function _fix_negative_moisture_column!(correction, moisture_fields, number_mass_pairs, number_fields, ρqᵛᵉ, grid)
    i, j = @index(Global, NTuple)
    Nz = size(grid, 3)

    # Phase 1: Species borrowing at each level
    for k = 1:Nz
        apply_same_level_correction!(i, j, k, moisture_fields, ρqᵛᵉ, correction)
    end

    # Zero orphaned number concentrations (mass zeroed but number still positive)
    for k = 1:Nz
        zero_orphaned_numbers!(i, j, k, number_mass_pairs)
    end

    # Clamp negative number concentrations to zero
    for k = 1:Nz
        clamp_negative_numbers!(i, j, k, number_fields)
    end

    # Phase 2: Vertical borrowing (no-op when the scheme does not enable it)
    apply_vertical_correction!(ρqᵛᵉ, i, j, grid, correction)
end

@inline apply_same_level_correction!(i, j, k, moisture_fields, ρqᵛᵉ, ::VerticalBorrowing) = nothing

@inline function apply_same_level_correction!(i, j, k, moisture_fields, ρqᵛᵉ, ::SpeciesBorrowing)
    same_level_borrow!(i, j, k, moisture_fields, ρqᵛᵉ)
    return nothing
end

@inline apply_vertical_correction!(ρqᵛᵉ, i, j, grid, correction::VerticalBorrowing) =
    vertical_borrow!(ρqᵛᵉ, i, j, grid, correction)

@inline apply_vertical_correction!(ρqᵛᵉ, i, j, grid, correction::SpeciesBorrowing) =
    vertical_borrow!(ρqᵛᵉ, i, j, grid, correction.vertical_borrowing)

#####
##### Vertical borrowing helpers
#####

@inline vertical_borrow!(ρqᵛᵉ, i, j, grid, ::Nothing) = nothing

@inline function vertical_borrow!(ρqᵛᵉ, i, j, grid, ::VerticalBorrowing)
    Nz = size(grid, 3)
    # Sweep from top to bottom, pushing deficit to level below (more moisture there).
    # Breeze convention: k = 1 is bottom, k = Nz is top.
    for k = Nz:-1:2
        @inbounds ρqᵛ_k = ρqᵛᵉ[i, j, k]
        Δz_k = Δzᶜᶜᶜ(i, j, k, grid)
        Δz_below = Δzᶜᶜᶜ(i, j, k - 1, grid)

        # Mass deficit [kg/m²] to push downward (positive when the level is negative)
        negative = ρqᵛ_k < 0
        deficit = ifelse(negative, -ρqᵛ_k * Δz_k, zero(ρqᵛ_k))

        # Assigned, not incremented, because -ρqᵛ Δz / Δz need not round back to -ρqᵛ
        @inbounds ρqᵛᵉ[i, j, k] = ifelse(negative, zero(ρqᵛ_k), ρqᵛ_k)
        @inbounds ρqᵛᵉ[i, j, k - 1] -= deficit / Δz_below   # receive deficit
    end

    # If bottom level still negative, borrow from level above.
    # Use ifelse (not if/else) for GPU kernel compatibility.
    # When Nz < 2, clamp indices to 1 so reads are valid but dq_mass = 0.
    k_bot = 1
    k_top = min(2, Nz)  # safe index: equals 2 when Nz ≥ 2, equals Nz when Nz < 2

    @inbounds ρqᵛ_bot = ρqᵛᵉ[i, j, k_bot]
    @inbounds ρqᵛ_top = ρqᵛᵉ[i, j, k_top]

    Δz_bot = Δzᶜᶜᶜ(i, j, k_bot, grid)
    Δz_top = Δzᶜᶜᶜ(i, j, k_top, grid)

    can_borrow = (Nz ≥ 2) & (ρqᵛ_bot < 0) & (ρqᵛ_top > 0)
    needed = -ρqᵛ_bot * Δz_bot       # mass needed at bottom [kg/m²]
    available = ρqᵛ_top * Δz_top      # mass available above [kg/m²]
    dq_mass = ifelse(can_borrow, min(needed, available), zero(ρqᵛ_bot))

    # `min` returns one of its arguments, so these comparisons are exact
    funded = can_borrow & (dq_mass == needed)
    drained = can_borrow & (dq_mass == available)

    @inbounds ρqᵛᵉ[i, j, k_bot] = ifelse(funded, zero(ρqᵛ_bot), ρqᵛ_bot + dq_mass / Δz_bot)
    @inbounds ρqᵛᵉ[i, j, k_top] = ifelse(drained, zero(ρqᵛ_top), ρqᵛ_top - dq_mass / Δz_top)
end

#####
##### Recursive same-level borrowing helpers
#####

# Each negative field borrows from every lighter species in order. Searching the
# whole tail lets a deficit pass an empty immediate donor without making any donor
# negative.
#
# The recursion is over a `Tuple` of fields whose length is known at compile time, so with
# `@inline` it unrolls completely: no runtime recursion, no allocation, no dynamic dispatch.
# The unrolled work is O(N²) pointwise reads/writes for N condensate fields (each field
# scans the tail behind it), which is a few tens of flops for the N ≤ 10 schemes we run.
#
# Every reservoir is a partial density, and the transfers are made in those units.
@inline function same_level_borrow!(i, j, k, fields::Tuple{F1, Vararg}, ρqᵛᵉ) where {F1}
    ρq = fields[1]
    @inbounds mass = ρq[i, j, k]

    deficit = max(0, -mass)
    remaining = borrow_from_lighter_species!(i, j, k, Base.tail(fields), ρqᵛᵉ, deficit)

    # `zero(mass) - remaining`, not `-remaining`, so that a fully funded deficit is +0.0
    @inbounds ρq[i, j, k] = ifelse(mass < 0, zero(mass) - remaining, mass)

    same_level_borrow!(i, j, k, Base.tail(fields), ρqᵛᵉ)
    return nothing
end

# Empty tuple: nothing to do
@inline same_level_borrow!(i, j, k, ::Tuple{}, ρqᵛᵉ) = nothing

# Recurse through the candidate donors for one field, returning the partial density still unfunded.
@inline function borrow_from_lighter_species!(i, j, k, fields::Tuple{F1, Vararg}, ρqᵛᵉ, deficit) where {F1}
    ρq_donor = fields[1]
    @inbounds mass_donor = ρq_donor[i, j, k]

    borrowed = min(deficit, max(0, mass_donor))
    @inbounds ρq_donor[i, j, k] -= borrowed

    return borrow_from_lighter_species!(i, j, k, Base.tail(fields), ρqᵛᵉ, deficit - borrowed)
end

# Vapor is the donor of last resort.
@inline function borrow_from_lighter_species!(i, j, k, ::Tuple{}, ρqᵛᵉ, deficit)
    @inbounds vapor_mass = ρqᵛᵉ[i, j, k]
    borrowed = min(deficit, max(0, vapor_mass))
    @inbounds ρqᵛᵉ[i, j, k] -= borrowed
    return deficit - borrowed
end

#####
##### Number concentration consistency helpers
#####

# Zero number concentration when corresponding mass is non-positive
@inline function zero_orphaned_numbers!(i, j, k, pairs::Tuple{P, Vararg}) where {P}
    ρn, ρq = pairs[1]
    @inbounds ρn_val = ρn[i, j, k]
    @inbounds ρn[i, j, k] = ifelse(ρq[i, j, k] ≤ 0, zero(ρn_val), ρn_val)
    zero_orphaned_numbers!(i, j, k, Base.tail(pairs))
    return nothing
end

@inline zero_orphaned_numbers!(i, j, k, ::Tuple{}) = nothing

#####
##### Negative number concentration clamping
#####

# Clamp negative number concentrations to zero
@inline function clamp_negative_numbers!(i, j, k, fields::Tuple{F, Vararg}) where {F}
    f = fields[1]
    @inbounds f[i, j, k] = max(0, f[i, j, k])
    clamp_negative_numbers!(i, j, k, Base.tail(fields))
    return nothing
end

@inline clamp_negative_numbers!(i, j, k, ::Tuple{}) = nothing
