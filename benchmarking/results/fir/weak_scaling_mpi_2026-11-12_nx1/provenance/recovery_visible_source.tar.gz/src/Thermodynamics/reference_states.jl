using Oceananigans: Oceananigans, Center, Field, set!, fill_halo_regions!
using Oceananigans.Architectures: architecture, on_architecture
using Oceananigans.BoundaryConditions: FieldBoundaryConditions, ValueBoundaryCondition
using Oceananigans.Fields: AbstractField, CenterField, ZeroField
using Oceananigans.Grids: znode, Face, topology, Flat
using Oceananigans.Operators: Δzᶜᶜᶜ, Δzᶜᶜᶠ
using Oceananigans.Operators: ℑzᵃᵃᶠ, Δzᶜᶜᶠ
using Oceananigans.Utils: launch!

using Adapt: Adapt, adapt
using GPUArraysCore: @allowscalar
using KernelAbstractions: @kernel, @index

#####
##### Reference state computations for Boussinesq and Anelastic models
#####

struct ReferenceState{FT, SP, SD, STm, P, D, T, QV, QL, QI}
    base_pressure :: FT # p₀: the datum, reference pressure at z=0 (not the pressure at the ground)
    surface_pressure :: SP # pˢ: reference pressure at the bottom face, a 2D field
    surface_density :: SD # ρˢ: reference density at the bottom face, a 2D field
    surface_temperature :: STm # Tˢ: reference temperature at the bottom face, a 2D field
    potential_temperature :: FT  # reference potential temperature at z=0
    standard_pressure :: FT # pˢᵗ: reference pressure for potential temperature (default 1e5)
    pressure :: P
    density :: D
    temperature :: T
    vapor_mass_fraction :: QV
    liquid_mass_fraction :: QL
    ice_mass_fraction :: QI
end

Adapt.adapt_structure(to, ref::ReferenceState) =
    ReferenceState(adapt(to, ref.base_pressure),
                   adapt(to, ref.surface_pressure),
                   adapt(to, ref.surface_density),
                   adapt(to, ref.surface_temperature),
                   adapt(to, ref.potential_temperature),
                   adapt(to, ref.standard_pressure),
                   adapt(to, ref.pressure),
                   adapt(to, ref.density),
                   adapt(to, ref.temperature),
                   adapt(to, ref.vapor_mass_fraction),
                   adapt(to, ref.liquid_mass_fraction),
                   adapt(to, ref.ice_mass_fraction))

Base.eltype(::ReferenceState{FT}) where FT = FT

function Base.summary(ref::ReferenceState)
    FT = eltype(ref)
    return string("ReferenceState{$FT}(p₀=", prettysummary(ref.base_pressure),
                  ", θ₀=", prettysummary(ref.potential_temperature),
                  ", pˢᵗ=", prettysummary(ref.standard_pressure), ")")
end

Base.show(io::IO, ref::ReferenceState) = print(io, summary(ref))

#####
##### How to compute the reference state
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the density at the bottom face of the domain by interpolating the reference density field.
"""
function surface_density(ref::ReferenceState)
    ρ = ref.density
    grid = ρ.grid
    return @allowscalar ℑzᵃᵃᶠ(1, 1, 1, grid, ρ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the surface air density from surface pressure `p₀`, surface temperature `T₀`,
and thermodynamic `constants` using the ideal gas law for dry air.
"""
@inline function surface_density(p₀, T₀, constants)
    Rᵈ = dry_air_gas_constant(constants)
    return p₀ / (Rᵈ * T₀)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the surface air density from surface pressure `p₀`, potential temperature `θ₀`,
standard pressure `pˢᵗ`, and thermodynamic `constants` using the ideal gas law for dry air.

The temperature is computed from potential temperature using the Exner function:
`T₀ = Π₀ * θ₀` where `Π₀ = (p₀ / pˢᵗ)^(Rᵈ/cᵖᵈ)`.
"""
@inline function surface_density(p₀, θ₀, pˢᵗ, constants)
    Rᵈ = dry_air_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    Π₀ = (p₀ / pˢᵗ)^(Rᵈ / cᵖᵈ)
    T₀ = Π₀ * θ₀
    return p₀ / (Rᵈ * T₀)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the reference pressure at height `z` that associated with the reference pressure `p₀`,
potential temperature `θ₀`, and standard pressure `pˢᵗ`. The reference pressure is defined as
the pressure of dry air at the reference pressure and temperature.
"""
@inline function adiabatic_hydrostatic_pressure(z, p₀, θ₀, pˢᵗ, constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    Rᵈ = dry_air_gas_constant(constants)
    g = constants.gravitational_acceleration
    T₀ = θ₀ * (p₀ / pˢᵗ)^(Rᵈ / cᵖᵈ)
    return p₀ * (1 - g * z / (cᵖᵈ * T₀))^(cᵖᵈ / Rᵈ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the reference density at height `z` that associated with the reference pressure `p₀`,
potential temperature `θ₀`, and standard pressure `pˢᵗ`. The reference density is defined as
the density of dry air at the reference pressure and temperature.
"""
@inline function adiabatic_hydrostatic_density(z, p₀, θ₀, pˢᵗ, constants)
    Rᵈ = dry_air_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    pᵣ = adiabatic_hydrostatic_pressure(z, p₀, θ₀, pˢᵗ, constants)
    ρ₀ = surface_density(p₀, θ₀, pˢᵗ, constants)
    return ρ₀ * (pᵣ / p₀)^(1 - Rᵈ / cᵖᵈ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the density that keeps pressure unchanged when applying a potential-temperature
perturbation at fixed composition.

`pressure_balanced_density(ρ_background, θ_background, θ_initial)` applies the dry-air /
vapor-only relation, for which holding ``ρ θ`` fixed avoids seeding an acoustic pressure
perturbation.

For fixed-composition states with nonzero liquid or ice condensate, use
`pressure_balanced_density(ρ_background, θ_background, θ_initial, q, pᵣ, pˢᵗ, constants)`
instead. The condensate-aware method evaluates the full liquid-ice potential-temperature
equation of state before balancing density.

# Examples
```jldoctest
using Breeze.Thermodynamics: pressure_balanced_density

ρ_background = 1.0
θ_background = 300.0
θ_initial = 303.0
pressure_balanced_density(ρ_background, θ_background, θ_initial)

# output
0.9900990099009901
```
"""
@inline pressure_balanced_density(ρ_background, θ_background, θ_initial) =
    ρ_background * θ_background / θ_initial

@inline function pressure_balanced_density(ρ_background, θ_background, θ_initial,
                                          q::MoistureMassFractions, pᵣ, pˢᵗ, constants)
    T_background = temperature(LiquidIcePotentialTemperatureState(θ_background, q, pˢᵗ, pᵣ), constants)
    T_initial = temperature(LiquidIcePotentialTemperatureState(θ_initial, q, pˢᵗ, pᵣ), constants)
    return ρ_background * T_background / T_initial
end

#####
##### Hydrostatic reference profiles from temperature and moisture
#####

@kernel function _compute_hydrostatic_reference!(pᵣ, ρᵣ, T, qᵛ, qˡ, qⁱ, grid, Nz, p₀, Rᵈ, Rᵛ, g)
    _ = @index(Global)
    c = Center()

    # Use first-level thermodynamic values as surface approximation
    @inbounds begin
        T¹  = T[1, 1, 1]
        qᵛ¹ = qᵛ[1, 1, 1]
        qˡ¹ = qˡ[1, 1, 1]
        qⁱ¹ = qⁱ[1, 1, 1]
    end
    qᵈ¹ = 1 - qᵛ¹ - qˡ¹ - qⁱ¹
    Rᵐ¹ = qᵈ¹ * Rᵈ + qᵛ¹ * Rᵛ

    # Initialize at z = 0 (surface)
    z⁻   = zero(T¹)
    RᵐT⁻ = Rᵐ¹ * T¹
    p⁻   = p₀

    # Integrate upward: d(ln p)/dz = -g / (Rᵐ T)
    for k in 1:Nz
        zᵏ = znode(1, 1, k, grid, c, c, c)
        @inbounds begin
            Tᵏ  = T[1, 1, k]
            qᵛᵏ = qᵛ[1, 1, k]
            qˡᵏ = qˡ[1, 1, k]
            qⁱᵏ = qⁱ[1, 1, k]
        end
        qᵈᵏ = 1 - qᵛᵏ - qˡᵏ - qⁱᵏ
        Rᵐᵏ = qᵈᵏ * Rᵈ + qᵛᵏ * Rᵛ
        RᵐTᵏ = Rᵐᵏ * Tᵏ

        Δz = zᵏ - z⁻
        pᵏ = p⁻ * exp(-g * Δz / ((RᵐT⁻ + RᵐTᵏ) / 2))

        @inbounds pᵣ[1, 1, k] = pᵏ
        @inbounds ρᵣ[1, 1, k] = pᵏ / RᵐTᵏ

        z⁻   = zᵏ
        RᵐT⁻ = RᵐTᵏ
        p⁻   = pᵏ
    end
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

A 2D `(Center, Center, Nothing)` field holding a surface (bottom-face) quantity, initialized to
`value`. Bottom-face quantities are stored in fields rather than as plain scalars so that the
`ValueBoundaryCondition` of the reference `pressure`/`density` can point at them once, at
construction: a reference reset then writes new boundary values *into the field* and the boundary
condition follows, with no need to rebuild the reference state or its fields. That is what keeps
the reference states immutable, and therefore `isbits` after `Adapt`, which they must be because
the dynamics that owns them is passed directly to GPU kernels.
"""
surface_state_field(grid, value) = set_surface_state!(Field{Center, Center, Nothing}(grid), value)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Write `value` into a surface field and fill its halos. The halo fill is the load-bearing half: the
field is aliased into a `ValueBoundaryCondition` by [`surface_boundary_value`](@ref) and read by the
column kernels, so a write that skipped it would leave both stale.
"""
function set_surface_state!(field, value)
    set!(field, value)
    fill_halo_regions!(field)
    return field
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

A surface quantity in the form Oceananigans' boundary conditions expect. A
`Field{Center, Center, Nothing}` already *is* that form: Oceananigans defines
`getbc(::ZReducedField, i, j, grid, args...) = condition[i, j, 1]` and an `Adapt` rule that
preserves the location of a reduced field, so one can be used as a boundary value directly. The
field is therefore passed through rather than wrapped.

Passing the field itself, rather than a `view` of its interior, is what makes the aliasing hold: a
`ValueBoundaryCondition` built from it reads whatever the field currently contains, so a reference
reset that writes new surface values in place updates every boundary condition built from it, with
nothing rebuilt.
"""
surface_boundary_value(field::AbstractField) = field
surface_boundary_value(value::Number) = value

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Reject the old `surface_pressure` keyword, which named the reference pressure datum at ``z = 0``
and is now `base_pressure`.

Worth an explicit error rather than a `MethodError`, because the name was not retired: it now names
the pressure at a column's *bottom face*, which is derived from `base_pressure` and the grid rather
than set by the user, and which differs from the datum by ``O(ρgh)`` whenever the ground is not at
``z = 0``. A caller who moved an old script across would otherwise have no hint that the quantity
they meant is spelled differently now, nor that the spelling they used means something else.
"""
reject_renamed_surface_pressure(::Nothing) = nothing

reject_renamed_surface_pressure(surface_pressure) =
    throw(ArgumentError("`surface_pressure` was renamed to `base_pressure`: the reference pressure \
                         at z = 0, which is the datum the hydrostatic profiles are anchored to. \
                         `surface_pressure` now names the reference pressure at a column's bottom \
                         face — the ground — which is derived rather than prescribed, so passing \
                         $(surface_pressure) here would not mean what it used to."))

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

The bottom-face pressure of `ref` as a scalar. Only valid for a reference whose bottom-face
pressure is horizontally uniform. For a horizontally varying 3D reference or over terrain,
`ref.surface_pressure` must be read as a field.
"""
surface_pressure_value(ref) = @allowscalar ref.surface_pressure[1, 1, 1]

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

The horizontally uniform bottom-face temperature of `ref` as a scalar. Stored rather than recovered
from `surface_pressure` and `surface_density` through a gas law, because which gas constant closes
that inversion depends on how the reference was built: the constructor's `density` is dry, while a
reset rebuilds it with the mixture constant, so `pˢ / (Rᵈ ρˢ)` is the temperature in one case and
the *virtual* temperature in the other.
"""
surface_temperature_value(ref) = @allowscalar ref.surface_temperature[1, 1, 1]

# Reduce the z = 0 datum to the bottom face along the *isothermal* layer implied by the first
# level's mixture temperature. This must match how `_compute_hydrostatic_reference!` takes its own
# first step — it integrates d(ln p)/dz = -g/(Rᵐ T) from z = 0 with `Rᵐ¹ T¹` over the whole gap —
# or the stored ground pressure would not lie on the profile it anchors. A `ReferenceState` is
# parameterized by T(z) and holds no data below its bottom face, so extending T¹ downward is the
# only reduction available here; the θ-parameterized `ExnerReferenceState` integrates its profile
# instead (see `moist_hydrostatic_pressure`).
#
# The constructor does not use this reduction: given θ analytically it integrates in closed form,
# exact for constant θ. So the two disagree on a raised domain — for z = (2000, 6000), θ₀ = 288,
# they anchor at 79320.21 and 78446.23 Pa, a 1.1% shift of the stored ground pressure and of the
# boundary value aliased to it, from recomputing an unchanged reference. The closed form is the
# accurate one; the gap below the domain does not shrink with resolution. Both are the identity
# when the bottom face is at z = 0.
function update_reference_surface_state!(ref::ReferenceState, constants)
    FT = eltype(ref)
    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    g = constants.gravitational_acceleration
    zˢ = bottom_face_height(ref.pressure.grid)

    T¹, qᵛ¹, qˡ¹, qⁱ¹ = @allowscalar begin
        ref.temperature[1, 1, 1],
        ref.vapor_mass_fraction[1, 1, 1],
        ref.liquid_mass_fraction[1, 1, 1],
        ref.ice_mass_fraction[1, 1, 1]
    end

    qᵈ¹ = 1 - qᵛ¹ - qˡ¹ - qⁱ¹
    Rᵐ¹ = qᵈ¹ * Rᵈ + qᵛ¹ * Rᵛ
    pˢ = ref.base_pressure * exp(-g * zˢ / (Rᵐ¹ * T¹))
    ρˢ = pˢ / (Rᵐ¹ * T¹)

    set_surface_state!(ref.surface_pressure, convert(FT, pˢ))
    set_surface_state!(ref.surface_density, convert(FT, ρˢ))
    # The reduction above extends T¹ isothermally to the bottom face, so T¹ *is* the temperature
    # there under this reference.
    set_surface_state!(ref.surface_temperature, convert(FT, T¹))
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the hydrostatic reference pressure and density profiles from the
temperature and moisture mass fraction profiles stored in `ref`.

The integration uses the mixture gas constant `Rᵐ = qᵈ Rᵈ + qᵛ Rᵛ`
(where `qᵈ = 1 - qᵛ - qˡ - qⁱ`) and the ideal gas law `ρ = p / (Rᵐ T)`.
"""
function compute_hydrostatic_reference!(ref::ReferenceState, constants)
    grid = ref.pressure.grid
    update_reference_surface_state!(ref, constants)
    arch = architecture(grid)
    Nz = grid.Nz

    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    g = constants.gravitational_acceleration
    p₀ = ref.base_pressure

    launch!(arch, grid, tuple(1),
            _compute_hydrostatic_reference!,
            ref.pressure, ref.density,
            ref.temperature, ref.vapor_mass_fraction,
            ref.liquid_mass_fraction, ref.ice_mass_fraction,
            grid, Nz, p₀, Rᵈ, Rᵛ, g)

    fill_halo_regions!(ref.pressure)
    fill_halo_regions!(ref.density)

    return nothing
end

#####
##### Constructor
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Evaluate `integrate(nsteps)` with the step count repeatedly doubled from `initial_steps`, returning
the first refinement whose value changes by less than the relative `tolerance`. Returns `y₀`
unchanged when `z == 0`.

Shared by both hydrostatic reductions from the ``z = 0`` datum, which differ only in their stepper:
[`midpoint_integral`](@ref) when the integrand depends on height alone, and
[`runge_kutta2_integral`](@ref) when it also depends on the pressure being solved for.

Warns rather than returning silently if `max_steps` is reached without converging: an unconverged
reduction would otherwise anchor a whole reference profile at a wrong ground pressure with no
indication.
"""
function converge_by_step_doubling(integrate, y₀, z, tolerance, initial_steps, max_steps)
    z == 0 && return y₀

    nsteps = initial_steps
    coarse = integrate(nsteps)
    while nsteps < max_steps
        nsteps *= 2
        fine = integrate(nsteps)
        abs(fine - coarse) ≤ tolerance * abs(fine) && return fine
        coarse = fine
    end

    @warn "Hydrostatic reduction over $z m did not reach a relative tolerance of $tolerance in \
           $max_steps steps; using the most refined value." maxlog=1
    return coarse
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Midpoint quadrature of ``∂y/∂z = \\mathrm{dydz}(z)`` from ``0`` to `z` in `nsteps` steps, for an
integrand that depends on height alone.
"""
function midpoint_integral(z, y₀, dydz, nsteps)
    dz = z / nsteps
    y = y₀
    for i in 1:nsteps
        # `oftype` rather than a bare `0.5`, which would promote a Float32 `dz` to Float64. Written
        # this way — and not as `(i - 1) * dz + dz / 2` — so the abscissae are bit-for-bit what they
        # were before this quadrature was factored out of `converged_hydrostatic_integral`, which
        # keeps reference profiles built from a `z`-dependent θ reproducible to the last ulp.
        zᵢ = (i - oftype(dz, 0.5)) * dz
        y += dydz(zᵢ) * dz
    end
    return y
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Explicit midpoint (RK2) integration of ``∂y/∂z = \\mathrm{dydz}(z, y)`` from ``0`` to `z` in
`nsteps` steps, for an integrand that also depends on the solution.
"""
function runge_kutta2_integral(z, y₀, dydz, nsteps)
    dz = z / nsteps
    half_dz = dz / 2
    y = y₀
    for i in 1:nsteps
        zₗ = (i - 1) * dz
        k₁ = dydz(zₗ, y)
        k₂ = dydz(zₗ + half_dz, y + k₁ * half_dz)
        y += k₂ * dz
    end
    return y
end

# Dry hydrostatic balance is linear in the Exner function Π = (p / pˢᵗ)^κ,
# so integrating Π(z) directly avoids repeatedly evaluating the nonlinear EOS.
converged_hydrostatic_integral(z, Π₀, dΠdz;
                               tolerance = sqrt(eps(float(typeof(Π₀)))),
                               initial_steps = 16,
                               max_steps = 1 << 16) =
    converge_by_step_doubling(nsteps -> midpoint_integral(z, Π₀, dΠdz, nsteps),
                              Π₀, z, tolerance, initial_steps, max_steps)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the dry hydrostatic pressure at height ``z`` by numerically integrating
``∂p/∂z = -g ρ`` from ``z=0``, where ``ρ = p/(Rᵈ T)`` and ``T = θ(z) (p/pˢᵗ)^κ``.

This function handles non-uniform potential temperature profiles ``θ(z)`` for which
the closed-form adiabatic solution does not apply. The integration is carried out in
the dry Exner function ``Π = (p / pˢᵗ)^κ``, which satisfies the linear equation
``∂Π/∂z = -g / (cᵖᵈ θ(z))``.
"""
function numerically_integrated_hydrostatic_pressure(z, p₀, θ_func, pˢᵗ, constants)
    Rᵈ = dry_air_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    κ = Rᵈ / cᵖᵈ
    g = constants.gravitational_acceleration
    Π₀ = (p₀ / pˢᵗ)^κ
    @inline dΠdz(zᵢ) = -g / (cᵖᵈ * θ_func(zᵢ))
    Π = converged_hydrostatic_integral(z, Π₀, dΠdz)
    return pˢᵗ * Π^(1 / κ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the dry hydrostatic density at height `z` from the numerically integrated pressure
and the given potential temperature profile `θ_func(z)`.
"""
function numerically_integrated_hydrostatic_density(z, p₀, θ_func, pˢᵗ, constants)
    Rᵈ = dry_air_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    κ = Rᵈ / cᵖᵈ
    p = numerically_integrated_hydrostatic_pressure(z, p₀, θ_func, pˢᵗ, constants)
    θ = θ_func(z)
    T = θ * (p / pˢᵗ)^κ
    return p / (Rᵈ * T)
end

#####
##### Dispatch: select closed-form (constant θ₀) or numerical (θᵣ(z)) hydrostatic profiles
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Dry hydrostatic pressure at height `z`, reduced from the datum `p₀` at ``z = 0`` along the
reference potential temperature, with `pˢᵗ` the standard pressure of the Exner function.

The potential temperature selects how the reduction is carried out: a constant `θ₀` has the
closed form [`adiabatic_hydrostatic_pressure`](@ref), while a profile `θᵣ(z)` is integrated
numerically by [`numerically_integrated_hydrostatic_pressure`](@ref). `hydrostatic_density` and
`hydrostatic_temperature` dispatch the same way.
"""
hydrostatic_pressure(z, p₀, θ₀::Number, pˢᵗ, constants) =
    adiabatic_hydrostatic_pressure(z, p₀, θ₀, pˢᵗ, constants)

hydrostatic_density(z, p₀, θ₀::Number, pˢᵗ, constants) =
    adiabatic_hydrostatic_density(z, p₀, θ₀, pˢᵗ, constants)

function hydrostatic_temperature(z, p₀, θ₀::Number, pˢᵗ, constants)
    κ = dry_air_gas_constant(constants) / constants.dry_air.heat_capacity
    p = adiabatic_hydrostatic_pressure(z, p₀, θ₀, pˢᵗ, constants)
    return θ₀ * (p / pˢᵗ)^κ
end

# Numerical integration for θᵣ(z) profiles
hydrostatic_pressure(z, p₀, θᵣ::Function, pˢᵗ, constants) =
    numerically_integrated_hydrostatic_pressure(z, p₀, θᵣ, pˢᵗ, constants)

hydrostatic_density(z, p₀, θᵣ::Function, pˢᵗ, constants) =
    numerically_integrated_hydrostatic_density(z, p₀, θᵣ, pˢᵗ, constants)

function hydrostatic_temperature(z, p₀, θᵣ::Function, pˢᵗ, constants)
    κ = dry_air_gas_constant(constants) / constants.dry_air.heat_capacity
    p = numerically_integrated_hydrostatic_pressure(z, p₀, θᵣ, pˢᵗ, constants)
    return θᵣ(z) * (p / pˢᵗ)^κ
end

# Evaluate a profile (Number or Function) at a given height.
# Used both here and in terrain_compressible_physics.jl for reference state construction.
"""
    evaluate_profile(profile, z)

Evaluate a vertical profile at height `z`. If `profile` is a `Number`, returns it unchanged.
If `profile` is a `Function`, calls `profile(z)`.
"""
@inline evaluate_profile(value::Number, z) = value
@inline evaluate_profile(f::Function, z) = f(z)

# Surface value for a reference profile: a `Number`, a column profile `f(z)`, or a
# horizontally varying profile `f(x, y, z)` (the 3D reference path) evaluated at the origin.
@inline surface_value(θ::Number) = θ

# `f(z)`, `f(φ, z)` on a `LatitudeLongitudeGrid`, or `f(x, y, z)`, all evaluated at the origin.
function surface_value(f::Function)
    nargs = _nargs(f)
    nargs == 1 && return f(0)
    nargs == 2 && return f(0, 0)
    return f(0, 0, 0)
end

#####
##### Continuous hydrostatic reduction from the z = 0 datum
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Integrate the hydrostatic equation ``∂p/∂z = \\mathrm{dpdz}(z, p)`` from ``z = 0`` to
height ``z``, repeatedly doubling the number of steps until the pressure at ``z`` changes
by less than the relative `tolerance` between successive refinements. `dpdz(z, p)` returns
the local pressure gradient ``-g ρ`` given height and pressure.
"""
converged_hydrostatic_pressure(z, p₀, dpdz;
                               tolerance = sqrt(eps(float(typeof(p₀)))),
                               initial_steps = 16,
                               max_steps = 1 << 16) =
    converge_by_step_doubling(nsteps -> runge_kutta2_integral(z, p₀, dpdz, nsteps),
                              p₀, z, tolerance, initial_steps, max_steps)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Continuous hydrostatic pressure at physical height `z`, reduced from the datum `p₀` at
``z = 0`` along the reference profiles `θᵣ` and `qᵛᵣ`. A dry reference (`qᵛᵣ = nothing`)
falls through to [`hydrostatic_pressure`](@ref), which has a closed form for constant `θᵣ`; a constant
moist reference (`θᵣ` and `qᵛᵣ` both numbers) has one too, and uses it.

This is the one place the ``z = 0`` datum is converted into a pressure at some other height.
Both reference-state families use it to obtain the anchor at the bottom face of a column: the
terrain surface on a terrain-following grid, the domain bottom on a height-coordinate grid.
It returns `p₀` exactly when `z == 0`. The Exner exponent `κ̂` relating `θᵣ` to temperature defaults
to `VaporEquivalentExponent()`; pass the model's exponent so the anchor lies on the column that
`set_to_mean!` integrates. A dry reference is independent of the exponent.
"""
moist_hydrostatic_pressure(z, p₀, θᵣ, ::Nothing, pˢᵗ, constants, κ̂=VaporEquivalentExponent()) =
    hydrostatic_pressure(z, p₀, θᵣ, pˢᵗ, constants)

# Exact, and free of the integrator's convergence branches, so it also traces when the
# profile values are traced numbers (a reference reset inside a compiled function).
moist_hydrostatic_pressure(z, p₀, θᵣ::Number, qᵛᵣ::Number, pˢᵗ, constants, κ̂=VaporEquivalentExponent()) =
    constant_moist_hydrostatic_pressure(z, p₀, θᵣ, qᵛᵣ, pˢᵗ,
                                        dry_air_gas_constant(constants), vapor_gas_constant(constants),
                                        constants.dry_air.heat_capacity, constants.vapor.heat_capacity,
                                        constants.gravitational_acceleration, κ̂)

function moist_hydrostatic_pressure(z, p₀, θᵣ, qᵛᵣ, pˢᵗ, constants, κ̂=VaporEquivalentExponent())
    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    cᵖᵛ = constants.vapor.heat_capacity
    g = constants.gravitational_acceleration

    @inline function dpdz(zⁿ, p)
        θⁿ = evaluate_profile(θᵣ, zⁿ)
        qᵛⁿ = evaluate_profile(qᵛᵣ, zⁿ)
        Rᵐⁿ, cᵖᵐⁿ, κᵐⁿ = moist_reference_constants(qᵛⁿ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
        κⁿ, _ = column_exner_exponent(κ̂, Rᵐⁿ, cᵖᵐⁿ, κᵐⁿ, Rᵈ, cᵖᵈ)
        Tⁿ = θⁿ * (p / pˢᵗ)^κⁿ
        return -g * p / (Rᵐⁿ * Tⁿ)
    end

    return converged_hydrostatic_pressure(z, p₀, dpdz)
end

# Restrict a horizontally varying reference profile to one vertical column. The coordinate tuple
# contains every active horizontal coordinate supplied by `set!`. The first branch handles
# Cartesian f(x, y, z) and two-dimensional f(x, z) profiles. The second handles zonally symmetric
# f(φ, z) profiles on a three-dimensional LatitudeLongitudeGrid. A plain f(z) remains valid when
# only the other reference profile varies horizontally.
column_profile_at_coordinates(value::Number, coordinates, z) = value
column_profile_at_coordinates(::Nothing, coordinates, z) = nothing

function column_profile_at_coordinates(profile::Function, coordinates, z)
    applicable(profile, coordinates..., z) && return height -> profile(coordinates..., height)
    length(coordinates) > 1 && applicable(profile, last(coordinates), z) &&
        return height -> profile(last(coordinates), height)
    applicable(profile, z) && return height -> profile(height)

    throw(ArgumentError("A horizontally varying reference profile cannot be evaluated along " *
                        "a column at horizontal coordinates $coordinates."))
end

function columnwise_surface_pressure_field(grid, zˢ, p₀, θᵣ, qᵛᵣ, pˢᵗ, constants)
    # The reduction is the identity at the datum, so the usual domain starting at z = 0 needs
    # neither the per-column integration nor the arity resolution it would take to set it up.
    zˢ == 0 && return surface_state_field(grid, convert(eltype(grid), p₀))

    function pressure_at_surface(coordinates...)
        θ_column = column_profile_at_coordinates(θᵣ, coordinates, zˢ)
        qᵛ_column = column_profile_at_coordinates(qᵛᵣ, coordinates, zˢ)
        return moist_hydrostatic_pressure(zˢ, p₀, θ_column, qᵛ_column, pˢᵗ, constants)
    end

    return surface_state_field(grid, pressure_at_surface)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Height of the bottom face of column `(1, 1)`, the level at which a height-coordinate
reference state is anchored. Zero for the usual domain that starts at the ground.
"""
bottom_face_height(grid) = @allowscalar znode(1, 1, 1, grid, Center(), Center(), Face())

# The anchor pressure for a column integration is stored either as a scalar or as a 2D field. The
# field may vary because the reference thermodynamics varies horizontally or because the bottom
# face is terrain. Both representations are read the same way inside the column kernels.
@inline column_surface_pressure(pˢ::Number, i, j) = pˢ
@inline column_surface_pressure(pˢ, i, j) = @inbounds pˢ[i, j, 1]

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Extrapolate pressure from the first cell center to the bottom face using the local
hydrostatic scale height ``p / (ρg)``. This provides a live surface pressure from the
model state without assuming where the reference-pressure datum is located.
"""
@inline surface_pressure_from_cell_center(p, ρ, Δz, g) = p * exp(g * Δz * ρ / (2 * p))

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

The same extrapolation, reading the pressure and density fields at `(i, j, k)`. Every consumer of
"the live pressure at the bottom face" — the surface fluxes, the diagnostic hydrostatic pressure,
and `PrescribedDynamics` — goes through this one method, so they cannot drift on which level or
which half-cell factor they use.
"""
@inline function surface_pressure_from_cell_center(i, j, k, grid, p, ρ, g)
    @inbounds pᵏ = p[i, j, k]
    @inbounds ρᵏ = ρ[i, j, k]
    return surface_pressure_from_cell_center(pᵏ, ρᵏ, Δzᶜᶜᶜ(i, j, k, grid), g)
end

# A "column ensemble" grid holds many independent columns in Flat horizontal dimensions of size > 1
# (e.g. built with `Oceananigans.Grids.ColumnEnsembleSize`). Reduced `(Nothing, Nothing, Center)`
# fields — the memory-efficient reference profile broadcast across the horizontal — cannot be
# constructed on such grids (Oceananigans sizes the data by topology but indexes it by the reduced
# location). On an ordinary 3D grid or a 1×1 single column, reduced fields work as before.
function is_column_ensemble(grid)
    TX, TY, TZ = topology(grid)
    Nx, Ny, Nz = size(grid)
    return (TX === Flat && Nx > 1) || (TY === Flat && Ny > 1)
end

# Horizontal location of the reference-profile fields: reduced (`Nothing`) on ordinary grids, full
# (`Center`) on a column-ensemble grid where reduced fields cannot be built. Returns location *types*.
reference_horizontal_location(grid) = is_column_ensemble(grid) ? (Center, Center) : (Nothing, Nothing)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return a `ReferenceState` on `grid`, with [`ThermodynamicConstants`](@ref) `constants`
that includes the hydrostatic reference pressure and reference density.

The reference state is initialized with a dry adiabatic temperature profile
and the given moisture profiles (zero by default). The pressure and density
are then computed by hydrostatic integration using the mixture gas constant
``Rᵐ = qᵈ Rᵈ + qᵛ Rᵛ`` and the ideal gas law ``ρ = p / (Rᵐ T)``.

Arguments
=========
- `grid`: The grid.
- `constants :: ThermodynamicConstants`: By default, `ThermodynamicConstants(eltype(grid))`.

Keyword arguments
=================
- `base_pressure`: Reference pressure at ``z = 0``, the datum the hydrostatic profiles are
  anchored to rather than the pressure at the ground. By default, 101325.
- `potential_temperature`: A constant value (default 288) or a function ``θ(z)`` giving
  the potential temperature profile. When a constant is provided, closed-form adiabatic
  hydrostatic profiles are used. When a function is provided, the hydrostatic profiles
  are computed by numerical integration of ``∂p/∂z = -g ρ``.
- `standard_pressure`: Reference pressure for potential temperature (``pˢᵗ``). By default, 1e5.
- `discrete_hydrostatic_balance`: If `true`, recompute the reference pressure from the
  reference density using discrete integration, so that `∂z(p_ref) + g * ℑz(ρ_ref) = 0`
  exactly at the discrete level. By default, `false`.

  !!! note "Discrete vs continuous hydrostatic balance"
      With discrete balance, reference subtraction becomes a no-op (the subtracted terms
      cancel to machine precision). For split-explicit compressible dynamics, **continuous**
      balance (default) is preferred: both the actual and reference states share similar
      ``O(Δz^2)`` truncation errors that cancel in the perturbation PG, leaving only the
      tiny truncation error of the physical perturbation ``∂(p - p_{ref})/∂z``.
- `vapor_mass_fraction`: Initial qᵛ profile. Can be a `Number`, `Function(z)`, or `Field`. Default: `nothing` (`ZeroField`).
- `liquid_mass_fraction`: Initial qˡ profile. Default: `nothing` (`ZeroField`).
- `ice_mass_fraction`: Initial qⁱ profile. Default: `nothing` (`ZeroField`).

Pass `=0` to allocate an actual `Field` initialized to zero — required for later use
with [`compute_reference_state!`](@ref) or `set_to_mean!`.
"""
function ReferenceState(grid, constants=ThermodynamicConstants(eltype(grid));
                        base_pressure = 101325,
                        potential_temperature = 288,
                        standard_pressure = 1e5,
                        discrete_hydrostatic_balance = false,
                        vapor_mass_fraction = nothing,
                        liquid_mass_fraction = nothing,
                        ice_mass_fraction = nothing,
                        surface_pressure = nothing)

    reject_renamed_surface_pressure(surface_pressure)

    pˢᵗ = convert(eltype(grid), standard_pressure)
    return materialize_reference_state(grid, constants, base_pressure, potential_temperature, pˢᵗ,
                                       discrete_hydrostatic_balance,
                                       vapor_mass_fraction, liquid_mass_fraction, ice_mass_fraction)
end

# Homogeneous reference state: a constant `base_pressure` and a constant or `z`-function
# `potential_temperature` give one profile shared by every column. Array-valued parameters dispatch
# instead to the per-column methods below (`materialize_reference_state(..., ::AbstractArray, ...)`).
function materialize_reference_state(grid, constants, base_pressure::Number,
                                     potential_temperature::Union{Number, Function}, pˢᵗ,
                                     discrete_hydrostatic_balance, vapor_mass_fraction,
                                     liquid_mass_fraction, ice_mass_fraction)

    FT = eltype(grid)
    p₀ = convert(FT, base_pressure)

    # Reference profiles depend only on height. On ordinary grids they are stored as reduced
    # (Nothing, Nothing, Center) column profiles; on a column-ensemble grid they become full
    # CenterFields (one identical profile per column). See `is_column_ensemble`.
    LX, LY = reference_horizontal_location(grid)
    loc = (LX(), LY(), Center())

    # Moisture mass fractions: ZeroField by default, actual Field when specified
    qᵛᵣ = reference_moisture_field(vapor_mass_fraction, grid)
    qˡᵣ = reference_moisture_field(liquid_mass_fraction, grid)
    qⁱᵣ = reference_moisture_field(ice_mass_fraction, grid)

    θᵣ = potential_temperature
    θ₀ = convert(FT, surface_value(θᵣ))
    zˢ = bottom_face_height(grid)
    pˢ = surface_state_field(grid, convert(FT, hydrostatic_pressure(zˢ, p₀, θᵣ, pˢᵗ, constants)))
    ρˢ = surface_state_field(grid, convert(FT, hydrostatic_density(zˢ, p₀, θᵣ, pˢᵗ, constants)))
    Tˢ = surface_state_field(grid, convert(FT, hydrostatic_temperature(zˢ, p₀, θᵣ, pˢᵗ, constants)))

    ρ_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(ρˢ)))
    ρᵣ = Field{LX, LY, Center}(grid, boundary_conditions=ρ_bcs)
    set!(ρᵣ, z -> hydrostatic_density(z, p₀, θᵣ, pˢᵗ, constants))
    fill_halo_regions!(ρᵣ)

    p_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(pˢ)))
    pᵣ = Field{LX, LY, Center}(grid, boundary_conditions=p_bcs)
    set!(pᵣ, z -> hydrostatic_pressure(z, p₀, θᵣ, pˢᵗ, constants))
    fill_halo_regions!(pᵣ)

    if discrete_hydrostatic_balance
        g = constants.gravitational_acceleration
        enforce_discrete_hydrostatic_balance!(pᵣ, ρᵣ, grid, g)
    end

    Tᵣ = Field{LX, LY, Center}(grid)
    set!(Tᵣ, z -> hydrostatic_temperature(z, p₀, θᵣ, pˢᵗ, constants))
    fill_halo_regions!(Tᵣ)

    return ReferenceState(p₀, pˢ, ρˢ, Tˢ, θ₀, pˢᵗ, pᵣ, ρᵣ, Tᵣ, qᵛᵣ, qˡᵣ, qⁱᵣ)
end

#####
##### Per-column (heterogeneous) reference state
#####
#
# Array-valued `base_pressure` and/or `potential_temperature` give each column of an ensemble its
# own adiabatic profile. Dispatching on the parameter type (rather than an `isa` predicate) keeps the
# homogeneous and per-column paths as distinct methods.

materialize_reference_state(grid, constants, base_pressure::AbstractArray, potential_temperature, pˢᵗ, args...) =
    column_reference_state(grid, constants, base_pressure, potential_temperature, pˢᵗ, args...)

materialize_reference_state(grid, constants, base_pressure::Number, potential_temperature::AbstractArray, pˢᵗ, args...) =
    column_reference_state(grid, constants, base_pressure, potential_temperature, pˢᵗ, args...)

# Select a column's value from a per-column parameter: a scalar is shared by all columns; a matrix
# supplies one value per column. Kernel-safe (`@inline`, allocation-free).
@inline column_value(x::Number, i, j) = x
@inline column_value(x::AbstractArray, i, j) = @inbounds x[i, j]

validate_column_parameter(::Number, Nx, Ny, name) = nothing
function validate_column_parameter(x::AbstractArray, Nx, Ny, name)
    size(x) == (Nx, Ny) ||
        throw(ArgumentError("`$name` array must have size ($Nx, $Ny) to match the column ensemble, got $(size(x))."))
    return nothing
end

# Bring a per-column parameter to `grid`'s architecture with element type `FT`. Scalars pass through.
column_parameter(x::Number, FT, arch) = convert(FT, x)
column_parameter(x::AbstractArray, FT, arch) = on_architecture(arch, FT.(x))

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct a per-column `ReferenceState` on a column-ensemble grid, where `base_pressure` and/or
`potential_temperature` are `(Nx, Ny)` arrays supplying one adiabatic profile per column. Scalars are
shared across all columns. The reference *fields* (`ρᵣ`, `pᵣ`, `Tᵣ`) then vary column-by-column; the
scalar `base_pressure`/`potential_temperature` metadata store the first column's surface values.
"""
function column_reference_state(grid, constants, base_pressure, potential_temperature, pˢᵗ,
                                discrete_hydrostatic_balance,
                                vapor_mass_fraction, liquid_mass_fraction, ice_mass_fraction)

    FT = eltype(grid)
    arch = architecture(grid)
    Nx, Ny, Nz = size(grid)

    is_column_ensemble(grid) ||
        throw(ArgumentError("Array-valued `base_pressure`/`potential_temperature` require a " *
                            "column-ensemble grid (Flat horizontal topology with size > 1)."))

    validate_column_parameter(base_pressure, Nx, Ny, "base_pressure")
    validate_column_parameter(potential_temperature, Nx, Ny, "potential_temperature")

    (vapor_mass_fraction === nothing && liquid_mass_fraction === nothing && ice_mass_fraction === nothing) ||
        throw(ArgumentError("Moisture profiles are not yet supported with per-column reference states."))

    discrete_hydrostatic_balance &&
        throw(ArgumentError("`discrete_hydrostatic_balance` is not yet supported with per-column reference states."))

    p₀ = column_parameter(base_pressure, FT, arch)
    θ₀ = column_parameter(potential_temperature, FT, arch)

    ρᵣ = CenterField(grid)
    pᵣ = CenterField(grid)
    Tᵣ = CenterField(grid)

    # Each column carries its own bottom-face anchor, reduced from that column's own datum.
    pˢ = Field{Center, Center, Nothing}(grid)
    ρˢ = Field{Center, Center, Nothing}(grid)
    Tˢ = Field{Center, Center, Nothing}(grid)

    launch!(arch, grid, :xy, _compute_adiabatic_reference_columns!,
            ρᵣ, pᵣ, Tᵣ, pˢ, ρˢ, Tˢ, grid, Nz, p₀, θ₀, pˢᵗ, constants)
    fill_halo_regions!(ρᵣ)
    fill_halo_regions!(pᵣ)
    fill_halo_regions!(Tᵣ)
    fill_halo_regions!(pˢ)
    fill_halo_regions!(ρˢ)
    fill_halo_regions!(Tˢ)

    # Representative scalar surface metadata (first column); the per-column detail lives in the fields.
    p₀₁₁ = @allowscalar convert(FT, column_value(p₀, 1, 1))
    θ₀₁₁ = @allowscalar convert(FT, column_value(θ₀, 1, 1))
    Z = reference_moisture_field(nothing, grid)

    return ReferenceState(p₀₁₁, pˢ, ρˢ, Tˢ, θ₀₁₁, pˢᵗ, pᵣ, ρᵣ, Tᵣ, Z, Z, Z)
end

@kernel function _compute_adiabatic_reference_columns!(ρᵣ, pᵣ, Tᵣ, pˢ, ρˢ, Tˢ, grid, Nz, p₀, θ₀, pˢᵗ, constants)
    i, j = @index(Global, NTuple)
    p₀ᵢⱼ = column_value(p₀, i, j)
    θ₀ᵢⱼ = column_value(θ₀, i, j)

    zˢ = znode(i, j, 1, grid, Center(), Center(), Face())
    @inbounds begin
        pˢ[i, j, 1] = adiabatic_hydrostatic_pressure(zˢ, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
        ρˢ[i, j, 1] = adiabatic_hydrostatic_density(zˢ, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
        Tˢ[i, j, 1] = hydrostatic_temperature(zˢ, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
    end

    @inbounds for k in 1:Nz
        z = znode(i, j, k, grid, Center(), Center(), Center())
        ρᵣ[i, j, k] = adiabatic_hydrostatic_density(z, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
        pᵣ[i, j, k] = adiabatic_hydrostatic_pressure(z, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
        Tᵣ[i, j, k] = hydrostatic_temperature(z, p₀ᵢⱼ, θ₀ᵢⱼ, pˢᵗ, constants)
    end
end

#####
##### ExnerReferenceState: built in Exner coordinates for split-explicit compressible dynamics
#####

"""
    ExnerReferenceState

A dry reference state built in Exner coordinates, ensuring that the discrete Exner
hydrostatic balance

```math
cᵖᵈ θᵣ^{face} \\frac{π₀[k] - π₀[k-1]}{Δz} = -g
```

holds _exactly_ at every interior z-face. This is essential for the Exner pressure
acoustic substepping formulation, where the vertical pressure gradient is computed
as ``cᵖᵈ θᵥ ∂π'/∂z`` and the hydrostatic part must cancel to machine precision.

Unlike [`ReferenceState`](@ref) which builds pressure first and derives Exner,
this type builds the Exner function π₀ first by discrete integration and then
derives pressure and density from it. This matches CM1's approach where `pi0`
is the fundamental reference variable.

Fields
======

- `base_pressure`: Reference pressure at z=0 (Pa). The datum, not a pressure at the ground:
  the two differ by ``O(ρgh)`` whenever the ground is not at ``z = 0``.
- `surface_pressure`: Reference pressure at the bottom face of each column (Pa), as a 2D
  ``(Center, Center, Nothing)`` field, obtained by reducing `base_pressure` to that height with
  [`moist_hydrostatic_pressure`](@ref). Equal to `base_pressure` for the usual domain that starts
  at ``z = 0``, and horizontally uniform on any height-coordinate grid, whose bottom face is a
  single level; genuinely column-dependent on a terrain-following grid, where it is the pressure at
  the terrain surface. This is the anchor every consumer of "pressure at the surface" actually
  wants, and the quantity that keeps the column integration, the cold start, and the diagnostic
  hydrostatic pressure consistent over terrain. A reference reset writes into this field in place,
  so consumers that captured it stay current — see [`surface_state_field`](@ref).
- `surface_density`: Reference density at the bottom face (kg/m³), the boundary value that the
  bottom `ValueBoundaryCondition` of `density` reads, or `nothing` for the 3D and terrain-following
  forms, whose `density` carries no bottom boundary value.
- `surface_potential_temperature`: Reference potential temperature at z=0 (K)
- `standard_pressure`: pˢᵗ for potential temperature definition (Pa)
- `pressure`: Reference pressure field ``p₀ = pˢᵗ π₀^{cᵖᵈ/Rᵈ}`` (derived from π₀)
- `density`: Reference density field ``ρ₀ = p₀/(Rᵈ T₀)`` (derived from π₀ and θᵣ)
- `exner_function`: Reference Exner function π₀ (built by discrete integration)
"""
struct ExnerReferenceState{FT, SP, SD, FP, FD, FE}
    base_pressure :: FT
    surface_pressure :: SP
    surface_density :: SD
    surface_potential_temperature :: FT
    standard_pressure :: FT
    pressure :: FP
    density :: FD
    exner_function :: FE
end

Adapt.adapt_structure(to, ref::ExnerReferenceState) =
    ExnerReferenceState(adapt(to, ref.base_pressure),
                        adapt(to, ref.surface_pressure),
                        adapt(to, ref.surface_density),
                        adapt(to, ref.surface_potential_temperature),
                        adapt(to, ref.standard_pressure),
                        adapt(to, ref.pressure),
                        adapt(to, ref.density),
                        adapt(to, ref.exner_function))

Base.eltype(::ExnerReferenceState{FT}) where FT = FT

function Base.summary(ref::ExnerReferenceState)
    FT = eltype(ref)
    return string("ExnerReferenceState{$FT}(p₀=", prettysummary(ref.base_pressure),
                  ", θ₀=", prettysummary(ref.surface_potential_temperature),
                  ", pˢᵗ=", prettysummary(ref.standard_pressure), ")")
end

Base.show(io::IO, ref::ExnerReferenceState) = print(io, summary(ref))

@kernel function _compute_isothermal_reference!(π₀, pᵣ, ρᵣ, θᵣ, grid, Nz, p₀, pˢᵗ, κ, Rᵈ, g, T₀)
    _ = @index(Global)

    # Discrete-balance recurrence. Enforces
    #
    #   (p[k] − p[k − 1]) / Δz_face[k] + g · (ρ[k] + ρ[k − 1]) / 2 = 0
    #
    # exactly, where ρ[k] = p[k] / (Rᵈ T₀), so the substepper's slow
    # vertical-momentum tendency is zero on a rest atmosphere to
    # floating-point precision. The previous MPAS-form analytic
    # solution `p(z) = p₀ exp(-g z / (Rᵈ T₀))` satisfies the
    # *continuous* hydrostatic equation but leaves a discrete-operator
    # residual ~1e-3 N/m³, which seeds an acoustic instability at
    # production Δt.
    #
    # For constant T₀, the recurrence has the closed form
    #   p[k] = p[k − 1] · (1 − a) / (1 + a),  a = g Δz_face / (2 Rᵈ T₀).

    # Anchor at the first cell center via the continuous analytic
    # solution `p(z) = p₀ exp(-gz / (Rᵈ T₀))`. Face k = 1 is a
    # boundary face (ρw[1] = 0 by impenetrability) and the substepper
    # does NOT apply the discrete-balance check there, so we are free
    # to anchor however we like; the continuous formula keeps
    # `base_pressure = p₀` semantics intact and matches what users
    # set with `θ = θᵇᵍ(z)`.
    z₁ = znode(1, 1, 1, grid, Center(), Center(), Center())
    p¹ = p₀ * exp(-g * z₁ / (Rᵈ * T₀))
    ρ¹ = p¹ / (Rᵈ * T₀)
    Π¹ = (p¹ / pˢᵗ)^κ
    @inbounds begin
        pᵣ[1, 1, 1] = p¹
        π₀[1, 1, 1] = Π¹
        ρᵣ[1, 1, 1] = ρ¹
        θᵣ[1, 1, 1] = T₀ / Π¹
    end
    p⁻ = p¹
    ρ⁻ = ρ¹

    # Discrete-balance recurrence for k = 2..Nz. Each iteration gives
    # `(p[k] − p[k − 1]) / Δz_face[k] + g · (ρ[k] + ρ[k − 1]) / 2 = 0`
    # at machine precision, so the substepper's slow vertical-momentum
    # tendency is zero on a rest atmosphere to ulp.
    for k in 2:Nz
        Δz_face = Δzᶜᶜᶠ(1, 1, k, grid)
        a = g * Δz_face / (2 * Rᵈ * T₀)
        pᵏ = (p⁻ - g * Δz_face * ρ⁻ / 2) / (1 + a)
        ρᵏ = pᵏ / (Rᵈ * T₀)
        Πᵏ = (pᵏ / pˢᵗ)^κ
        @inbounds begin
            pᵣ[1, 1, k] = pᵏ
            π₀[1, 1, k] = Πᵏ
            ρᵣ[1, 1, k] = ρᵏ
            θᵣ[1, 1, k] = T₀ / Πᵏ
        end
        p⁻ = pᵏ
        ρ⁻ = ρᵏ
    end
end

# Level-local moist EOS constants from a vapor mass fraction: the mixture gas
# constant Rᵐ = (1-qᵛ) Rᵈ + qᵛ Rᵛ, isobaric heat capacity cᵖᵐ = (1-qᵛ) cᵖᵈ + qᵛ cᵖᵛ,
# and κᵐ = Rᵐ/cᵖᵐ. The dry case is recovered exactly when qᵛ ≡ 0. Operates on plain
# scalars (not a `MoistureMassFractions`) so it can be called from GPU kernels that
# receive the bare constants rather than a `ThermodynamicConstants` object.
@inline function moist_reference_constants(qᵛ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
    qᵈ = 1 - qᵛ
    Rᵐ = qᵈ * Rᵈ + qᵛ * Rᵛ
    cᵖᵐ = qᵈ * cᵖᵈ + qᵛ * cᵖᵛ
    return Rᵐ, cᵖᵐ, Rᵐ / cᵖᵐ
end

# The bottom-face density implied by a bottom-face pressure and the moist state there,
# ρˢ = pˢ / (Rᵐ θˢ Πˢ), with Πˢ defined by the Exner exponent `κ̂` as in `_compute_exner_column!`.
# Shared by the `ExnerReferenceState` constructor and by `set_to_mean!`, so a reset lands on the
# same boundary value the constructor would have produced.
@inline function surface_reference_density(pˢ, θˢ, qᵛˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, κ̂)
    Rᵐ, cᵖᵐ, κᵐ = moist_reference_constants(qᵛˢ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
    κ, _ = column_exner_exponent(κ̂, Rᵐ, cᵖᵐ, κᵐ, Rᵈ, cᵖᵈ)
    Πˢ = (pˢ / pˢᵗ)^κ
    return pˢ / (Rᵐ * θˢ * Πˢ)
end

@inline function constant_moist_hydrostatic_pressure(z, p₀, θ, qᵛ, pˢᵗ,
                                                     Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
    Rᵐ, cᵖᵐ, κᵐ = moist_reference_constants(qᵛ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
    κ, ĉᵖ = column_exner_exponent(κ̂, Rᵐ, cᵖᵐ, κᵐ, Rᵈ, cᵖᵈ)
    Π₀ = (p₀ / pˢᵗ)^κ
    Π = Π₀ - g * z / (ĉᵖ * θ)
    return pˢᵗ * Π^(1 / κ)
end

# Newton solve of the discrete hydrostatic balance for the pressure pₖ at one face,
# given the level below (p⁻, ρ⁻) and the level-local moist constants. The residual
#   F(p) = p / Δz + Aₖ p^(1−κₖ) − Cₖ,   Aₖ = g pˢᵗ^κₖ / (2 Rᵐₖ θₖ),  Cₖ = p⁻/Δz − g ρ⁻/2
# is monotone increasing in p, so Newton converges quadratically from the continuous-Π
# initial guess pₖ — `FixedIterations(5)` reaches machine precision across the atmospheric
# range (verified in test/solvers.jl), and both call sites (the per-column Exner kernel and
# the terrain reference-state solve) use that same count. The iteration is delegated to the
# unified `newton_solve` driver (see Breeze.Solvers); passing a `FixedIterations` solver
# keeps the trip count fixed so the loop unrolls to straight-line code on the GPU.
@inline function newton_hydrostatic_pressure(p⁻, ρ⁻, θₖ, Rᵐₖ, κₖ, Δz, pˢᵗ, g, pₖ, solver)
    Aₖ = g * pˢᵗ^κₖ / (2 * Rᵐₖ * θₖ)
    Cₖ = p⁻ / Δz - g * ρ⁻ / 2
    @inline function residual_and_derivative(p)
        ρp = p^(-κₖ)
        f  = p / Δz + Aₖ * p * ρp - Cₖ
        f′ = 1 / Δz + Aₖ * (1 - κₖ) * ρp
        return f, f′
    end
    return newton_solve(residual_and_derivative, solver, pₖ)
end

# Discrete-balance Exner integration for one column (i, j) of θ̄ and an
# optional vapor profile qᵛ. Enforces
#   (p[k] − p[k − 1]) / Δz_face[k] + g · (ρ[k] + ρ[k − 1]) / 2 = 0
# at every interior face k = 2..Nz, with the level-local moist EOS
# ρ[k] = p[k] / (Rᵐ[k] T[k]), T[k] = θ̄[k] · Π[k], Π[k] = (p/pˢᵗ)^κ[k],
# Rᵐ = (1-qᵛ) Rᵈ + qᵛ Rᵛ, cᵖᵐ = (1-qᵛ) cᵖᵈ + qᵛ cᵖᵛ. The exponent κ[k] is selected by
# `κ̂` (see `column_exner_exponent`): κᵐ = Rᵐ/cᵖᵐ for `VaporEquivalentExponent` and κᵈ for
# `DryExponent`, so the balanced column matches the EOS the model inverts θ with. The dry
# case is recovered exactly when qᵛ ≡ 0.
#
# The previous MPAS-style up-then-down Π integration satisfies the
# *continuous* hydrostatic equation but leaves a discrete-operator
# residual ~1e-3 N/m³ that seeds an acoustic instability at production Δt.
@inline function _compute_exner_column!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, i, j, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
    # Anchor at first cell center via the continuous Π recurrence (one
    # half-step from the bottom face). Face k = 1 is the impenetrability boundary
    # face — no discrete-balance constraint applies — so the anchor is free.
    #
    # `pˢ` is the pressure *at that bottom face*, not the z = 0 datum: the caller has already
    # reduced the datum to the face height with `moist_hydrostatic_pressure`. The two coincide
    # for the usual domain whose bottom is at z = 0. Keeping the datum reduction on the host
    # (where the reference profile is a callable) is what lets this kernel serve both the
    # height-coordinate column and the per-column terrain anchor.
    @inbounds begin
        qᵛ¹ = qᵛ[i, j, 1]
        Rᵐ¹, cᵖᵐ¹, κᵐ¹ = moist_reference_constants(qᵛ¹, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
        κ¹, ĉᵖ¹ = column_exner_exponent(κ̂, Rᵐ¹, cᵖᵐ¹, κᵐ¹, Rᵈ, cᵖᵈ)
        π₀_surface = (column_surface_pressure(pˢ, i, j) / pˢᵗ)^κ¹

        Δzᶜ₁ = Δzᶜᶜᶜ(i, j, 1, grid)
        θ¹ = θ₀[i, j, 1]
        Π¹ = π₀_surface - g * Δzᶜ₁ / (2 * ĉᵖ¹ * θ¹)
        p¹ = pˢᵗ * Π¹^(1/κ¹)
        ρ¹ = p¹ / (Rᵐ¹ * θ¹ * Π¹)

        π₀[i, j, 1] = Π¹
        pᵣ[i, j, 1] = p¹
        ρᵣ[i, j, 1] = ρ¹
    end
    integrate_exner_column!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, i, j, grid, 2, Nz, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
end

# Upward discrete-balance recurrence for levels k = k_first..Nz of column (i, j), continuing from
# the already-filled level `k_first - 1`. The residual
#   F(p) = (p − p⁻) / Δz_face + g · (ρ(p) + ρ⁻) / 2
# with ρ(p) = p^(1−κᵏ) · pˢᵗ^κᵏ / (Rᵐᵏ θ̄[k]) is monotone increasing in p, so Newton converges in
# O(few) iterations from the continuous-Π guess. Shared by the height-coordinate anchor above and
# the terrain-following anchor in `Breeze.CompressibleEquations` — the two differ only in how the
# first level is set, not in the interior recurrence.
@inline function integrate_exner_column!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, i, j, grid, k_first, Nz, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
    @inbounds begin
        p⁻ = pᵣ[i, j, k_first - 1]
        ρ⁻ = ρᵣ[i, j, k_first - 1]
    end

    for k in k_first:Nz
        Δz_face = Δzᶜᶜᶠ(i, j, k, grid)
        @inbounds begin
            θᵏ = θ₀[i, j, k]
            θᵏ⁻ = θ₀[i, j, k - 1]
            qᵛᵏ = qᵛ[i, j, k]
        end
        Rᵐᵏ, cᵖᵐᵏ, κᵐᵏ = moist_reference_constants(qᵛᵏ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ)
        κᵏ, ĉᵖᵏ = column_exner_exponent(κ̂, Rᵐᵏ, cᵖᵐᵏ, κᵐᵏ, Rᵈ, cᵖᵈ)

        # Initial guess: continuous Π integration (one face step).
        θ_face = (θᵏ + θᵏ⁻) / 2
        Πᵏ_init = @inbounds(π₀[i, j, k - 1]) - g * Δz_face / (ĉᵖᵏ * θ_face)
        pᵏ = pˢᵗ * Πᵏ_init^(1/κᵏ)

        # Newton solve of the discrete-balance residual to machine precision.
        pᵏ = newton_hydrostatic_pressure(p⁻, ρ⁻, θᵏ, Rᵐᵏ, κᵏ, Δz_face, pˢᵗ, g, pᵏ, FixedIterations(5))
        Πᵏ = (pᵏ / pˢᵗ)^κᵏ
        ρᵏ = pᵏ / (Rᵐᵏ * θᵏ * Πᵏ)
        @inbounds begin
            π₀[i, j, k] = Πᵏ
            pᵣ[i, j, k] = pᵏ
            ρᵣ[i, j, k] = ρᵏ
        end
        p⁻ = pᵏ
        ρ⁻ = ρᵏ
    end
end

@kernel function _compute_exner_reference!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
    _ = @index(Global)
    _compute_exner_column!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, 1, 1, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Construct an `ExnerReferenceState` by discrete Exner integration on `grid`.

Two modes are supported, controlled by which keyword is provided:

**Isentropic** (`potential_temperature`): Constant or horizontally-varying θ₀.
Each column is built by Newton iteration on the discrete hydrostatic balance
``(p_k - p_{k-1})/Δz_{face} + g(ρ_k + ρ_{k-1})/2 = 0`` so the substepper's
slow vertical-momentum tendency vanishes to ulp on a rest atmosphere. The
same column kernel handles both the 1D path (`θ₀` constant or z-dependent)
and the 3D path (`θ₀(x, y, z)`); `vapor_mass_fraction` is supported in both.
When provided, the level-local moist gas constants ``Rᵐ = (1-qᵛ)Rᵈ + qᵛRᵛ``,
``cᵖᵐ = (1-qᵛ)cᵖᵈ + qᵛcᵖᵛ`` are used; the dry case is recovered exactly
when ``qᵛ ≡ 0``.
The column is integrated with the vapor-equivalent Exner exponent ``κᵐ = Rᵐ/cᵖᵐ``. A model
evolving ``θˡⁱ`` with `DryExponent` inverts the same ``θ₀`` to a slightly different temperature;
`set_to_mean!` recomputes the reference with the model's exponent.

**Isothermal** (`reference_temperature`): Constant T₀ (MPAS baroclinic wave
convention). Uses the analytic isothermal solution:
``p₀(z) = pˢ \\exp(-g z / (Rᵈ T₀))``, ``Π₀ = (p₀/pˢᵗ)^κ``,
``ρ₀ = p₀/(Rᵈ T₀)``, ``θ₀ = T₀/Π₀``.
This matches MPAS init_atm_cases.F lines 813-817 exactly.

Arguments
=========
- `grid`: The grid
- `constants`: Thermodynamic constants (default: `ThermodynamicConstants(eltype(grid))`)

Keyword Arguments
=================
- `base_pressure`: Pressure at ``z = 0`` (default: 101325 Pa). This is a datum, not the
  pressure at the ground: on a domain whose bottom face sits above ``z = 0`` it is reduced to
  that height before anchoring the column, so the reference profile passes through
  `base_pressure` at ``z = 0`` regardless of where the domain starts.
- `potential_temperature`: Constant value or function `θᵣ(z)` for isentropic reference (default: 288 K)
- `reference_temperature`: Constant T₀ for isothermal reference (default: `nothing`).
  When provided, overrides `potential_temperature`.
- `standard_pressure`: pˢᵗ for potential temperature definition (default: 1e5 Pa)
- `vapor_mass_fraction`: Optional vapor mass fraction for a moist reference state.
  A number or function `qᵛ(z)` builds a 1D column; a multi-argument function
  `qᵛ(x, y, z)` (or `qᵛ(φ, z)` on a `LatitudeLongitudeGrid`) builds a 3D field.
"""
function ExnerReferenceState(grid, constants=ThermodynamicConstants(eltype(grid));
                             base_pressure = 101325,
                             potential_temperature = 288,
                             reference_temperature = nothing,
                             standard_pressure = 1e5,
                             vapor_mass_fraction = nothing,
                             surface_pressure = nothing)

    reject_renamed_surface_pressure(surface_pressure)

    FT = eltype(grid)
    arch = architecture(grid)
    p₀ = convert(FT, base_pressure)
    pˢᵗ = convert(FT, standard_pressure)
    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    cᵖᵈ = constants.dry_air.heat_capacity
    cᵖᵛ = constants.vapor.heat_capacity
    κ = Rᵈ / cᵖᵈ
    g = constants.gravitational_acceleration
    Nz = size(grid, 3)

    # Height of the domain's bottom face. `base_pressure` is the datum at z = 0, so anything
    # anchored at the bottom face — the column integration, the bottom boundary values, and every
    # downstream consumer of "pressure at the surface" — needs the datum reduced to this height
    # first. Zero, and so a no-op, for the usual domain that starts at the ground.
    zˢ = bottom_face_height(grid)

    if reference_temperature !== nothing
        vapor_mass_fraction === nothing ||
            throw(ArgumentError("`vapor_mass_fraction` is not supported with `reference_temperature`."))

        # ── Isothermal base state (MPAS baroclinic wave convention) ──
        # Analytic solution: p(z) = p₀ exp(-gz/(Rᵈ T₀)), Π = (p/pˢᵗ)^κ,
        # ρ = p/(Rᵈ T₀), θ = T₀/Π.  (MPAS init_atm_cases.F lines 813-817)
        T₀ = convert(FT, reference_temperature)
        loc = (nothing, nothing, Center())

        # The isothermal kernel anchors from the z = 0 datum through `znode`, so it already
        # respects the datum; only the bottom-face values need the analytic reduction.
        pˢ_value = convert(FT, p₀ * exp(-g * zˢ / (Rᵈ * T₀)))
        pˢ = surface_state_field(grid, pˢ_value)
        ρˢ = surface_state_field(grid, convert(FT, pˢ_value / (Rᵈ * T₀)))

        θᵣ = Field{Nothing, Nothing, Center}(grid)
        πᵣ = Field{Nothing, Nothing, Center}(grid)
        p_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(pˢ)))
        pᵣ = Field{Nothing, Nothing, Center}(grid, boundary_conditions=p_bcs)
        ρ_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(ρˢ)))
        ρᵣ = Field{Nothing, Nothing, Center}(grid, boundary_conditions=ρ_bcs)

        launch!(arch, grid, tuple(1), _compute_isothermal_reference!,
                πᵣ, pᵣ, ρᵣ, θᵣ, grid, Nz, p₀, pˢᵗ, κ, Rᵈ, g, T₀)
    else
        # ── Isentropic base state (constant or z-dependent θ₀) ──
        # Either thermodynamic profile can make the reference horizontally varying.
        needs_3d = _needs_3d_reference(potential_temperature) ||
                   _needs_3d_reference(vapor_mass_fraction)

        if needs_3d
            # 3D reference: per-column discrete-balance integration for
            # horizontally varying θ₀(x, y, z). Same kernel as the 1D path,
            # indexed by (i, j); dry case (qᵛ = ZeroField) and moist case
            # share a single code path.
            #
            # Reduce the datum to the bottom face along each reference column: a height-coordinate
            # bottom is geometrically level, but its pressure is not horizontally uniform when θ or
            # qᵛ varies horizontally above a uniform pressure datum at z = 0.
            pˢ = columnwise_surface_pressure_field(grid, zˢ, p₀, potential_temperature,
                                                   vapor_mass_fraction, pˢᵗ, constants)

            θᵣ = CenterField(grid)
            set!(θᵣ, potential_temperature)
            fill_halo_regions!(θᵣ)

            πᵣ = CenterField(grid)
            pᵣ = CenterField(grid)
            ρᵣ = CenterField(grid)
            # The 3D form carries no bottom boundary value on `density`.
            ρˢ = nothing

            qᵛᵣ = vapor_mass_fraction === nothing ? ZeroField(FT) :
                  let qf = CenterField(grid)
                      set!(qf, vapor_mass_fraction)
                      fill_halo_regions!(qf)
                      qf
                  end

            launch!(arch, grid, :xy, _compute_exner_reference_3d!,
                    πᵣ, pᵣ, ρᵣ, θᵣ, qᵛᵣ, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, VaporEquivalentExponent())
        else
            # 1D reference: single column, broadcast to all (i,j). The unified
            # kernel handles both dry (qᵛ = ZeroField) and moist cases via the
            # moist gas constants Rᵐ, cᵖᵐ, κᵐ — these reduce to Rᵈ, cᵖᵈ, κ
            # when qᵛ = 0.
            #
            # The bottom face is a single level, so one reduction of the datum serves every column.
            pˢ_value = convert(FT, moist_hydrostatic_pressure(zˢ, p₀, potential_temperature,
                                                              vapor_mass_fraction, pˢᵗ, constants))
            pˢ = surface_state_field(grid, pˢ_value)

            loc = (nothing, nothing, Center())
            θᵣ = Field{Nothing, Nothing, Center}(grid)
            set!(θᵣ, potential_temperature)
            fill_halo_regions!(θᵣ)

            πᵣ = Field{Nothing, Nothing, Center}(grid)
            # θ at the bottom face, which is where the bottom boundary values below live.
            θˢ = convert(FT, evaluate_profile(potential_temperature, zˢ))

            qᵛᵣ = reference_moisture_field(vapor_mass_fraction, grid)
            qᵛ_surface = if isnothing(vapor_mass_fraction)
                zero(FT)
            else
                convert(FT, evaluate_profile(vapor_mass_fraction, zˢ))
            end
            ρˢ = surface_state_field(grid, surface_reference_density(pˢ_value, θˢ, qᵛ_surface, pˢᵗ,
                                                                    Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, VaporEquivalentExponent()))

            p_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(pˢ)))
            pᵣ = Field{Nothing, Nothing, Center}(grid, boundary_conditions=p_bcs)
            ρ_bcs = FieldBoundaryConditions(grid, loc, bottom=ValueBoundaryCondition(surface_boundary_value(ρˢ)))
            ρᵣ = Field{Nothing, Nothing, Center}(grid, boundary_conditions=ρ_bcs)

            launch!(arch, grid, tuple(1), _compute_exner_reference!,
                    πᵣ, pᵣ, ρᵣ, θᵣ, qᵛᵣ, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, VaporEquivalentExponent())
        end
    end

    fill_halo_regions!(θᵣ)
    fill_halo_regions!(πᵣ)
    fill_halo_regions!(pᵣ)
    fill_halo_regions!(ρᵣ)

    # Surface θ₀ for the struct: for isothermal, θ_surface = T₀/Π_surface = T₀
    θ₀_val = if reference_temperature !== nothing
        convert(FT, reference_temperature)  # T₀ (at surface Π≈1, θ≈T)
    else
        convert(FT, surface_value(potential_temperature))
    end

    return ExnerReferenceState(p₀, pˢ, ρˢ, θ₀_val, pˢᵗ, pᵣ, ρᵣ, πᵣ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Whether `ref` stores a single reference column broadcast to every `(i, j)`, as opposed to genuinely
column-dependent 3D fields. Selects between the single-column and per-column integration kernels on
a reset. The field dimensions provide this information directly without relying on the values in
`surface_pressure`.
"""
is_column_reference(ref) = size(ref.pressure, 1) == 1 && size(ref.pressure, 2) == 1

# Detect if θ₀ needs a 3D (per-column) reference.
# Functions with ≥2 methods or ≥2 arguments → 3D.
_needs_3d_reference(::Number) = false
_needs_3d_reference(::Nothing) = false
_needs_3d_reference(f::Function) = _nargs(f) > 1
_nargs(f) = maximum(m.nargs for m in methods(f)) - 1  # subtract 1 for the function itself

@kernel function _compute_exner_reference_3d!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
    i, j = @index(Global, NTuple)
    _compute_exner_column!(π₀, pᵣ, ρᵣ, θ₀, qᵛ, i, j, grid, Nz, pˢ, pˢᵗ, Rᵈ, Rᵛ, cᵖᵈ, cᵖᵛ, g, κ̂)
end

# ExnerReferenceState has the same surface_density interface as ReferenceState
function surface_density(ref::ExnerReferenceState)
    ρ = ref.density
    grid = ρ.grid
    return @allowscalar ℑzᵃᵃᶠ(1, 1, 1, grid, ρ)
end

@kernel function _enforce_discrete_hydrostatic_balance!(pᵣ, ρᵣ, grid, Nz, g)
    _ = @index(Global)

    # Integrate upward from k=2, enforcing balance at each interior face.
    # pᵣ[1] is kept at its analytic value (closest to the surface boundary condition).
    for k in 2:Nz
        Δzᶠ = Δzᶜᶜᶠ(1, 1, k, grid)
        @inbounds ρᶠ = (ρᵣ[1, 1, k] + ρᵣ[1, 1, k - 1]) / 2
        @inbounds pᵣ[1, 1, k] = pᵣ[1, 1, k - 1] - g * Δzᶠ * ρᶠ
    end
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Recompute the reference pressure `pᵣ` from the reference density `ρᵣ` by discrete
upward integration, ensuring that the discrete hydrostatic balance

```math
\\frac{p_{ref}[k] - p_{ref}[k-1]}{Δz} + g \\frac{ρ_{ref}[k] + ρ_{ref}[k-1]}{2} = 0
```

holds exactly at every interior z-face. This guarantees that reference-state subtraction
in the pressure gradient and buoyancy cancels to machine precision, eliminating the
``O(Δz^2)`` truncation error that would otherwise dominate the momentum tendency
for nearly-hydrostatic flows.
"""
function enforce_discrete_hydrostatic_balance!(pᵣ, ρᵣ, grid, g)
    arch = architecture(grid)
    Nz = size(grid, 3)
    launch!(arch, grid, tuple(1), _enforce_discrete_hydrostatic_balance!, pᵣ, ρᵣ, grid, Nz, g)
    fill_halo_regions!(pᵣ)
    return nothing
end

#####
##### Helpers for moisture mass fraction fields
#####

reference_moisture_field(::Nothing, grid) = ZeroField(eltype(grid))

function reference_moisture_field(value, grid)
    field = Field{Nothing, Nothing, Center}(grid)
    set!(field, value)
    fill_halo_regions!(field)
    return field
end

# set! and fill_halo_regions! are no-ops for ZeroField
set_reference_field!(field, value) = (set!(field, value); fill_halo_regions!(field); nothing)
set_reference_field!(::ZeroField, value) = nothing

#####
##### Recompute reference state from profiles
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Recompute the reference pressure and density profiles by setting the
reference temperature to `T̄` and moisture mass fractions to `q̄ᵛ`, `q̄ˡ`, `q̄ⁱ`,
then integrating the hydrostatic equation using the mixture gas constant
`Rᵐ = qᵈ Rᵈ + qᵛ Rᵛ` and ideal gas law `ρ = p / (Rᵐ T)`.

`T̄`, `q̄ᵛ`, `q̄ˡ`, `q̄ⁱ` can be `Number`s, `Function(z)`s, or `Field`s.

This function is useful for:
- Initialization: setting the reference state to match a non-constant-θ initial condition
- Runtime: calling from a callback to keep the reference state close to the evolving mean state
"""
function compute_reference_state!(ref::ReferenceState, T̄, q̄ᵛ, q̄ˡ, q̄ⁱ, constants)
    set!(ref.temperature, T̄)
    fill_halo_regions!(ref.temperature)
    set_reference_field!(ref.vapor_mass_fraction, q̄ᵛ)
    set_reference_field!(ref.liquid_mass_fraction, q̄ˡ)
    set_reference_field!(ref.ice_mass_fraction, q̄ⁱ)
    compute_hydrostatic_reference!(ref, constants)
    return nothing
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Convenience method that assumes all moisture is vapor (no condensate in the
reference state). Equivalent to `compute_reference_state!(reference_state, T̄, q̄ᵗ, 0, 0, constants)`.
"""
function compute_reference_state!(ref::ReferenceState, T̄, q̄ᵗ, constants)
    compute_reference_state!(ref, T̄, q̄ᵗ, 0, 0, constants)
end
