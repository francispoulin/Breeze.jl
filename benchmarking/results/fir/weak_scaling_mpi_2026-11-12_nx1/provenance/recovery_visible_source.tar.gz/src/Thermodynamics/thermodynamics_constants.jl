using Adapt: Adapt, adapt
using Oceananigans.Utils: prettysummary

"""
$(TYPEDEF)

A struct representing an ideal gas with molar mass and specific heat capacity.

# Fields
- `molar_mass`: Molar mass of the gas in kg/mol
- `heat_capacity`: Specific heat capacity at constant pressure in J/(kg·K)

# Examples
```jldoctest
using Breeze
dry_air = IdealGas(molar_mass=0.02897, heat_capacity=1005)

# output
IdealGas{Float64}(molar_mass=0.02897, heat_capacity=1005.0)
```
"""
struct IdealGas{FT}
    molar_mass :: FT
    heat_capacity :: FT # specific heat capacity at constant pressure
end

function Base.summary(gas::IdealGas{FT}) where FT
    return string("IdealGas{", FT, "}(",
                  "molar_mass=", prettysummary(gas.molar_mass), ", ",
                  "heat_capacity=", prettysummary(gas.heat_capacity), ")")
end

Base.show(io::IO, gas::IdealGas) = print(io, summary(gas))
Base.eltype(::IdealGas{FT}) where FT = FT

function Adapt.adapt_structure(to, gas::IdealGas)
    molar_mass = adapt(to, gas.molar_mass)
    heat_capacity = adapt(to, gas.heat_capacity)
    FT = typeof(molar_mass)
    return IdealGas{FT}(molar_mass, heat_capacity)
end

function IdealGas(FT = Oceananigans.defaults.FloatType;
                  molar_mass = 0.02897,
                  heat_capacity = 1005)

    return IdealGas{FT}(convert(FT, molar_mass),
                        convert(FT, heat_capacity))
end

struct CondensedPhase{FT}
    reference_latent_heat :: FT
    heat_capacity :: FT
    density :: FT
end

function Base.summary(ph::CondensedPhase{FT}) where FT
    return string("CondensedPhase{", FT, "}(",
                  "reference_latent_heat=", prettysummary(ph.reference_latent_heat), ", ",
                  "heat_capacity=", prettysummary(ph.heat_capacity), ", ",
                  "density=", prettysummary(ph.density), ")")
end

Base.show(io::IO, ph::CondensedPhase) = print(io, summary(ph))

Adapt.adapt_structure(to, pt::CondensedPhase) =
    CondensedPhase(adapt(to, pt.reference_latent_heat),
                   adapt(to, pt.heat_capacity),
                   adapt(to, pt.density))

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return `CondensedPhase` with specified parameters converted to `FT`.

Two examples of `CondensedPhase` are liquid and ice.
When matter is converted from vapor to liquid, water molecules in the
gas phase cluster together and slow down to form liquid with `heat_capacity`,
The lost of molecular kinetic energy is called the `reference_latent_heat`.

Likewise, during deposition, water molecules in the gas phase cluster into ice crystals.

Arguments
=========
- `FT`: Float type to use (defaults to `Oceananigans.defaults.FloatType`)
- `reference_latent_heat`: Difference between the internal energy of the gaseous phase at
  the `energy_reference_temperature`.
- `heat_capacity`: Heat capacity of the phase of matter.
- `density`: Reference mass density of the phase of matter [kg/m³].
"""
function CondensedPhase(FT = Oceananigans.defaults.FloatType;
                        reference_latent_heat,
                        heat_capacity,
                        density)
    return CondensedPhase{FT}(convert(FT, reference_latent_heat),
                              convert(FT, heat_capacity),
                              convert(FT, density))
end

liquid_water(FT) = CondensedPhase(FT; reference_latent_heat=2500800,
                                      heat_capacity=4181,
                                      density=1000)

water_ice(FT) = CondensedPhase(FT; reference_latent_heat=2834000,
                                   heat_capacity=2108,
                                   density=917)

"""
$(TYPEDEF)

A saturation vapor pressure formulation based on the Clausius-Clapeyron relation.

The Clausius-Clapeyron equation describes how saturation vapor pressure varies with
temperature based on thermodynamic principles. This formulation uses thermodynamic
constants (latent heats, heat capacities, triple point values) to compute
saturation vapor pressure analytically.

See [`saturation_vapor_pressure`](@ref) for the implementation details.
"""
struct ClausiusClapeyron end

Base.summary(::ClausiusClapeyron) = "ClausiusClapeyron()"
Base.show(io::IO, cc::ClausiusClapeyron) = print(io, summary(cc))
Adapt.adapt_structure(to, cc::ClausiusClapeyron) = cc

struct ThermodynamicConstants{FT, C, I, SVP}
    molar_gas_constant :: FT
    gravitational_acceleration :: FT
    energy_reference_temperature :: FT
    triple_point_temperature :: FT
    triple_point_pressure :: FT
    dry_air :: IdealGas{FT}
    vapor :: IdealGas{FT}
    liquid :: C
    ice :: I
    saturation_vapor_pressure :: SVP
end

Base.summary(::ThermodynamicConstants{FT}) where FT = "ThermodynamicConstants{$FT}"

function Base.show(io::IO, at::ThermodynamicConstants)
    print(io, summary(at), ":", '\n',
        "├── molar_gas_constant: ", at.molar_gas_constant, "\n",
        "├── gravitational_acceleration: ", at.gravitational_acceleration, "\n",
        "├── energy_reference_temperature: ", at.energy_reference_temperature, "\n",
        "├── triple_point_temperature: ", at.triple_point_temperature, "\n",
        "├── triple_point_pressure: ", at.triple_point_pressure, "\n",
        "├── dry_air: ", at.dry_air, "\n",
        "├── vapor: ", at.vapor, "\n",
        "├── liquid: ", at.liquid, "\n",
        "├── ice: ", at.ice, "\n",
        "└── saturation_vapor_pressure: ", at.saturation_vapor_pressure)
end

Base.eltype(::ThermodynamicConstants{FT}) where FT = FT

function Adapt.adapt_structure(to, constants::ThermodynamicConstants)
    molar_gas_constant = adapt(to, constants.molar_gas_constant)
    gravitational_acceleration = adapt(to, constants.gravitational_acceleration)
    dry_air = adapt(to, constants.dry_air)
    vapor = adapt(to, constants.vapor)
    energy_reference_temperature = adapt(to, constants.energy_reference_temperature)
    triple_point_temperature = adapt(to, constants.triple_point_temperature)
    triple_point_pressure = adapt(to, constants.triple_point_pressure)
    liquid = adapt(to, constants.liquid)
    ice = adapt(to, constants.ice)
    saturation_vapor_pressure = adapt(to, constants.saturation_vapor_pressure)
    FT = typeof(molar_gas_constant)
    C = typeof(liquid)
    I = typeof(ice)
    SVP = typeof(saturation_vapor_pressure)
    return ThermodynamicConstants{FT, C, I, SVP}(molar_gas_constant,
                                                 gravitational_acceleration,
                                                 energy_reference_temperature,
                                                 triple_point_temperature,
                                                 triple_point_pressure,
                                                 dry_air,
                                                 vapor,
                                                 liquid,
                                                 ice,
                                                 saturation_vapor_pressure)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return `ThermodynamicConstants` with parameters that represent gaseous mixture of dry "air"
and vapor, as well as condensed liquid and ice phases.
The `triple_point_temperature` and `triple_point_pressure` may be combined with
internal energy parameters for condensed phases to compute the vapor pressure
at the boundary between vapor and a homogeneous sample of the condensed phase.
The `gravitational_acceleration` parameter is included to compute [`ReferenceState`](@ref)
quantities associated with hydrostatic balance.
The `liquid` and `ice` phases contain their respective reference densities for use by
microphysical parameterizations.
"""
function ThermodynamicConstants(FT = Oceananigans.defaults.FloatType;
                                molar_gas_constant = 8.314462618,
                                gravitational_acceleration = 9.81,
                                energy_reference_temperature = 273.15,
                                triple_point_temperature = 273.16,
                                triple_point_pressure = 611.657,
                                dry_air_molar_mass = 0.02897,
                                dry_air_heat_capacity = 1005,
                                vapor_molar_mass = 0.018015,
                                vapor_heat_capacity = 1850,
                                liquid = liquid_water(FT),
                                ice = water_ice(FT),
                                saturation_vapor_pressure = ClausiusClapeyron())

    dry_air = IdealGas(FT; molar_mass = dry_air_molar_mass,
                           heat_capacity = dry_air_heat_capacity)

    vapor = IdealGas(FT; molar_mass = vapor_molar_mass,
                         heat_capacity = vapor_heat_capacity)

    return ThermodynamicConstants(convert(FT, molar_gas_constant),
                                  convert(FT, gravitational_acceleration),
                                  convert(FT, energy_reference_temperature),
                                  convert(FT, triple_point_temperature),
                                  convert(FT, triple_point_pressure),
                                  dry_air,
                                  vapor,
                                  liquid,
                                  ice,
                                  saturation_vapor_pressure)
end

const TC = ThermodynamicConstants

@inline vapor_gas_constant(constants::TC)   = constants.molar_gas_constant / constants.vapor.molar_mass
@inline dry_air_gas_constant(constants::TC) = constants.molar_gas_constant / constants.dry_air.molar_mass

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the latent heat of vaporization (vapor → liquid) at temperature `T`.

The latent heat varies linearly with temperature:

```math
ℒˡ(T) = ℒˡᵣ + (cᵖᵛ - cˡ)(T - Tᵣ)
```

where ``ℒˡᵣ`` is the reference latent heat at the energy reference temperature ``Tᵣ``,
``cᵖᵛ`` is the heat capacity of vapor, and ``cˡ`` is the heat capacity of liquid water.
"""
@inline function liquid_latent_heat(T, constants::TC)
    ℒˡᵣ = constants.liquid.reference_latent_heat
    cᵖᵛ = constants.vapor.heat_capacity
    cˡ = constants.liquid.heat_capacity
    Tᵣ = constants.energy_reference_temperature
    return ℒˡᵣ + (cᵖᵛ - cˡ) * (T - Tᵣ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the latent heat of sublimation (vapor → ice) at temperature `T`.

The latent heat varies linearly with temperature:

```math
ℒⁱ(T) = ℒⁱᵣ + (cᵖᵛ - cⁱ)(T - Tᵣ)
```

where ``ℒⁱᵣ`` is the reference latent heat at the energy reference temperature ``Tᵣ``,
``cᵖᵛ`` is the heat capacity of vapor, and ``cⁱ`` is the heat capacity of ice.
"""
@inline function ice_latent_heat(T, constants::TC)
    ℒⁱᵣ = constants.ice.reference_latent_heat
    cᵖᵛ = constants.vapor.heat_capacity
    cⁱ = constants.ice.heat_capacity
    Tᵣ = constants.energy_reference_temperature
    return ℒⁱᵣ + (cᵖᵛ - cⁱ) * (T - Tᵣ)
end

@inline function specific_heat_difference(constants, phase::CondensedPhase)
    cᵖᵛ = constants.vapor.heat_capacity
    cᵝ = phase.heat_capacity
    return cᵖᵛ - cᵝ
end

@inline function absolute_zero_latent_heat(constants, phase::CondensedPhase)
    ℒᵣ = phase.reference_latent_heat # at constants.energy_reference_temperature
    Δcᵝ = specific_heat_difference(constants, phase)
    Tᵣ = constants.energy_reference_temperature
    return ℒᵣ - Δcᵝ * Tᵣ
end


#####
##### Mixtures of dry air with vapor, liquid, and ice
#####

"""
$(TYPEDEF)

A struct representing the moisture mass fractions of a moist air parcel.

# Fields
- `vapor`: the mass fraction of vapor
- `liquid`: the mass fraction of liquid
- `ice`: the mass fraction of ice
"""
struct MoistureMassFractions{FT}
    vapor :: FT
    liquid :: FT
    ice :: FT
end

@inline MoistureMassFractions(vapor::FT) where FT = MoistureMassFractions(vapor, zero(vapor), zero(vapor))
@inline MoistureMassFractions(vapor::FT, liquid::FT) where FT = MoistureMassFractions(vapor, liquid, zero(vapor))

@inline MoistureMassFractions{FT}(q::MoistureMassFractions) where FT =
    MoistureMassFractions(convert(FT, q.vapor), convert(FT, q.liquid), convert(FT, q.ice))

const MMF = MoistureMassFractions
Base.zero(::Type{MMF{FT}}) where FT = MoistureMassFractions(zero(FT), zero(FT), zero(FT))

function Base.summary(q::MoistureMassFractions{FT}) where FT
    return string("MoistureMassFractions{$FT}(vapor=", prettysummary(q.vapor),
                  ", liquid=", prettysummary(q.liquid), ", ice=", prettysummary(q.ice), ")")
end

function Base.show(io::IO, q::MoistureMassFractions{FT}) where FT
    println(io, "MoistureMassFractions{$FT}: \n",
                "├── vapor:  ", prettysummary(q.vapor), "\n",
                "├── liquid: ", prettysummary(q.liquid), "\n",
                "└── ice:    ", prettysummary(q.ice))
end

@inline total_specific_moisture(q::MMF) = q.vapor + q.liquid + q.ice
@inline dry_air_mass_fraction(q::MMF) = 1 - total_specific_moisture(q)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the gas constant of moist air mixture [in J/(kg K)] given the specific humidity
`q` and thermodynamic parameters `constants`.

The mixture gas constant is calculated as a weighted average of the dry air
and water vapor gas constants:

```math
Rᵐ = qᵈ Rᵈ + qᵛ Rᵛ ,
```

where:
- `Rᵈ` is the dry air gas constant,
- `Rᵛ` is the water vapor gas constant,
- `qᵈ` is the mass fraction of dry air, and
- `qᵛ` is the mass fraction of water vapor.

# Arguments
- `q`: the moisture mass fractions (vapor, liquid, and ice)
- `constants`: `ThermodynamicConstants` instance containing gas constants
"""
@inline function mixture_gas_constant(q::MMF, constants::TC)
    qᵈ = dry_air_mass_fraction(q)
    qᵛ = q.vapor
    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    return qᵈ * Rᵈ + qᵛ * Rᵛ
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the heat capacity of a mixture of dry air, vapor, liquid, and ice, where
the mass fractions of vapor, liquid, and ice are given by `q`.
The heat capacity of moist air is the weighted sum of its constituents:

```math
cᵖᵐ = qᵈ cᵖᵈ + qᵛ cᵖᵛ + qˡ cˡ + qⁱ cⁱ ,
```

where `qᵛ = q.vapor`, `qˡ = q.liquid`, `qⁱ = q.ice` are
the mass fractions of vapor, liquid, and ice constituents, respectively,
and `qᵈ = 1 - qᵛ - qˡ - qⁱ` is the mass fraction of dry air.
The heat capacities `cᵖᵈ`, `cᵖᵛ`, `cˡ`, `cⁱ` are the heat capacities
of dry air, vapor, liquid, and ice at constant pressure, respectively.
The liquid and ice phases are assumed to be incompressible.
"""
@inline function mixture_heat_capacity(q::MMF, constants::TC)
    qᵈ = dry_air_mass_fraction(q)
    qᵛ = q.vapor
    qˡ = q.liquid
    qⁱ = q.ice
    cᵖᵈ = constants.dry_air.heat_capacity
    cᵖᵛ = constants.vapor.heat_capacity
    cˡ = constants.liquid.heat_capacity
    cⁱ = constants.ice.heat_capacity
    return qᵈ * cᵖᵈ + qᵛ * cᵖᵛ + qˡ * cˡ + qⁱ * cⁱ
end

# The vapor-equivalent heat capacity ĉᵖ = qᵈ cᵖᵈ + qᵗ cᵖᵛ, with qᵈ = 1 - qᵗ: the heat capacity at constant
# pressure a parcel would have if all of its water were vapor. Unlike `mixture_heat_capacity`, ĉᵖ does
# not change when water changes phase. It normalizes the liquid-ice potential temperature θˡⁱ.
@inline function vapor_equivalent_heat_capacity(q::MMF, constants::TC)
    qᵗ = total_specific_moisture(q)
    qᵈ = 1 - qᵗ
    cᵖᵈ = constants.dry_air.heat_capacity
    cᵖᵛ = constants.vapor.heat_capacity
    return qᵈ * cᵖᵈ + qᵗ * cᵖᵛ
end

# The vapor-equivalent gas constant R̂ = qᵈ Rᵈ + qᵗ Rᵛ: the gas constant a parcel would have if all of its
# water were vapor. It equals `mixture_gas_constant` in unsaturated air, and κ̂ = R̂ / ĉᵖ is the exponent
# of the `VaporEquivalentExponent` Exner function.
@inline function vapor_equivalent_gas_constant(q::MMF, constants::TC)
    qᵗ = total_specific_moisture(q)
    qᵈ = 1 - qᵗ
    Rᵈ = dry_air_gas_constant(constants)
    Rᵛ = vapor_gas_constant(constants)
    return qᵈ * Rᵈ + qᵗ * Rᵛ
end

# The latent energy ℒˡ₀ qˡ + ℒⁱ₀ qⁱ of the condensate, with the latent heats extrapolated to absolute
# zero (`absolute_zero_latent_heat`). The enthalpy relative to all-vapor water is cᵖᵐ T minus this.
@inline condensate_latent_energy(q::MMF, constants) =
    absolute_zero_latent_heat(constants, constants.liquid) * q.liquid +
    absolute_zero_latent_heat(constants, constants.ice) * q.ice

#####
##### Equation of state
#####

@inline function density(T, p, q::MMF, constants::TC)
    Rᵐ = mixture_gas_constant(q, constants)
    return p / (Rᵐ * T)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the vapor pressure from the ideal gas law:

```math
pᵛ = ρ qᵛ Rᵛ T
```
"""
@inline function vapor_pressure(T, ρ, qᵛ, constants)
    Rᵛ = vapor_gas_constant(constants)
    return ρ * qᵛ * Rᵛ * T
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the relative humidity as the ratio of vapor pressure to saturation vapor pressure:

```math
ℋ = pᵛ / pᵛ⁺ = qᵛ / qᵛ⁺
```
"""
@inline function relative_humidity(T, ρ, qᵛ, constants, surface=PlanarLiquidSurface())
    pᵛ = vapor_pressure(T, ρ, qᵛ, constants)
    pᵛ⁺ = saturation_vapor_pressure(T, constants, surface)
    return pᵛ / pᵛ⁺
end

@inline function relative_humidity(T, p, q::MMF, constants, surface=PlanarLiquidSurface())
    ρ = density(T, p, q, constants)
    pᵛ = vapor_pressure(T, ρ, q.vapor, constants)
    pᵛ⁺ = saturation_vapor_pressure(T, constants, surface)
    return pᵛ / pᵛ⁺
end

#####
##### Moisture mixing ratios
#####

struct MoistureMixingRatio{FT}
    vapor :: FT
    liquid :: FT
    ice :: FT
end

@inline MoistureMixingRatio(vapor::FT) where FT = MoistureMixingRatio(vapor, zero(vapor), zero(vapor))
@inline MoistureMixingRatio(vapor::FT, liquid::FT) where FT = MoistureMixingRatio(vapor, liquid, zero(vapor))

const MR = MoistureMixingRatio
Base.zero(::Type{MR{FT}}) where FT = MoistureMixingRatio(zero(FT), zero(FT), zero(FT))

function Base.summary(q::MoistureMixingRatio{FT}) where FT
    return string("MoistureMixingRatio{$FT}(vapor=", prettysummary(q.vapor),
                  ", liquid=", prettysummary(q.liquid), ", ice=", prettysummary(q.ice), ")")
end

function Base.show(io::IO, q::MoistureMixingRatio{FT}) where FT
    println(io, "MoistureMixingRatio{$FT}: \n",
                "├── vapor:  ", prettysummary(q.vapor), "\n",
                "├── liquid: ", prettysummary(q.liquid), "\n",
                "└── ice:    ", prettysummary(q.ice))
end

@inline total_mixing_ratio(r::MR) = r.vapor + r.liquid + r.ice

@inline function total_specific_moisture(r::MR)
    rᵗ = total_mixing_ratio(r)
    return rᵗ / (1 + rᵗ)
end

@inline dry_air_mass_fraction(r::MR) = 1 - total_specific_moisture(r)

#####
##### Conversions between MoistureMassFractions and MoistureMixingRatio
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Convert `MoistureMassFractions` to `MoistureMixingRatio`.

Mixing ratios are defined as mass of constituent per mass of dry air:
```math
r = q / (1 - qᵗ) = q / qᵈ
```
where ``qᵗ`` is the total specific moisture and ``qᵈ = 1 - qᵗ`` is the dry air mass fraction.
"""
@inline function MoistureMixingRatio(q::MoistureMassFractions)
    qᵗ = total_specific_moisture(q)
    inv_qᵈ = inv(1 - qᵗ)
    return MoistureMixingRatio(q.vapor * inv_qᵈ, q.liquid * inv_qᵈ, q.ice * inv_qᵈ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Convert `MoistureMixingRatio` to `MoistureMassFractions`.

Mass fractions are defined as mass of constituent per total mass:
```math
q = r / (1 + rᵗ)
```
where ``rᵗ`` is the total mixing ratio.
"""
@inline function MoistureMassFractions(r::MoistureMixingRatio)
    rᵗ = total_mixing_ratio(r)
    inv_factor = inv(1 + rᵗ)
    return MoistureMassFractions(r.vapor * inv_factor, r.liquid * inv_factor, r.ice * inv_factor)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the gas constant of a moist air mixture given moisture mixing ratios.

Converts mixing ratios to mass fractions and calls `mixture_gas_constant(q::MMF, constants)`.
"""
@inline function mixture_gas_constant(r::MR, constants::TC)
    return mixture_gas_constant(MoistureMassFractions(r), constants)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute the heat capacity of a moist air mixture given moisture mixing ratios.

Converts mixing ratios to mass fractions and calls `mixture_heat_capacity(q::MMF, constants)`.
"""
@inline function mixture_heat_capacity(r::MR, constants::TC)
    return mixture_heat_capacity(MoistureMassFractions(r), constants)
end
