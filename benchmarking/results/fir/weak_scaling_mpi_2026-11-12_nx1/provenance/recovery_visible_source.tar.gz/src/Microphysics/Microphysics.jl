module Microphysics

export
    # Microphysics schemes and utilities
    compute_temperature,
    adjust_thermodynamic_state,
    SaturationAdjustment,
    MixedPhaseEquilibrium,
    WarmPhaseEquilibrium,
    AbstractCondensateFormation,
    ConstantRateCondensateFormation,
    NonEquilibriumCloudFormation,
    BulkMicrophysics,
    FourCategories,
    SaturationSpecificHumidity,
    SaturationSpecificHumidityField,
    DewpointTemperature,
    DewpointTemperatureField,
    DCMIP2016KesslerMicrophysics,
    InstantaneousPrecipitation,
    kessler_terminal_velocity,
    saturation_adjustment_coefficient,
    RelativeHumidity,
    RelativeHumidityField,
    Supersaturation,
    SupersaturationField,
    number_concentration,
    number_concentration_field

using ..AtmosphereModels: AtmosphereModels, moisture_fractions, grid_moisture_fractions,
    materialize_microphysical_fields, update_microphysical_fields!,
    NothingMicrophysicalState, WarmRainState, thermodynamic_state_density,
    specific_prognostic_moisture, total_density, invalid_time_step

include("saturation_adjustment.jl")
include("bulk_microphysics.jl")
include("microphysics_diagnostics.jl")
include("dcmip2016_kessler.jl")
include("instantaneous_precipitation.jl")

#####
##### Predicted Particle Properties (P3) submodule
#####

include("PredictedParticleProperties/PredictedParticleProperties.jl")
using .PredictedParticleProperties

# Re-export key P3 types
export PredictedParticlePropertiesMicrophysics, P3Microphysics,
       DiagnosticVaporExcess, PrognosticVaporExcess,
       PrognosticLiquidFraction, NoLiquidFraction

end # module Microphysics
