
#####
##### Phase 2: Riming (cloud and rain collection by ice)
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute cloud droplet collection (riming) by ice particles using the
continuous collection equation with the collision kernel integrated
over the ice particle size distribution.

The collection rate is:
```math
\\frac{dq^{cl}}{dt} = -E^{ci} q^{cl} ρ\\, ρ_\\text{corr}\\, n^i ⟨A \\mathbb{W}⟩
```
where ``⟨A \\mathbb{W}⟩`` is the number-normalized sweep-out kernel
``\\int \\mathbb{W}(D) A(D) N'(D) \\, dD / \\int N'(D) \\, dD`` [m³/s]
read from Table 1 at the ice bracket, and
``ρ_\\text{corr}`` is the ice air-density correction.

# Arguments
- `p3`: P3 microphysics scheme (provides parameters)
- `qᶜˡ`: Cloud liquid mass fraction [kg/kg]
- `qⁱ`: Ice mass fraction [kg/kg]
- `nⁱ`: Ice number concentration [1/kg]
- `T`: Temperature [K]
- `Fᶠ`: Rime fraction [-]
- `ρᶠ`: Rime density [kg/m³]
- `ρ`: Air density [kg/m³]

# Returns
- Rate of cloud → ice conversion [kg/kg/s] (also equals rime mass gain rate)
"""
@inline function cloud_riming_rate(p3, qᶜˡ, qⁱ, nⁱ, T, Fᶠ, ρᶠ, ρ, qʷⁱ = zero(typeof(qⁱ)))
    # Riming is the below-freezing branch, T ≤ T₀
    below_freezing = T <= p3.process_rates.freezing_temperature
    return cloud_collection_mass_rate(p3, qᶜˡ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, below_freezing, qʷⁱ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Ice sweep-out of cloud water, gated by `temperature_active`. Below freezing the
collected water rimes onto the ice; above freezing it is shed as rain. Both use
the same kernel, so they differ only in the gate and in what the caller does with
the result — see [`cloud_riming_rate`](@ref) and [`cloud_warm_collection_rate`](@ref).
"""
@inline function cloud_collection_mass_rate(p3, qᶜˡ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ,
                                            temperature_active,
                                            qʷⁱ = zero(typeof(qⁱ)),
                                            lookups = p3_ice_lookups(p3, qⁱ, qʷⁱ, nⁱ, Fᶠ, ρᶠ, ρ))
    FT = typeof(qᶜˡ)
    parameters = p3.process_rates

    ℂʳⁱᵐᵉ₁ = parameters.cloud_ice_collection_efficiency

    qᶜˡ₊ = max(0, qᶜˡ)
    qⁱ_total = total_ice_mass(qⁱ, qʷⁱ)
    nⁱ₊ = max(nⁱ, p3.minimum_number_mixing_ratio)

    active = temperature_active &
             (qᶜˡ₊ >= p3.minimum_mass_mixing_ratio) &
             (qⁱ_total >= p3.minimum_mass_mixing_ratio)

    # Number-normalized cloud-water collection kernel ⟨A×𝕎⟩ from the lookup table,
    # ∫ 𝕎(D) A(D) N'(D) dD / ∫ N'(D) dD, with E=1.
    collection_kernel = evaluate_at(p3.ice.collection.cloud_collection, lookups.prep)

    # Collection rate = E × qc × ni × ρ × rhofaci × ⟨A×𝕎⟩
    rate = ℂʳⁱᵐᵉ₁ * qᶜˡ₊ * nⁱ₊ * ρ * lookups.ρ_correction * collection_kernel

    return ifelse(active, rate, zero(FT))
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute above-freezing cloud collection by melting ice.

When `T > T₀`, ice particles still sweep up cloud droplets via the same collection
kernel as riming, but the collected water is immediately shed as rain drops (not frozen).
The number of new rain drops follows `process_rates.shed_drop_mass`, whose default
is the mass of a 1 mm drop, ``π/6 ρ^L D³ ≈ 5.24 × 10⁻⁷`` kg.

# Returns
- `(mass_rate, number_rate)`: Cloud → rain mass rate [kg/kg/s] and rain number source [1/kg/s]
"""
@inline function cloud_warm_collection_rate(p3, qᶜˡ, qⁱ, nⁱ, T, Fᶠ, ρᶠ, ρ,
                                            qʷⁱ = zero(typeof(qⁱ)))
    # Collection above freezing is the T > T₀ branch
    above_freezing = T > p3.process_rates.freezing_temperature
    mass_rate = cloud_collection_mass_rate(p3, qᶜˡ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, above_freezing, qʷⁱ)
    # Collected water is shed as 1 mm drops: m = π/6 × 1000 × 0.001³ ≈ 5.2e-7 kg.
    # The gate is already applied to `mass_rate`, so the quotient carries it.
    return (mass_rate, mass_rate / p3.process_rates.shed_drop_mass)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute above-freezing rain collection by melting ice.

When `T > T₀` and liquid fraction is active, rain drops collected by ice
contribute to the liquid coating (qʷⁱ) rather than to rime.
Uses the same collection kernel as rain riming.
See [Milbrandt et al. (2025)](@cite MilbrandtEtAl2025liquidfraction).

# Returns
- Rain mass rate collected onto ice [kg/kg/s]
"""
@inline function rain_warm_collection_rate(p3, qʳ, nʳ, qⁱ, nⁱ, T, Fᶠ, ρᶠ, ρ,
                                           qʷⁱ = zero(typeof(qⁱ)))
    # Collection above freezing is the T > T₀ branch. It uses the same Table 2 double-PSD
    # kernel as the below-freezing path.
    above_freezing = T > p3.process_rates.freezing_temperature
    return rain_collection_mass_rate(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, above_freezing, qʷⁱ)
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute cloud droplet number sink from riming.

Returns `(Nᶜˡ / (ρ * qᶜˡ)) * riming_rate` [1/kg/s]: the per-mass cloud
number removal proportional to the rimed cloud mass fraction.

# Arguments
- `p3`: the scheme, for `minimum_mass_mixing_ratio` (cloud below it is absent)
- `qᶜˡ`: Cloud liquid mass fraction [kg/kg]
- `Nᶜˡ`: Cloud droplet number concentration [1/m³]
- `ρ`: Air density [kg/m³]
- `riming_rate`: Cloud riming mass rate [kg/kg/s]

# Returns
- Rate of cloud number loss [1/kg/s] (positive magnitude; sign applied in tendency assembly)
"""
@inline function cloud_riming_number_rate(p3, qᶜˡ, Nᶜˡ, ρ, riming_rate)
    return cloud_number_per_cloud_mass(Nᶜˡ, ρ, qᶜˡ, p3.minimum_mass_mixing_ratio) * riming_rate
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute rain collection (riming) by ice particles from the Table 2 double-PSD
collection kernel.

**Double-PSD integration:**

Table 2 integrates over *both* the ice PSD and the rain PSD. The collision cross
section is ``(√{A(D^i)} + √{π/4} D^r)^2``, where ``A(D^i)`` is the ice projected
area. For spherical ice this reduces to ``π/4 (D^i + D^r)^2``. The ice PSD is
normalized to unit number, and the rain intercept ``N_0^r`` is factored out, so the
rate is ``\\mathcal{K} × N_0^r × n^i × ρ × ρ_\\text{corr} × E^{ri}``, with
``N_0^r = n^r λ^r`` at ``μ^r = 0``. Here ``n^r`` is the mass-specific number
recomputed from the bounded rain slope, so the rain PSD preserves mass when the
slope limiter binds.

# Arguments
- `p3`: P3 microphysics scheme (provides parameters)
- `qʳ`: Rain mass fraction [kg/kg]
- `nʳ`: Rain number concentration [1/kg]; floored at `minimum_number_mixing_ratio`
- `qⁱ`: Ice mass fraction [kg/kg]
- `nⁱ`: Ice number concentration [1/kg]
- `T`: Temperature [K]
- `Fᶠ`: Rime fraction [-]
- `ρᶠ`: Rime density [kg/m³]
- `ρ`: Air density [kg/m³]

# Returns
- Rate of rain → ice conversion [kg/kg/s] (also equals rime mass gain rate)
"""
@inline rain_riming_rate(p3, qʳ, nʳ, qⁱ, nⁱ, T, Fᶠ, ρᶠ, ρ,
                         qʷⁱ = zero(typeof(qⁱ))) =
    # Riming is the below-freezing branch, T ≤ T₀
    rain_collection_mass_rate(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ,
                              T <= p3.process_rates.freezing_temperature, qʷⁱ)

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Ice sweep-out of rain water, gated by `temperature_active`. Below freezing the
collected rain rimes onto the ice; above freezing it becomes liquid coating. See
[`rain_riming_rate`](@ref) and [`rain_warm_collection_rate`](@ref) for the gates.

Mass and number share every coordinate and both come out of one Table 2 read, so
they are returned together rather than rediagnosed independently. The number rate
replaces the monodisperse approximation `(nʳ/qʳ) × mass_rate` with the
PSD-integrated number-weighted kernel.

# Returns
- `(mass_rate, number_rate)`: rain → ice mass rate [kg/kg/s] and rain number sink [1/kg/s]
"""
# Table 2 has its own 5-D bracket; only m̄, Fˡ, and the density correction come from `lookups`.
@inline function rain_collection_rates(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ,
                                       temperature_active,
                                       qʷⁱ = zero(typeof(qⁱ)),
                                       lookups = p3_ice_lookups(p3, qⁱ, qʷⁱ, nⁱ, Fᶠ, ρᶠ, ρ))
    FT = typeof(qʳ)
    parameters = p3.process_rates

    ℂʳⁱᵐᵉ₂ = parameters.rain_ice_collection_efficiency

    qʳ₊ = max(0, qʳ)
    nʳ₊ = max(nʳ, p3.minimum_number_mixing_ratio)
    qⁱ_total = total_ice_mass(qⁱ, qʷⁱ)
    Fˡ = lookups.Fˡ
    nⁱ₊ = max(nⁱ, p3.minimum_number_mixing_ratio)

    active = temperature_active &
             (qʳ₊ >= p3.minimum_mass_mixing_ratio) &
             (qⁱ_total >= p3.minimum_mass_mixing_ratio)

    m_mean = lookups.m_mean
    density_correction = lookups.ρ_correction

    # Diagnose rain DSD slope parameter
    λʳ = rain_slope_parameter(qʳ₊, nʳ₊, parameters)
    nʳ_bounded = rain_number_from_slope(qʳ₊, λʳ, parameters)

    # Use Table 2 (double-PSD kernel) for ice-rain collection. The table stores the
    # double-PSD integrals with N₀ʳ factored out, so each rate is
    # kernel × N₀ʳ × nⁱ × ρ × (density correction) × E, with N₀ʳ = nʳ λʳ at μʳ = 0.
    mass_kernel, number_kernel = ice_rain_collection_lookup(p3.ice.ice_rain,
                                                            m_mean, λʳ, Fᶠ, Fˡ, ρᶠ)

    Nʳ₀ = nʳ_bounded * λʳ
    prefactor = ℂʳⁱᵐᵉ₂ * Nʳ₀ * nⁱ₊ * ρ * density_correction

    return (ifelse(active, prefactor * mass_kernel, zero(FT)),
            ifelse(active, prefactor * number_kernel, zero(FT)))
end

@inline rain_collection_mass_rate(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, temperature_active,
                                  qʷⁱ = zero(typeof(qⁱ))) =
    rain_collection_rates(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, temperature_active, qʷⁱ)[1]

@inline rain_collection_number_rate(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, temperature_active,
                                    qʷⁱ = zero(typeof(qⁱ))) =
    rain_collection_rates(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ, temperature_active, qʷⁱ)[2]

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute below-freezing rain number loss from riming using the tabulated
number-weighted collection kernel (`IceRainCollection.number`).
"""
@inline function rain_riming_number_rate(p3, qʳ, nʳ, qⁱ, nⁱ, T, Fᶠ, ρᶠ, ρ,
                                         qʷⁱ = zero(typeof(qⁱ)))
    # Riming is the T ≤ T₀ branch.
    below_freezing = T <= p3.process_rates.freezing_temperature
    return rain_collection_number_rate(p3, qʳ, nʳ, qⁱ, nⁱ, Fᶠ, ρᶠ, ρ,
                                       below_freezing, qʷⁱ)
end
