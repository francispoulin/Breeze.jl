"""
Small, scheme-independent helpers shared across Breeze: property sums, guarded arithmetic, the
Chebyshev–Gauss quadrature used to tabulate size-distribution integrals, and the
`@adapt_architecture` macro that generates architecture-transfer methods for
container structs.
"""
module Utils

export sum_properties,
       safe_divide,
       chebyshev_gauss_nodes_weights,
       transform_to_diameter,
       jacobian_diameter_transform,
       @adapt_architecture

using Adapt: Adapt
using DocStringExtensions: DocStringExtensions
using Oceananigans: Oceananigans
using Oceananigans.Architectures: on_architecture

#####
##### Docstring signatures
#####

# `DocStringExtensions.TYPEDSIGNATURES` with the default values of positional and keyword
# arguments shown, as in `f(x, n::Int64=3; Δt=0.001)`. Breeze docstrings use it in place of
# `TYPEDSIGNATURES`.
const TYPEDSIGNATURES_WITH_DEFAULTS = DocStringExtensions.TypedMethodSignatures(defaults = true)

# `TYPEDSIGNATURES_WITH_DEFAULTS` without the inferred return type, for methods whose return
# type is too long to be worth printing, such as a `Union` of deeply parametrized types.
const TYPEDSIGNATURES_WITH_DEFAULTS_NO_RETURN = DocStringExtensions.TypedMethodSignatures(defaults = true, returns = false)

#####
##### Sums of selected properties
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return the sum of the properties of `object` selected by the nonempty tuple `names`.
Properties may be scalars, fields, or other values supporting `+`.

A single selected property is returned unchanged. No scalar zero is added, so the
sum also supports lazy field expressions. Callers handle empty selections.

```jldoctest
using Breeze.Utils: sum_properties
sum_properties((a=1, b=2, c=4), (:a, :c))

# output
5
```
"""
@inline sum_properties(object, names::Tuple{Symbol}) = getproperty(object, first(names))

@inline function sum_properties(object, names::Tuple{Symbol, Vararg})
    value = getproperty(object, first(names))
    return value + sum_properties(object, Base.tail(names))
end

#####
##### Guarded arithmetic
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Return `a / b`, or `default` where `b` is exactly zero. Branch-free, so it is
safe inside GPU kernels.

```jldoctest
using Breeze.Utils: safe_divide
safe_divide(1.0, 0.0, -1.0)

# output
-1.0
```
"""
@inline safe_divide(a, b, default) = ifelse(iszero(b), default, a / b)

#####
##### Chebyshev–Gauss quadrature
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Compute Chebyshev–Gauss quadrature nodes and weights for `n` points.

Returns `(nodes, weights)` for approximating

```math
∫_{-1}^{1} f(x) dx ≈ ∑ᵢ wᵢ f(xᵢ)
```

The nodes cluster near the boundaries, which helps capture rapidly-varying
contributions of size-distribution integrands.

```jldoctest
using Breeze.Utils: chebyshev_gauss_nodes_weights
nodes, weights = chebyshev_gauss_nodes_weights(Float64, 4)
round(sum(weights), digits=4)

# output
2.0523
```
"""
function chebyshev_gauss_nodes_weights(FT::DataType, n::Int)
    nodes = zeros(FT, n)
    weights = zeros(FT, n)

    for i in 1:n
        x = cos(FT((2i - 1) * FT(π) / (2n)))
        nodes[i] = x
        # Chebyshev–Gauss type 1 computes ∫ f(x)/√(1-x²) dx with weight π/n.
        # For regular integrals ∫ f(x) dx, multiply by √(1-x²).
        weights[i] = FT(π) / n * sqrt(1 - x^2)
    end

    return nodes, weights
end

chebyshev_gauss_nodes_weights(n::Int) =
    chebyshev_gauss_nodes_weights(Oceananigans.defaults.FloatType, n)

#####
##### Domain transform from x ∈ [-1, 1] (Chebyshev–Gauss nodes) to D ∈ [0, ∞)
#####

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Map a Chebyshev–Gauss node `x ∈ [-1, 1]` to a particle diameter `D ∈ [0, ∞)`
using `D = (scale/λ) (1+x)/(1-x+ε)`. The default `scale = 10` covers more than
99.99% of an exponential tail with decay length 1/λ.
"""
@inline function transform_to_diameter(x, λ; scale=10)
    FT = typeof(x)
    return FT(scale) / λ * (1 + x) / (1 - x + eps(FT))
end

"""
$(TYPEDSIGNATURES_WITH_DEFAULTS)

Jacobian `dD/dx` of the diameter transform used by [`transform_to_diameter`](@ref).
"""
@inline function jacobian_diameter_transform(x, λ; scale=10)
    FT = typeof(x)
    return FT(scale) / λ * (2 + eps(FT)) / (1 - x + eps(FT))^2
end

#####
##### Architecture transfer for container structs
#####

"""
    @adapt_architecture T

Generate `Adapt.adapt_structure` and `Oceananigans.Architectures.on_architecture`
methods for `T` that walk every field of `T` and reconstruct via the positional
constructor. `T` must already be defined when the macro is expanded.

A field-by-field walk leaves scalars untouched, because both `Adapt.adapt` and
`on_architecture` fall back to the identity for types without specific methods
(`adapt_storage(to, x) = x`, `on_architecture(arch, a) = a`), so only the array
fields are actually transferred.

The invoking module must have `Adapt` and `Oceananigans` in scope.
"""
macro adapt_architecture(T)
    fields = fieldnames(getfield(__module__, T))
    adapt_args = [:(Adapt.adapt(to, x.$f)) for f in fields]
    on_arch_args = [:(on_architecture(arch, x.$f)) for f in fields]
    return esc(quote
        Adapt.adapt_structure(to, x::$T) = $T($(adapt_args...))
        Oceananigans.Architectures.on_architecture(arch, x::$T) = $T($(on_arch_args...))
    end)
end

end # module Utils
