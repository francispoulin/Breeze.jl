module Forcings

export
    geostrophic_forcings,
    SubsidenceForcing,
    GeostrophicForcing,
    SpecificForcing,
    TemperatureForcing

using Breeze.Utils: TYPEDSIGNATURES_WITH_DEFAULTS

using Oceananigans: Average, Field, set!, compute!
using Oceananigans.Grids: Center, Face
using Oceananigans.Forcings: materialize_forcing, MultipleForcings

using ..AtmosphereModels: AtmosphereModels, materialize_atmosphere_model_forcing,
                          compute_forcing!, is_density_tendency_forcing, wrap_specific_forcing

include("geostrophic_forcings.jl")
include("subsidence_forcing.jl")
include("specific_forcing.jl")
include("temperature_forcing.jl")

#####
##### Extension of materialize_forcing with context argument
#####

# Fallback: standard forcings don't need context
AtmosphereModels.materialize_atmosphere_model_forcing(forcing, field, name, model_field_names, context) =
    materialize_forcing(forcing, field, name, model_field_names)

# Handle tuples of forcings (multiple forcings on the same field)
# Uses Oceananigans' MultipleForcings to sum contributions
function AtmosphereModels.materialize_atmosphere_model_forcing(forcings::Tuple, field, name, model_field_names, context)
    materialized = Tuple(materialize_atmosphere_model_forcing(f, field, name, model_field_names, context) for f in forcings)
    return MultipleForcings(materialized)
end

# Handle compute_forcing! for MultipleForcings
function AtmosphereModels.compute_forcing!(mf::MultipleForcings)
    for forcing in mf.forcings
        compute_forcing!(forcing)
    end
    return nothing
end

#####
##### Specific-key wrapping: build a SpecificForcing for a user value supplied under a
##### specific name (`θ`, `u`, ...). Tuples recurse; user-defined density-tendency
##### forcings (i.e., those whose kernels already include the ρ factor) error to
##### prevent double-counting. Breeze's own SubsidenceForcing and GeostrophicForcing
##### return specific tendencies and so are accepted here directly.
#####

AtmosphereModels.wrap_specific_forcing(::Nothing, density_name) = nothing

function AtmosphereModels.wrap_specific_forcing(value, density_name)
    if is_density_tendency_forcing(value)
        msg = string("Forcing of type ", nameof(typeof(value)),
                     " produces a density-weighted tendency F_{ρϕ}; ",
                     "supply it under the density-weighted key `", density_name,
                     "` rather than its specific counterpart. ",
                     "Auto-wrapping it in SpecificForcing would multiply by ρ a second time.")
        throw(ArgumentError(msg))
    end
    return SpecificForcing(value)
end

function AtmosphereModels.wrap_specific_forcing(values::Tuple, density_name)
    return map(v -> wrap_specific_forcing(v, density_name), values)
end

end
